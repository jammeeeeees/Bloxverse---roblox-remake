export type AvatarSlot = 'skinColor' | 'hat' | 'face' | 'shirt' | 'pants' | 'accessory' | 'pet' | 'aura';

export interface AvatarItem {
  id: string;
  name: string;
  slot: AvatarSlot;
  price: number;
  rarity: 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary';
  emoji: string;
  description: string;
  preview: string; // CSS color / gradient for rendering
}

export const RARITY_COLORS: Record<string, { border: string; bg: string; text: string; glow: string }> = {
  common:    { border: 'border-gray-500',   bg: 'bg-gray-500/10',   text: 'text-gray-400',   glow: '' },
  uncommon:  { border: 'border-green-500',  bg: 'bg-green-500/10',  text: 'text-green-400',  glow: 'shadow-green-500/20' },
  rare:      { border: 'border-blue-500',   bg: 'bg-blue-500/10',   text: 'text-blue-400',   glow: 'shadow-blue-500/20' },
  epic:      { border: 'border-purple-500', bg: 'bg-purple-500/10', text: 'text-purple-400', glow: 'shadow-purple-500/30' },
  legendary: { border: 'border-yellow-500', bg: 'bg-yellow-500/10', text: 'text-yellow-400', glow: 'shadow-yellow-500/40' },
};

export const SLOT_INFO: Record<AvatarSlot, { label: string; emoji: string }> = {
  skinColor:  { label: 'Skin Color', emoji: '🎨' },
  hat:        { label: 'Hats',       emoji: '🎩' },
  face:       { label: 'Faces',      emoji: '😎' },
  shirt:      { label: 'Shirts',     emoji: '👕' },
  pants:      { label: 'Pants',      emoji: '👖' },
  accessory:  { label: 'Accessories', emoji: '💍' },
  pet:        { label: 'Pets',       emoji: '🐾' },
  aura:       { label: 'Auras',      emoji: '✨' },
};

export const AVATAR_ITEMS: AvatarItem[] = [
  // ── Skin Colors ──
  { id: 'skin-default',  name: 'Default',       slot: 'skinColor', price: 0,    rarity: 'common',    emoji: '🟢', description: 'Classic green Bloxverse look.',   preview: '#10b981' },
  { id: 'skin-blue',     name: 'Ocean Blue',    slot: 'skinColor', price: 50,   rarity: 'common',    emoji: '🔵', description: 'Cool blue vibes.',               preview: '#3b82f6' },
  { id: 'skin-red',      name: 'Crimson',       slot: 'skinColor', price: 50,   rarity: 'common',    emoji: '🔴', description: 'Bold and fiery.',                preview: '#ef4444' },
  { id: 'skin-purple',   name: 'Royal Purple',  slot: 'skinColor', price: 75,   rarity: 'uncommon',  emoji: '🟣', description: 'Fit for royalty.',               preview: '#8b5cf6' },
  { id: 'skin-gold',     name: 'Golden',        slot: 'skinColor', price: 200,  rarity: 'rare',      emoji: '🟡', description: 'Shiny and precious.',            preview: '#eab308' },
  { id: 'skin-pink',     name: 'Bubblegum',     slot: 'skinColor', price: 75,   rarity: 'uncommon',  emoji: '🩷', description: 'Sweet and playful.',             preview: '#ec4899' },
  { id: 'skin-black',    name: 'Shadow',        slot: 'skinColor', price: 300,  rarity: 'epic',      emoji: '⚫', description: 'Embrace the darkness.',          preview: '#1e1e2e' },
  { id: 'skin-rainbow',  name: 'Rainbow',       slot: 'skinColor', price: 750,  rarity: 'legendary', emoji: '🌈', description: 'All the colors!',               preview: 'linear-gradient(135deg,#ef4444,#f59e0b,#10b981,#3b82f6,#8b5cf6)' },

  // ── Hats ──
  { id: 'hat-none',      name: 'None',          slot: 'hat', price: 0,    rarity: 'common',    emoji: '❌', description: 'No hat.',                     preview: '' },
  { id: 'hat-cap',       name: 'Baseball Cap',  slot: 'hat', price: 30,   rarity: 'common',    emoji: '🧢', description: 'Classic cap for everyday.',    preview: '#3b82f6' },
  { id: 'hat-tophat',    name: 'Top Hat',        slot: 'hat', price: 100,  rarity: 'uncommon',  emoji: '🎩', description: 'Elegant and sophisticated.',   preview: '#1a1a2e' },
  { id: 'hat-crown',     name: 'Golden Crown',   slot: 'hat', price: 500,  rarity: 'epic',      emoji: '👑', description: 'Rule the Bloxverse!',         preview: '#eab308' },
  { id: 'hat-wizard',    name: 'Wizard Hat',     slot: 'hat', price: 150,  rarity: 'rare',      emoji: '🧙', description: 'Magical headwear.',            preview: '#7c3aed' },
  { id: 'hat-cowboy',    name: 'Cowboy Hat',     slot: 'hat', price: 80,   rarity: 'uncommon',  emoji: '🤠', description: 'Yeehaw!',                     preview: '#92400e' },
  { id: 'hat-helmet',    name: 'Space Helmet',   slot: 'hat', price: 250,  rarity: 'rare',      emoji: '🪖', description: 'Ready for launch!',           preview: '#94a3b8' },
  { id: 'hat-halo',      name: 'Halo',           slot: 'hat', price: 1000, rarity: 'legendary', emoji: '😇', description: 'Angelic glow above your head.', preview: '#fbbf24' },
  { id: 'hat-devil',     name: 'Devil Horns',    slot: 'hat', price: 400,  rarity: 'epic',      emoji: '😈', description: 'Devilishly cool.',             preview: '#dc2626' },

  // ── Faces ──
  { id: 'face-default',  name: 'Classic Smile',  slot: 'face', price: 0,    rarity: 'common',    emoji: '😊', description: 'Simple and happy.',           preview: '' },
  { id: 'face-cool',     name: 'Sunglasses',     slot: 'face', price: 60,   rarity: 'common',    emoji: '😎', description: 'Too cool for school.',        preview: '#1a1a2e' },
  { id: 'face-angry',    name: 'Battle Face',    slot: 'face', price: 40,   rarity: 'common',    emoji: '😤', description: 'Ready for war!',              preview: '#ef4444' },
  { id: 'face-wink',     name: 'Wink',           slot: 'face', price: 50,   rarity: 'common',    emoji: '😉', description: 'Charming wink.',              preview: '#f59e0b' },
  { id: 'face-robot',    name: 'Robot Face',     slot: 'face', price: 200,  rarity: 'rare',      emoji: '🤖', description: 'Bleep bloop.',                preview: '#6b7280' },
  { id: 'face-ghost',    name: 'Ghost Face',     slot: 'face', price: 350,  rarity: 'epic',      emoji: '👻', description: 'Spooky and mysterious.',      preview: '#e2e8f0' },
  { id: 'face-star',     name: 'Star Eyes',      slot: 'face', price: 600,  rarity: 'legendary', emoji: '🤩', description: 'Starry-eyed wonder!',        preview: '#fbbf24' },

  // ── Shirts ──
  { id: 'shirt-default', name: 'Basic Tee',      slot: 'shirt', price: 0,    rarity: 'common',    emoji: '👕', description: 'Simple t-shirt.',              preview: '#6b7280' },
  { id: 'shirt-hoodie',  name: 'Hoodie',         slot: 'shirt', price: 80,   rarity: 'uncommon',  emoji: '🧥', description: 'Cozy hoodie vibes.',           preview: '#1e40af' },
  { id: 'shirt-suit',    name: 'Business Suit',  slot: 'shirt', price: 150,  rarity: 'rare',      emoji: '🤵', description: 'Looking sharp!',              preview: '#1a1a2e' },
  { id: 'shirt-armor',   name: 'Knight Armor',   slot: 'shirt', price: 400,  rarity: 'epic',      emoji: '🛡️', description: 'Ready for battle.',            preview: '#94a3b8' },
  { id: 'shirt-fire',    name: 'Flame Jersey',   slot: 'shirt', price: 250,  rarity: 'rare',      emoji: '🔥', description: 'Hot stuff!',                  preview: '#ea580c' },
  { id: 'shirt-galaxy',  name: 'Galaxy Jacket',  slot: 'shirt', price: 800,  rarity: 'legendary', emoji: '🌌', description: 'Wear the cosmos.',            preview: 'linear-gradient(135deg,#1e1b4b,#4c1d95,#7e22ce)' },

  // ── Pants ──
  { id: 'pants-default', name: 'Basic Jeans',    slot: 'pants', price: 0,    rarity: 'common',    emoji: '👖', description: 'Classic blue jeans.',           preview: '#1d4ed8' },
  { id: 'pants-cargo',   name: 'Cargo Pants',    slot: 'pants', price: 60,   rarity: 'common',    emoji: '👖', description: 'Extra pockets!',               preview: '#65a30d' },
  { id: 'pants-royal',   name: 'Royal Trousers', slot: 'pants', price: 200,  rarity: 'rare',      emoji: '👖', description: 'Regal elegance.',              preview: '#7e22ce' },
  { id: 'pants-lava',    name: 'Lava Leggings',  slot: 'pants', price: 350,  rarity: 'epic',      emoji: '🌋', description: 'Walk on fire.',                preview: '#dc2626' },
  { id: 'pants-crystal', name: 'Crystal Pants',  slot: 'pants', price: 700,  rarity: 'legendary', emoji: '💎', description: 'Sparkling brilliance.',        preview: 'linear-gradient(135deg,#06b6d4,#818cf8)' },

  // ── Accessories ──
  { id: 'acc-none',      name: 'None',           slot: 'accessory', price: 0,    rarity: 'common',    emoji: '❌', description: 'No accessory.',                preview: '' },
  { id: 'acc-watch',     name: 'Gold Watch',     slot: 'accessory', price: 100,  rarity: 'uncommon',  emoji: '⌚', description: 'Time is money.',               preview: '#eab308' },
  { id: 'acc-chain',     name: 'Diamond Chain',  slot: 'accessory', price: 350,  rarity: 'epic',      emoji: '💎', description: 'Bling bling!',                preview: '#60a5fa' },
  { id: 'acc-cape',      name: 'Hero Cape',      slot: 'accessory', price: 500,  rarity: 'epic',      emoji: '🦸', description: 'Fly in style!',               preview: '#dc2626' },
  { id: 'acc-wings',     name: 'Angel Wings',    slot: 'accessory', price: 900,  rarity: 'legendary', emoji: '🪽', description: 'Take flight!',               preview: '#f0f9ff' },
  { id: 'acc-sword',     name: 'Flame Sword',    slot: 'accessory', price: 300,  rarity: 'rare',      emoji: '⚔️', description: 'Wield the power of fire.',    preview: '#f97316' },
  { id: 'acc-shield',    name: 'Crystal Shield', slot: 'accessory', price: 250,  rarity: 'rare',      emoji: '🛡️', description: 'Unbreakable defense.',        preview: '#06b6d4' },

  // ── Pets ──
  { id: 'pet-none',      name: 'None',           slot: 'pet', price: 0,     rarity: 'common',    emoji: '❌', description: 'No pet.',                   preview: '' },
  { id: 'pet-cat',       name: 'Space Cat',      slot: 'pet', price: 150,   rarity: 'uncommon',  emoji: '🐱', description: 'Meow from the stars!',      preview: '#f97316' },
  { id: 'pet-dog',       name: 'Robo Dog',       slot: 'pet', price: 150,   rarity: 'uncommon',  emoji: '🐶', description: 'Good bot!',                 preview: '#94a3b8' },
  { id: 'pet-dragon',    name: 'Baby Dragon',    slot: 'pet', price: 600,   rarity: 'epic',      emoji: '🐉', description: 'Breathes tiny flames.',     preview: '#dc2626' },
  { id: 'pet-unicorn',   name: 'Unicorn',        slot: 'pet', price: 1200,  rarity: 'legendary', emoji: '🦄', description: 'Magical companion.',        preview: '#ec4899' },
  { id: 'pet-phoenix',   name: 'Phoenix',        slot: 'pet', price: 1500,  rarity: 'legendary', emoji: '🔥', description: 'Rise from the ashes.',      preview: '#f59e0b' },
  { id: 'pet-fox',       name: 'Arctic Fox',     slot: 'pet', price: 300,   rarity: 'rare',      emoji: '🦊', description: 'Fluffy snow friend.',       preview: '#e2e8f0' },

  // ── Auras ──
  { id: 'aura-none',     name: 'None',           slot: 'aura', price: 0,     rarity: 'common',    emoji: '❌', description: 'No aura effect.',            preview: '' },
  { id: 'aura-fire',     name: 'Fire Aura',      slot: 'aura', price: 200,   rarity: 'rare',      emoji: '🔥', description: 'Surrounded by flames.',     preview: '#ef4444' },
  { id: 'aura-ice',      name: 'Ice Aura',       slot: 'aura', price: 200,   rarity: 'rare',      emoji: '❄️', description: 'Chilling presence.',        preview: '#06b6d4' },
  { id: 'aura-electric', name: 'Electric Aura',  slot: 'aura', price: 350,   rarity: 'epic',      emoji: '⚡', description: 'Sparking with energy.',     preview: '#eab308' },
  { id: 'aura-shadow',   name: 'Shadow Aura',    slot: 'aura', price: 400,   rarity: 'epic',      emoji: '🌑', description: 'Embrace the void.',        preview: '#312e81' },
  { id: 'aura-rainbow',  name: 'Rainbow Aura',   slot: 'aura', price: 1000,  rarity: 'legendary', emoji: '🌈', description: 'Radiate every color!',     preview: 'linear-gradient(135deg,#ef4444,#f59e0b,#10b981,#3b82f6,#8b5cf6)' },
  { id: 'aura-divine',   name: 'Divine Aura',    slot: 'aura', price: 2000,  rarity: 'legendary', emoji: '✨', description: 'Godlike brilliance.',       preview: '#fef3c7' },
];

export const getItemById = (id: string) => AVATAR_ITEMS.find(i => i.id === id);
export const getItemsBySlot = (slot: AvatarSlot) => AVATAR_ITEMS.filter(i => i.slot === slot);
export const ALL_SLOTS: AvatarSlot[] = ['skinColor', 'hat', 'face', 'shirt', 'pants', 'accessory', 'pet', 'aura'];

export interface EquippedAvatar {
  skinColor: string;
  hat: string;
  face: string;
  shirt: string;
  pants: string;
  accessory: string;
  pet: string;
  aura: string;
}

export const DEFAULT_EQUIPPED: EquippedAvatar = {
  skinColor: 'skin-default',
  hat: 'hat-none',
  face: 'face-default',
  shirt: 'shirt-default',
  pants: 'pants-default',
  accessory: 'acc-none',
  pet: 'pet-none',
  aura: 'aura-none',
};

export const DEFAULT_OWNED = [
  'skin-default', 'hat-none', 'face-default', 'shirt-default',
  'pants-default', 'acc-none', 'pet-none', 'aura-none',
];
