export interface GameData {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  category: string;
  players: string;
  rating: number;
  creator: string;
  tags: string[];
  gradient: string;
  multiplayer?: boolean;
  maxPlayers?: number;
}

export const GAMES: GameData[] = [
  // Multiplayer Games
  {
    id: 'horror',
    title: 'Horror Maze',
    description: 'Navigate a terrifying maze with friends. Find the exit before the monster finds you! Work together to survive the darkness.',
    thumbnail: './images/game-adventure.jpg',
    category: 'Horror',
    players: '31.2K',
    rating: 4.9,
    creator: 'ScaryGames Studio',
    tags: ['Horror', 'Multiplayer', 'Survival', 'Co-op'],
    gradient: 'from-gray-700 to-gray-900',
    multiplayer: true,
    maxPlayers: 4,
  },
  {
    id: 'battle',
    title: 'Battle Arena',
    description: 'Fight against other players in an epic battle arena! Last one standing wins. Use power-ups and strategy to dominate.',
    thumbnail: './images/game-tower.jpg',
    category: 'Battle',
    players: '45.8K',
    rating: 4.8,
    creator: 'FightClub Games',
    tags: ['PvP', 'Battle', 'Multiplayer', 'Action'],
    gradient: 'from-red-500 to-orange-600',
    multiplayer: true,
    maxPlayers: 8,
  },
  {
    id: 'racing',
    title: 'Speed Racers',
    description: 'Race against friends and players worldwide! Drift through corners, use boost pads, and cross the finish line first!',
    thumbnail: './images/game-racing.jpg',
    category: 'Racing',
    players: '22.5K',
    rating: 4.6,
    creator: 'TurboTeam',
    tags: ['Racing', 'Multiplayer', 'Cars', 'Speed'],
    gradient: 'from-blue-500 to-cyan-600',
    multiplayer: true,
    maxPlayers: 6,
  },
  {
    id: 'zombie',
    title: 'Zombie Survival',
    description: 'Team up with friends to survive waves of zombies! Build defenses, gather weapons, and protect your base from the horde.',
    thumbnail: './images/game-survival.jpg',
    category: 'Survival',
    players: '38.4K',
    rating: 4.7,
    creator: 'UndeadGames',
    tags: ['Zombies', 'Co-op', 'Survival', 'Multiplayer'],
    gradient: 'from-green-600 to-emerald-700',
    multiplayer: true,
    maxPlayers: 4,
  },
  // Single Player Games
  {
    id: 'platformer',
    title: 'Obby Jumper',
    description: 'Jump through challenging obstacle courses! Avoid lava, dodge spinning blades, and reach the finish line. How far can you go?',
    thumbnail: './images/game-obby.jpg',
    category: 'Adventure',
    players: '12.4K',
    rating: 4.7,
    creator: 'BloxDev Studio',
    tags: ['Obby', 'Platformer', 'Challenge'],
    gradient: 'from-pink-500 to-purple-600',
  },
  {
    id: 'clicker',
    title: 'Coin Tycoon',
    description: 'Click to earn coins and build your business empire! Buy upgrades, hire workers, and become the richest player in Bloxverse!',
    thumbnail: './images/game-tycoon.jpg',
    category: 'Tycoon',
    players: '28.1K',
    rating: 4.5,
    creator: 'TycoonMasters',
    tags: ['Tycoon', 'Clicker', 'Economy'],
    gradient: 'from-yellow-500 to-orange-600',
  },
  {
    id: 'memory',
    title: 'Memory Quest',
    description: 'Test your memory! Match pairs of cards to clear the board. Race against the clock and earn bonus coins for perfect matches!',
    thumbnail: './images/game-tower.jpg',
    category: 'Puzzle',
    players: '8.7K',
    rating: 4.3,
    creator: 'PuzzleWorks',
    tags: ['Puzzle', 'Memory', 'Brain'],
    gradient: 'from-blue-500 to-cyan-600',
  },
  {
    id: 'snake',
    title: 'Snake Simulator',
    description: 'Classic snake game with a Bloxverse twist! Eat food, grow longer, and avoid hitting walls or yourself. How long can you survive?',
    thumbnail: './images/game-survival.jpg',
    category: 'Arcade',
    players: '15.2K',
    rating: 4.6,
    creator: 'ArcadeBlox',
    tags: ['Arcade', 'Snake', 'Classic'],
    gradient: 'from-green-500 to-emerald-600',
  },
  {
    id: 'typing',
    title: 'Type Racer',
    description: 'Race against time by typing words as fast as you can! Improve your typing speed and accuracy. Every word counts!',
    thumbnail: './images/game-racing.jpg',
    category: 'Education',
    players: '6.3K',
    rating: 4.2,
    creator: 'EduGames',
    tags: ['Typing', 'Racing', 'Education'],
    gradient: 'from-red-500 to-rose-600',
  },
  {
    id: 'whackamole',
    title: 'Whack-a-Blox',
    description: 'Whack the moles as they pop up from their holes! Quick reflexes earn you more points. Watch out for the golden moles!',
    thumbnail: './images/game-adventure.jpg',
    category: 'Arcade',
    players: '19.8K',
    rating: 4.8,
    creator: 'FunFactory',
    tags: ['Arcade', 'Reflex', 'Fun'],
    gradient: 'from-violet-500 to-purple-600',
  },
];

export const CATEGORIES = ['All', 'Horror', 'Battle', 'Racing', 'Survival', 'Adventure', 'Tycoon', 'Puzzle', 'Arcade', 'Education'];
