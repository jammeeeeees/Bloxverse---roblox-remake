import { useState } from 'react';
import Navbar from './components/Navbar';
import GamePlayer from './components/GamePlayer';
import AuthModal from './components/AuthModal';
import HomePage from './pages/HomePage';
import DiscoverPage from './pages/DiscoverPage';
import FavoritesPage from './pages/FavoritesPage';
import ProfilePage from './pages/ProfilePage';
import LeaderboardPage from './pages/LeaderboardPage';
import AvatarShopPage from './pages/AvatarShopPage';
import FriendsPage from './pages/FriendsPage';
import MultiplayerLobbyPage from './pages/MultiplayerLobbyPage';

export default function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [activeGame, setActiveGame] = useState<string | null>(null);
  const [showAuth, setShowAuth] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [lobbyGameId, setLobbyGameId] = useState<string | null>(null);

  const handlePlayGame = (gameId: string, multiplayer: boolean = false) => {
    if (multiplayer) {
      setLobbyGameId(gameId);
      setCurrentPage('lobby');
    } else {
      setActiveGame(gameId);
    }
  };

  const handleExitGame = () => {
    setActiveGame(null);
  };

  const handleOpenAuth = (mode: 'login' | 'signup' = 'login') => {
    setAuthMode(mode);
    setShowAuth(true);
  };

  const handleStartMultiplayerGame = (gameId: string) => {
    setCurrentPage('home');
    setLobbyGameId(null);
    setActiveGame(gameId);
  };

  // If a game is active, show full-screen game view
  if (activeGame) {
    return <GamePlayer gameId={activeGame} onExit={handleExitGame} />;
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onPlayGame={handlePlayGame} onOpenAuth={() => handleOpenAuth('signup')} onNavigate={setCurrentPage} />;
      case 'discover':
        return <DiscoverPage onPlayGame={handlePlayGame} />;
      case 'favorites':
        return <FavoritesPage onPlayGame={handlePlayGame} onOpenAuth={() => handleOpenAuth('login')} />;
      case 'profile':
        return <ProfilePage onNavigate={setCurrentPage} />;
      case 'leaderboard':
        return <LeaderboardPage />;
      case 'avatar':
        return <AvatarShopPage onOpenAuth={() => handleOpenAuth('login')} />;
      case 'friends':
        return <FriendsPage onOpenAuth={() => handleOpenAuth('login')} />;
      case 'lobby':
        return <MultiplayerLobbyPage gameId={lobbyGameId} onStartGame={handleStartMultiplayerGame} onBack={() => setCurrentPage('home')} onOpenAuth={() => handleOpenAuth('login')} />;
      default:
        return <HomePage onPlayGame={handlePlayGame} onOpenAuth={() => handleOpenAuth('signup')} onNavigate={setCurrentPage} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-950">
      <Navbar currentPage={currentPage} onNavigate={setCurrentPage} onOpenAuth={handleOpenAuth} />
      <main className="max-w-7xl mx-auto px-4 py-8">
        {renderPage()}
      </main>

      {/* Footer */}
      <footer className="border-t border-gray-800 mt-16 py-8 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <span className="text-2xl">🎮</span>
              <div className="flex flex-col leading-none">
                <span className="text-white font-bold text-lg">Bloxverse</span>
                <span className="text-green-400/50 text-xs">bloxverse.arena</span>
              </div>
            </div>
            <div className="flex flex-wrap gap-6 text-sm text-gray-500">
              <button onClick={() => setCurrentPage('home')} className="hover:text-white transition-colors">Home</button>
              <button onClick={() => setCurrentPage('discover')} className="hover:text-white transition-colors">Discover</button>
              <button onClick={() => setCurrentPage('friends')} className="hover:text-white transition-colors">Friends</button>
              <button onClick={() => setCurrentPage('avatar')} className="hover:text-white transition-colors">Avatar Shop</button>
              <button onClick={() => setCurrentPage('leaderboard')} className="hover:text-white transition-colors">Leaderboard</button>
            </div>
            <p className="text-gray-600 text-sm">
              © 2025 bloxverse.arena — Play, Create, Imagine.
            </p>
          </div>
        </div>
      </footer>

      {/* Single global auth modal */}
      <AuthModal isOpen={showAuth} onClose={() => setShowAuth(false)} initialMode={authMode} />
    </div>
  );
}
