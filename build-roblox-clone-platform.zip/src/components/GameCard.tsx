import { Star, Users, Heart } from 'lucide-react';
import { GameData } from '../data/games';
import { useAuthStore } from '../store/authStore';

interface GameCardProps {
  game: GameData;
  onPlay: (gameId: string) => void;
}

export default function GameCard({ game, onPlay }: GameCardProps) {
  const { user, isLoggedIn, toggleFavorite } = useAuthStore();
  const isFavorite = isLoggedIn && user?.favoriteGames.includes(game.id);

  return (
    <div className="group bg-gray-800 rounded-2xl overflow-hidden border border-gray-700 hover:border-green-500/50 transition-all hover:shadow-xl hover:shadow-green-500/10 hover:-translate-y-1">
      {/* Thumbnail */}
      <div className={`relative aspect-video overflow-hidden bg-gradient-to-br ${game.gradient}`}>
        <img
          src={game.thumbnail}
          alt={game.title}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />

        {/* Category badge */}
        <div className="absolute top-3 left-3 flex gap-2">
          <span className={`bg-gradient-to-r ${game.gradient} text-white text-xs font-bold px-3 py-1 rounded-full shadow-lg`}>
            {game.category}
          </span>
          {game.multiplayer && (
            <span className="bg-purple-500 text-white text-xs font-bold px-2 py-1 rounded-full shadow-lg flex items-center gap-1">
              <Users size={10} /> MP
            </span>
          )}
        </div>

        {/* Favorite button */}
        {isLoggedIn && (
          <button
            onClick={(e) => { e.stopPropagation(); toggleFavorite(game.id); }}
            className="absolute top-3 right-3 w-8 h-8 bg-black/40 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-black/60 transition-colors"
          >
            <Heart
              size={16}
              className={isFavorite ? 'text-red-400 fill-red-400' : 'text-white'}
            />
          </button>
        )}

        {/* Players count */}
        <div className="absolute bottom-3 left-3 flex items-center gap-1.5 bg-black/40 backdrop-blur-sm rounded-full px-3 py-1">
          <Users size={12} className="text-green-400" />
          <span className="text-white text-xs font-medium">{game.players} playing</span>
        </div>

        {/* Play overlay */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all">
          <button
            onClick={() => onPlay(game.id)}
            className="bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold px-8 py-3 rounded-xl transform scale-90 group-hover:scale-100 transition-all shadow-xl shadow-green-500/30 hover:from-green-600 hover:to-emerald-700"
          >
            ▶ Play Now
          </button>
        </div>
      </div>

      {/* Info */}
      <div className="p-4">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <h3 className="text-white font-bold text-lg truncate">{game.title}</h3>
            <p className="text-gray-400 text-sm mt-0.5">by {game.creator}</p>
          </div>
          <div className="flex items-center gap-1 bg-gray-700 rounded-lg px-2 py-1 flex-shrink-0">
            <Star size={12} className="text-yellow-400 fill-yellow-400" />
            <span className="text-white text-sm font-medium">{game.rating}</span>
          </div>
        </div>

        <p className="text-gray-500 text-sm mt-2 line-clamp-2">{game.description}</p>

        <div className="flex flex-wrap gap-1.5 mt-3">
          {game.tags.map((tag) => (
            <span
              key={tag}
              className="text-xs bg-gray-700 text-gray-300 px-2.5 py-1 rounded-full"
            >
              {tag}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
