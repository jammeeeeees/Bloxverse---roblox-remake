import { GAMES } from '../data/games';
import PlatformerGame from '../games/PlatformerGame';
import ClickerGame from '../games/ClickerGame';
import MemoryGame from '../games/MemoryGame';
import SnakeGame from '../games/SnakeGame';
import TypingGame from '../games/TypingGame';
import WhackAMoleGame from '../games/WhackAMoleGame';
import HorrorMazeGame from '../games/HorrorMazeGame';
import BattleArenaGame from '../games/BattleArenaGame';
import RacingGame from '../games/RacingGame';
import ZombieSurvivalGame from '../games/ZombieSurvivalGame';
import { ArrowLeft, Star, Users } from 'lucide-react';

interface GamePlayerProps {
  gameId: string;
  onExit: () => void;
}

export default function GamePlayer({ gameId, onExit }: GamePlayerProps) {
  const game = GAMES.find(g => g.id === gameId);

  const renderGame = () => {
    switch (gameId) {
      case 'platformer': return <PlatformerGame onExit={onExit} />;
      case 'clicker': return <ClickerGame onExit={onExit} />;
      case 'memory': return <MemoryGame onExit={onExit} />;
      case 'snake': return <SnakeGame onExit={onExit} />;
      case 'typing': return <TypingGame onExit={onExit} />;
      case 'whackamole': return <WhackAMoleGame onExit={onExit} />;
      case 'horror': return <HorrorMazeGame onExit={onExit} />;
      case 'battle': return <BattleArenaGame onExit={onExit} />;
      case 'racing': return <RacingGame onExit={onExit} />;
      case 'zombie': return <ZombieSurvivalGame onExit={onExit} />;
      default: return <div className="text-white text-center py-20">Game not found</div>;
    }
  };

  return (
    <div className="min-h-screen bg-gray-950">
      {/* Game Header */}
      <div className="bg-gray-900 border-b border-gray-800">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={onExit}
              className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors"
            >
              <ArrowLeft size={18} />
              <span className="text-sm hidden sm:inline">Back to Games</span>
            </button>
            {game && (
              <div className="flex items-center gap-3 border-l border-gray-700 pl-4">
                <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${game.gradient} flex items-center justify-center text-sm`}>
                  {game.multiplayer ? '👥' : '🎮'}
                </div>
                <div>
                  <h2 className="text-white font-bold text-sm">{game.title}</h2>
                  <div className="flex items-center gap-3 text-xs text-gray-500">
                    <span className="flex items-center gap-1"><Users size={10} /> {game.players}</span>
                    <span className="flex items-center gap-1"><Star size={10} className="text-yellow-400" /> {game.rating}</span>
                    {game.multiplayer && <span className="text-purple-400">Multiplayer</span>}
                  </div>
                </div>
              </div>
            )}
          </div>
          <span className="text-green-400/40 text-xs hidden md:block font-mono tracking-wider">bloxverse.arena</span>
        </div>
      </div>

      {/* Game Area */}
      <div className="max-w-5xl mx-auto px-4 py-8">
        {renderGame()}
      </div>
    </div>
  );
}
