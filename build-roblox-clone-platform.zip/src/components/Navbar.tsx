import { useState } from 'react';
import { useAuthStore } from '../store/authStore';
import { useSocialStore } from '../store/socialStore';
import AvatarDisplay from './AvatarDisplay';
import {
  Gamepad2,
  Search,
  Coins,
  LogOut,
  User,
  Menu,
  X,
  Home,
  Compass,
  Star,
  Trophy,
  ShoppingBag,
  Users,
  Bell,
} from 'lucide-react';

interface NavbarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  onOpenAuth: (mode: 'login' | 'signup') => void;
}

export default function Navbar({ currentPage, onNavigate, onOpenAuth }: NavbarProps) {
  const { user, isLoggedIn, logout } = useAuthStore();
  const { friends } = useSocialStore();
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const onlineFriendsCount = friends.filter(f => f.status !== 'offline').length;

  const navItems = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'discover', label: 'Games', icon: Compass },
    { id: 'friends', label: 'Friends', icon: Users, badge: onlineFriendsCount > 0 ? onlineFriendsCount : undefined },
    { id: 'avatar', label: 'Avatar', icon: ShoppingBag },
    { id: 'favorites', label: 'Favorites', icon: Star },
    { id: 'leaderboard', label: 'Leaderboard', icon: Trophy },
  ];

  return (
    <nav className="sticky top-0 z-40 bg-gray-900/95 backdrop-blur-md border-b border-gray-800">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 group"
          >
            <div className="w-9 h-9 bg-gradient-to-br from-green-400 to-emerald-600 rounded-xl flex items-center justify-center shadow-lg shadow-green-500/20 group-hover:shadow-green-500/40 transition-shadow">
              <Gamepad2 className="text-white" size={20} />
            </div>
            <div className="hidden sm:flex flex-col items-start leading-none">
              <span className="text-white font-bold text-lg tracking-tight">
                Bloxverse
              </span>
              <span className="text-green-400/60 text-[10px] font-medium tracking-wider">
                bloxverse.arena
              </span>
            </div>
          </button>

          {/* Nav Links - Desktop */}
          <div className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={`relative flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                  currentPage === item.id
                    ? 'bg-green-500/15 text-green-400'
                    : 'text-gray-400 hover:text-white hover:bg-gray-800'
                }`}
              >
                <item.icon size={15} />
                {item.label}
                {item.badge && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full text-[10px] text-white flex items-center justify-center font-bold">
                    {item.badge}
                  </span>
                )}
              </button>
            ))}
          </div>

          {/* Search Bar */}
          <div className="hidden lg:flex relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={16} />
            <input
              type="text"
              placeholder="Search games..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && searchQuery.trim()) {
                  onNavigate('discover');
                }
              }}
              className="bg-gray-800 border border-gray-700 rounded-lg pl-9 pr-4 py-2 text-sm text-white placeholder-gray-500 w-56 focus:outline-none focus:border-green-500 focus:ring-1 focus:ring-green-500 transition-colors"
            />
          </div>

          {/* Right Side */}
          <div className="flex items-center gap-2">
            {isLoggedIn && user ? (
              <>
                {/* Notifications */}
                <button className="relative p-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded-lg transition-colors">
                  <Bell size={18} />
                  <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
                </button>

                {/* Coins */}
                <button
                  onClick={() => onNavigate('avatar')}
                  className="hidden sm:flex items-center gap-1.5 bg-gray-800 border border-gray-700 rounded-lg px-3 py-1.5 hover:border-yellow-500/40 transition-colors"
                >
                  <Coins size={16} className="text-yellow-400" />
                  <span className="text-yellow-400 font-semibold text-sm">
                    {user.bloxCoins.toLocaleString()}
                  </span>
                </button>

                {/* Level Badge */}
                <div className="hidden sm:flex items-center gap-1.5 bg-gray-800 border border-gray-700 rounded-lg px-3 py-1.5">
                  <span className="text-xs font-bold text-green-400">LVL</span>
                  <span className="text-white font-semibold text-sm">{user.level}</span>
                </div>

                {/* Profile */}
                <div className="relative">
                  <button
                    onClick={() => setShowProfileMenu(!showProfileMenu)}
                    className="flex items-center gap-2 bg-gray-800 hover:bg-gray-700 border border-gray-700 rounded-lg px-2 py-1 transition-colors"
                  >
                    <AvatarDisplay size="sm" showPet={false} showAura={false} />
                    <span className="text-white text-sm font-medium hidden sm:block">{user.displayName}</span>
                  </button>

                  {showProfileMenu && (
                    <>
                      <div className="fixed inset-0" onClick={() => setShowProfileMenu(false)} />
                      <div className="absolute right-0 top-14 w-64 bg-gray-800 border border-gray-700 rounded-xl shadow-xl overflow-hidden z-50">
                        <div className="p-4 border-b border-gray-700 flex items-center gap-3">
                          <AvatarDisplay size="md" showPet={false} showAura={false} />
                          <div>
                            <p className="text-white font-medium">{user.displayName}</p>
                            <p className="text-gray-400 text-sm">@{user.username}</p>
                            <div className="flex items-center gap-1.5 mt-1">
                              <Coins size={12} className="text-yellow-400" />
                              <span className="text-yellow-400 text-xs font-medium">{user.bloxCoins.toLocaleString()}</span>
                            </div>
                          </div>
                        </div>
                        <button
                          onClick={() => { onNavigate('profile'); setShowProfileMenu(false); }}
                          className="w-full flex items-center gap-3 px-4 py-3 text-gray-300 hover:bg-gray-700 transition-colors text-sm"
                        >
                          <User size={16} /> My Profile
                        </button>
                        <button
                          onClick={() => { onNavigate('friends'); setShowProfileMenu(false); }}
                          className="w-full flex items-center gap-3 px-4 py-3 text-gray-300 hover:bg-gray-700 transition-colors text-sm"
                        >
                          <Users size={16} /> Friends
                          {onlineFriendsCount > 0 && <span className="ml-auto text-green-400 text-xs">{onlineFriendsCount} online</span>}
                        </button>
                        <button
                          onClick={() => { onNavigate('avatar'); setShowProfileMenu(false); }}
                          className="w-full flex items-center gap-3 px-4 py-3 text-gray-300 hover:bg-gray-700 transition-colors text-sm"
                        >
                          <ShoppingBag size={16} /> Avatar Shop
                        </button>
                        <button
                          onClick={() => { logout(); setShowProfileMenu(false); }}
                          className="w-full flex items-center gap-3 px-4 py-3 text-red-400 hover:bg-gray-700 transition-colors text-sm border-t border-gray-700"
                        >
                          <LogOut size={16} /> Log Out
                        </button>
                      </div>
                    </>
                  )}
                </div>
              </>
            ) : (
              <>
                <button
                  onClick={() => onOpenAuth('login')}
                  className="text-gray-300 hover:text-white px-4 py-2 text-sm font-medium rounded-lg hover:bg-gray-800 transition-colors"
                >
                  Log In
                </button>
                <button
                  onClick={() => onOpenAuth('signup')}
                  className="bg-gradient-to-r from-green-500 to-emerald-600 text-white px-4 py-2 text-sm font-semibold rounded-lg hover:from-green-600 hover:to-emerald-700 transition-all shadow-lg shadow-green-500/25"
                >
                  Sign Up
                </button>
              </>
            )}

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setShowMobileMenu(!showMobileMenu)}
              className="md:hidden text-gray-400 hover:text-white p-2"
            >
              {showMobileMenu ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {showMobileMenu && (
        <div className="md:hidden border-t border-gray-800 bg-gray-900 px-4 py-3 space-y-1">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => { onNavigate(item.id); setShowMobileMenu(false); }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all ${
                currentPage === item.id
                  ? 'bg-green-500/15 text-green-400'
                  : 'text-gray-400 hover:text-white hover:bg-gray-800'
              }`}
            >
              <item.icon size={18} />
              {item.label}
              {item.badge && <span className="ml-auto bg-green-500 text-white text-xs px-2 py-0.5 rounded-full">{item.badge}</span>}
            </button>
          ))}
        </div>
      )}
    </nav>
  );
}
