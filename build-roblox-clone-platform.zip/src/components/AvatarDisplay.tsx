import { useAuthStore } from '../store/authStore';
import { getItemById, EquippedAvatar } from '../data/avatarShop';

interface AvatarDisplayProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  equipped?: EquippedAvatar;
  className?: string;
  showPet?: boolean;
  showAura?: boolean;
  animated?: boolean;
}

export default function AvatarDisplay({
  size = 'md',
  equipped,
  className = '',
  showPet = true,
  showAura = true,
  animated = false,
}: AvatarDisplayProps) {
  const { user } = useAuthStore();
  const eq = equipped || user?.equippedAvatar;
  if (!eq) return null;

  const skin = getItemById(eq.skinColor);
  const hat = getItemById(eq.hat);
  const face = getItemById(eq.face);
  const shirt = getItemById(eq.shirt);
  const pants = getItemById(eq.pants);
  const accessory = getItemById(eq.accessory);
  const pet = getItemById(eq.pet);
  const aura = getItemById(eq.aura);

  const dims = {
    sm: { wrapper: 'w-12 h-12', body: 'w-10 h-10', head: 'w-8 h-8', fontSize: 'text-xs', hatSize: 'text-sm', faceSize: 'text-[10px]', accSize: 'text-[8px]', petSize: 'text-sm', auraRing: 'w-14 h-14' },
    md: { wrapper: 'w-20 h-20', body: 'w-16 h-16', head: 'w-12 h-12', fontSize: 'text-sm', hatSize: 'text-lg', faceSize: 'text-sm', accSize: 'text-xs', petSize: 'text-lg', auraRing: 'w-22 h-22' },
    lg: { wrapper: 'w-32 h-32', body: 'w-24 h-24', head: 'w-20 h-20', fontSize: 'text-base', hatSize: 'text-2xl', faceSize: 'text-lg', accSize: 'text-sm', petSize: 'text-2xl', auraRing: 'w-36 h-36' },
    xl: { wrapper: 'w-48 h-48', body: 'w-36 h-36', head: 'w-28 h-28', fontSize: 'text-lg', hatSize: 'text-4xl', faceSize: 'text-2xl', accSize: 'text-lg', petSize: 'text-4xl', auraRing: 'w-52 h-52' },
  }[size];

  const skinColor = skin?.preview || '#10b981';
  const isGradientSkin = skinColor.startsWith('linear');
  const shirtColor = shirt?.preview || '#6b7280';
  const isGradientShirt = shirtColor.startsWith('linear');
  const pantsColor = pants?.preview || '#1d4ed8';
  const isGradientPants = pantsColor.startsWith('linear');
  const auraColor = aura?.preview || '';
  const hasAura = aura && aura.id !== 'aura-none' && showAura;

  return (
    <div className={`relative inline-flex flex-col items-center ${className}`}>
      {/* Aura ring */}
      {hasAura && (
        <div
          className={`absolute inset-0 rounded-full opacity-40 ${animated ? 'animate-pulse' : ''}`}
          style={{
            background: auraColor.startsWith('linear') ? auraColor : undefined,
            backgroundColor: auraColor.startsWith('linear') ? undefined : auraColor,
            filter: 'blur(8px)',
            transform: 'scale(1.3)',
            zIndex: 0,
          }}
        />
      )}

      <div className={`relative ${dims.wrapper} flex flex-col items-center justify-end`} style={{ zIndex: 1 }}>
        {/* Hat */}
        {hat && hat.id !== 'hat-none' && (
          <div
            className={`absolute ${dims.hatSize} leading-none`}
            style={{
              top: size === 'sm' ? '-6px' : size === 'md' ? '-8px' : size === 'lg' ? '-10px' : '-12px',
              zIndex: 10,
            }}
          >
            {hat.emoji}
          </div>
        )}

        {/* Head */}
        <div
          className={`${dims.head} rounded-lg flex items-center justify-center relative`}
          style={{
            background: isGradientSkin ? skinColor : undefined,
            backgroundColor: isGradientSkin ? undefined : skinColor,
            zIndex: 5,
          }}
        >
          {/* Face */}
          <span className={dims.faceSize}>
            {face && face.id !== 'face-default' ? face.emoji : '😊'}
          </span>
        </div>

        {/* Body / Shirt */}
        <div
          className="rounded-b-lg flex items-center justify-center -mt-0.5"
          style={{
            width: size === 'sm' ? '28px' : size === 'md' ? '44px' : size === 'lg' ? '68px' : '100px',
            height: size === 'sm' ? '14px' : size === 'md' ? '22px' : size === 'lg' ? '36px' : '52px',
            background: isGradientShirt ? shirtColor : undefined,
            backgroundColor: isGradientShirt ? undefined : shirtColor,
            zIndex: 4,
          }}
        />

        {/* Pants */}
        <div
          className="rounded-b-lg flex -mt-px"
          style={{
            width: size === 'sm' ? '26px' : size === 'md' ? '40px' : size === 'lg' ? '60px' : '90px',
            height: size === 'sm' ? '8px' : size === 'md' ? '12px' : size === 'lg' ? '20px' : '28px',
            background: isGradientPants ? pantsColor : undefined,
            backgroundColor: isGradientPants ? undefined : pantsColor,
            zIndex: 3,
          }}
        >
          <div className="w-1/2 rounded-bl-lg" style={{ background: isGradientPants ? pantsColor : undefined, backgroundColor: isGradientPants ? undefined : pantsColor }} />
          <div className="w-px bg-black/20" />
          <div className="w-1/2 rounded-br-lg" style={{ background: isGradientPants ? pantsColor : undefined, backgroundColor: isGradientPants ? undefined : pantsColor }} />
        </div>

        {/* Accessory */}
        {accessory && accessory.id !== 'acc-none' && (
          <div
            className={`absolute ${dims.accSize} leading-none`}
            style={{
              right: size === 'sm' ? '-4px' : size === 'md' ? '-6px' : size === 'lg' ? '-10px' : '-14px',
              top: '40%',
              zIndex: 11,
            }}
          >
            {accessory.emoji}
          </div>
        )}
      </div>

      {/* Pet */}
      {pet && pet.id !== 'pet-none' && showPet && (
        <div
          className={`${dims.petSize} leading-none ${animated ? 'animate-bounce' : ''}`}
          style={{ marginTop: '-2px', zIndex: 1 }}
        >
          {pet.emoji}
        </div>
      )}
    </div>
  );
}
