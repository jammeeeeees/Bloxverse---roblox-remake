import { create } from 'zustand';
import { EquippedAvatar, DEFAULT_EQUIPPED, DEFAULT_OWNED, AvatarSlot, getItemById } from '../data/avatarShop';

export interface User {
  id: string;
  username: string;
  displayName: string;
  email: string;
  avatar: string;
  joinDate: string;
  bloxCoins: number;
  level: number;
  xp: number;
  friends: number;
  gamesPlayed: number;
  favoriteGames: string[];
  ownedItems: string[];
  equippedAvatar: EquippedAvatar;
}

interface AuthState {
  user: User | null;
  isLoggedIn: boolean;
  error: string | null;
  login: (username: string, password: string) => boolean;
  signup: (username: string, email: string, password: string, displayName: string) => boolean;
  logout: () => void;
  addCoins: (amount: number) => void;
  addXP: (amount: number) => void;
  incrementGamesPlayed: () => void;
  toggleFavorite: (gameId: string) => void;
  clearError: () => void;
  buyItem: (itemId: string) => { success: boolean; message: string };
  equipItem: (slot: AvatarSlot, itemId: string) => void;
}

const AVATARS = [
  '🧑‍🚀', '🦸‍♂️', '🧙‍♂️', '🦹‍♀️', '🧛', '🤖', '👾', '🎮',
  '🐉', '🦊', '🐺', '🦁', '🐯', '🦄', '🐸', '🐵'
];

const getRandomAvatar = () => AVATARS[Math.floor(Math.random() * AVATARS.length)];

const loadUsers = (): Record<string, { user: User; password: string }> => {
  try {
    const data = localStorage.getItem('bloxverse_users');
    return data ? JSON.parse(data) : {};
  } catch {
    return {};
  }
};

const saveUsers = (users: Record<string, { user: User; password: string }>) => {
  localStorage.setItem('bloxverse_users', JSON.stringify(users));
};

const loadSession = (): User | null => {
  try {
    const data = localStorage.getItem('bloxverse_session');
    if (!data) return null;
    const user = JSON.parse(data);
    // Migrate old users that don't have avatar fields
    if (!user.ownedItems) user.ownedItems = [...DEFAULT_OWNED];
    if (!user.equippedAvatar) user.equippedAvatar = { ...DEFAULT_EQUIPPED };
    return user;
  } catch {
    return null;
  }
};

const saveSession = (user: User | null) => {
  if (user) {
    localStorage.setItem('bloxverse_session', JSON.stringify(user));
  } else {
    localStorage.removeItem('bloxverse_session');
  }
};

const persistUser = (user: User) => {
  saveSession(user);
  const users = loadUsers();
  const key = user.username.toLowerCase();
  if (users[key]) {
    users[key].user = user;
    saveUsers(users);
  }
};

const initialUser = loadSession();

export const useAuthStore = create<AuthState>((set, get) => ({
  user: initialUser,
  isLoggedIn: !!initialUser,
  error: null,

  login: (username: string, password: string) => {
    const users = loadUsers();
    const key = username.toLowerCase();
    if (users[key] && users[key].password === password) {
      const user = { ...users[key].user };
      // Migrate
      if (!user.ownedItems) user.ownedItems = [...DEFAULT_OWNED];
      if (!user.equippedAvatar) user.equippedAvatar = { ...DEFAULT_EQUIPPED };
      set({ user, isLoggedIn: true, error: null });
      saveSession(user);
      return true;
    }
    set({ error: 'Invalid username or password' });
    return false;
  },

  signup: (username: string, email: string, password: string, displayName: string) => {
    const users = loadUsers();
    const key = username.toLowerCase();
    if (users[key]) {
      set({ error: 'Username already taken' });
      return false;
    }
    if (username.length < 3) {
      set({ error: 'Username must be at least 3 characters' });
      return false;
    }
    if (password.length < 4) {
      set({ error: 'Password must be at least 4 characters' });
      return false;
    }
    const newUser: User = {
      id: Date.now().toString(),
      username,
      displayName: displayName || username,
      email,
      avatar: getRandomAvatar(),
      joinDate: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }),
      bloxCoins: 100,
      level: 1,
      xp: 0,
      friends: Math.floor(Math.random() * 10),
      gamesPlayed: 0,
      favoriteGames: [],
      ownedItems: [...DEFAULT_OWNED],
      equippedAvatar: { ...DEFAULT_EQUIPPED },
    };
    users[key] = { user: newUser, password };
    saveUsers(users);
    set({ user: newUser, isLoggedIn: true, error: null });
    saveSession(newUser);
    return true;
  },

  logout: () => {
    set({ user: null, isLoggedIn: false, error: null });
    saveSession(null);
  },

  addCoins: (amount: number) => {
    const { user } = get();
    if (user) {
      const updated = { ...user, bloxCoins: user.bloxCoins + amount };
      set({ user: updated });
      persistUser(updated);
    }
  },

  addXP: (amount: number) => {
    const { user } = get();
    if (user) {
      let newXP = user.xp + amount;
      let newLevel = user.level;
      while (newXP >= newLevel * 100) {
        newXP -= newLevel * 100;
        newLevel++;
      }
      const updated = { ...user, xp: newXP, level: newLevel };
      set({ user: updated });
      persistUser(updated);
    }
  },

  incrementGamesPlayed: () => {
    const { user } = get();
    if (user) {
      const updated = { ...user, gamesPlayed: user.gamesPlayed + 1 };
      set({ user: updated });
      persistUser(updated);
    }
  },

  toggleFavorite: (gameId: string) => {
    const { user } = get();
    if (user) {
      const favs = user.favoriteGames.includes(gameId)
        ? user.favoriteGames.filter(id => id !== gameId)
        : [...user.favoriteGames, gameId];
      const updated = { ...user, favoriteGames: favs };
      set({ user: updated });
      persistUser(updated);
    }
  },

  buyItem: (itemId: string) => {
    const { user } = get();
    if (!user) return { success: false, message: 'Not logged in' };

    if (user.ownedItems.includes(itemId)) {
      return { success: false, message: 'You already own this item!' };
    }

    const item = getItemById(itemId);
    if (!item) return { success: false, message: 'Item not found' };

    if (user.bloxCoins < item.price) {
      return { success: false, message: `Not enough BloxCoins! You need ${item.price - user.bloxCoins} more.` };
    }

    const updated = {
      ...user,
      bloxCoins: user.bloxCoins - item.price,
      ownedItems: [...user.ownedItems, itemId],
    };
    set({ user: updated });
    persistUser(updated);
    return { success: true, message: `Purchased ${item.name}!` };
  },

  equipItem: (slot: AvatarSlot, itemId: string) => {
    const { user } = get();
    if (!user) return;
    if (!user.ownedItems.includes(itemId)) return;

    const updated = {
      ...user,
      equippedAvatar: { ...user.equippedAvatar, [slot]: itemId },
    };
    set({ user: updated });
    persistUser(updated);
  },

  clearError: () => set({ error: null }),
}));
