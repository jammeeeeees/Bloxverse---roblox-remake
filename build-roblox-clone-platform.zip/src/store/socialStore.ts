import { create } from 'zustand';
import { EquippedAvatar, DEFAULT_EQUIPPED } from '../data/avatarShop';

export interface Player {
  id: string;
  username: string;
  displayName: string;
  avatar: EquippedAvatar;
  level: number;
  status: 'online' | 'in-game' | 'offline';
  currentGame?: string;
}

export interface FriendRequest {
  id: string;
  from: Player;
  timestamp: number;
}

export interface ChatMessage {
  id: string;
  from: string;
  content: string;
  timestamp: number;
  type: 'user' | 'system' | 'game';
}

export interface GameLobby {
  id: string;
  gameId: string;
  host: Player;
  players: Player[];
  maxPlayers: number;
  status: 'waiting' | 'starting' | 'in-progress';
  isPublic: boolean;
}

// Simulated online players (AI)
const AI_PLAYERS: Player[] = [
  { id: 'ai1', username: 'NightHunter', displayName: 'NightHunter', avatar: { ...DEFAULT_EQUIPPED, skinColor: 'skin-purple', hat: 'hat-devil', face: 'face-angry', shirt: 'shirt-armor', aura: 'aura-shadow' }, level: 28, status: 'online' },
  { id: 'ai2', username: 'StarGazer', displayName: 'StarGazer', avatar: { ...DEFAULT_EQUIPPED, skinColor: 'skin-blue', hat: 'hat-wizard', face: 'face-star', shirt: 'shirt-galaxy', pet: 'pet-unicorn', aura: 'aura-rainbow' }, level: 42, status: 'in-game', currentGame: 'Horror Maze' },
  { id: 'ai3', username: 'BloxKing', displayName: 'BloxKing', avatar: { ...DEFAULT_EQUIPPED, skinColor: 'skin-gold', hat: 'hat-crown', face: 'face-cool', shirt: 'shirt-suit', accessory: 'acc-chain', aura: 'aura-divine' }, level: 67, status: 'online' },
  { id: 'ai4', username: 'ShadowNinja', displayName: 'ShadowNinja', avatar: { ...DEFAULT_EQUIPPED, skinColor: 'skin-black', hat: 'hat-none', face: 'face-robot', shirt: 'shirt-hoodie', pet: 'pet-dragon', aura: 'aura-fire' }, level: 35, status: 'in-game', currentGame: 'Battle Arena' },
  { id: 'ai5', username: 'CuteKitty', displayName: 'CuteKitty', avatar: { ...DEFAULT_EQUIPPED, skinColor: 'skin-pink', hat: 'hat-halo', face: 'face-wink', shirt: 'shirt-default', pet: 'pet-cat', aura: 'aura-none' }, level: 15, status: 'online' },
  { id: 'ai6', username: 'FireStorm', displayName: 'FireStorm', avatar: { ...DEFAULT_EQUIPPED, skinColor: 'skin-red', hat: 'hat-helmet', face: 'face-angry', shirt: 'shirt-fire', accessory: 'acc-sword', aura: 'aura-fire' }, level: 51, status: 'online' },
  { id: 'ai7', username: 'IceQueen', displayName: 'IceQueen', avatar: { ...DEFAULT_EQUIPPED, skinColor: 'skin-blue', hat: 'hat-crown', face: 'face-cool', shirt: 'shirt-default', pet: 'pet-fox', aura: 'aura-ice' }, level: 44, status: 'offline' },
  { id: 'ai8', username: 'GhostRider', displayName: 'GhostRider', avatar: { ...DEFAULT_EQUIPPED, skinColor: 'skin-default', hat: 'hat-cowboy', face: 'face-ghost', shirt: 'shirt-hoodie', pet: 'pet-phoenix', aura: 'aura-shadow' }, level: 38, status: 'online' },
];

const AI_CHAT_RESPONSES = [
  "GG! That was fun!",
  "Let's play again!",
  "Nice move!",
  "I almost got you there 😂",
  "Who wants to join horror maze?",
  "Anyone up for Battle Arena?",
  "Just hit level up! 🎉",
  "That was intense!",
  "Good game everyone!",
  "brb getting snacks",
  "Let's team up!",
  "Watch out behind you!",
  "I need backup!",
  "Victory! 🏆",
];

interface SocialState {
  friends: Player[];
  friendRequests: FriendRequest[];
  onlinePlayers: Player[];
  lobbies: GameLobby[];
  currentLobby: GameLobby | null;
  globalChat: ChatMessage[];
  lobbyChat: ChatMessage[];
  
  // Actions
  sendFriendRequest: (username: string) => { success: boolean; message: string };
  acceptFriendRequest: (requestId: string) => void;
  declineFriendRequest: (requestId: string) => void;
  removeFriend: (friendId: string) => void;
  
  createLobby: (gameId: string, maxPlayers: number, isPublic: boolean, host: Player) => GameLobby;
  joinLobby: (lobbyId: string, player: Player) => { success: boolean; message: string };
  leaveLobby: (playerId: string) => void;
  startGame: (lobbyId: string) => void;
  
  sendGlobalMessage: (from: string, content: string) => void;
  sendLobbyMessage: (from: string, content: string) => void;
  
  getRandomPlayers: (count: number, excludeIds?: string[]) => Player[];
  simulateAIActivity: () => void;
}

const loadFriends = (): Player[] => {
  try {
    const data = localStorage.getItem('bloxverse_friends');
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
};

const saveFriends = (friends: Player[]) => {
  localStorage.setItem('bloxverse_friends', JSON.stringify(friends));
};

export const useSocialStore = create<SocialState>((set, get) => ({
  friends: loadFriends(),
  friendRequests: [],
  onlinePlayers: AI_PLAYERS.filter(p => p.status !== 'offline'),
  lobbies: [],
  currentLobby: null,
  globalChat: [
    { id: '1', from: 'System', content: 'Welcome to Bloxverse! 🎮', timestamp: Date.now() - 60000, type: 'system' },
    { id: '2', from: 'BloxKing', content: 'Anyone want to play Horror Maze?', timestamp: Date.now() - 45000, type: 'user' },
    { id: '3', from: 'StarGazer', content: 'Sure! Creating lobby now', timestamp: Date.now() - 30000, type: 'user' },
  ],
  lobbyChat: [],

  sendFriendRequest: (username: string) => {
    const { friends, onlinePlayers } = get();
    const target = [...AI_PLAYERS, ...onlinePlayers].find(
      p => p.username.toLowerCase() === username.toLowerCase()
    );
    
    if (!target) {
      return { success: false, message: 'Player not found' };
    }
    
    if (friends.some(f => f.id === target.id)) {
      return { success: false, message: 'Already friends!' };
    }
    
    // Simulate instant accept for AI players
    const newFriends = [...friends, target];
    set({ friends: newFriends });
    saveFriends(newFriends);
    
    return { success: true, message: `${target.displayName} is now your friend!` };
  },

  acceptFriendRequest: (requestId: string) => {
    const { friendRequests, friends } = get();
    const request = friendRequests.find(r => r.id === requestId);
    if (request) {
      const newFriends = [...friends, request.from];
      set({
        friends: newFriends,
        friendRequests: friendRequests.filter(r => r.id !== requestId),
      });
      saveFriends(newFriends);
    }
  },

  declineFriendRequest: (requestId: string) => {
    set(state => ({
      friendRequests: state.friendRequests.filter(r => r.id !== requestId),
    }));
  },

  removeFriend: (friendId: string) => {
    const newFriends = get().friends.filter(f => f.id !== friendId);
    set({ friends: newFriends });
    saveFriends(newFriends);
  },

  createLobby: (gameId: string, maxPlayers: number, isPublic: boolean, host: Player) => {
    const lobby: GameLobby = {
      id: `lobby_${Date.now()}`,
      gameId,
      host,
      players: [host],
      maxPlayers,
      status: 'waiting',
      isPublic,
    };
    set(state => ({
      lobbies: [...state.lobbies, lobby],
      currentLobby: lobby,
      lobbyChat: [{ id: '1', from: 'System', content: `${host.displayName} created the lobby`, timestamp: Date.now(), type: 'system' }],
    }));
    
    // Simulate AI players joining public lobbies
    if (isPublic) {
      setTimeout(() => {
        const { currentLobby, getRandomPlayers } = get();
        if (currentLobby && currentLobby.players.length < currentLobby.maxPlayers) {
          const aiPlayers = getRandomPlayers(Math.min(2, currentLobby.maxPlayers - 1), [host.id]);
          if (aiPlayers.length > 0) {
            const player = aiPlayers[0];
            set(state => {
              if (!state.currentLobby) return state;
              return {
                currentLobby: {
                  ...state.currentLobby,
                  players: [...state.currentLobby.players, player],
                },
                lobbyChat: [...state.lobbyChat, { id: Date.now().toString(), from: 'System', content: `${player.displayName} joined the lobby`, timestamp: Date.now(), type: 'system' }],
              };
            });
          }
        }
      }, 2000 + Math.random() * 3000);
    }
    
    return lobby;
  },

  joinLobby: (lobbyId: string, player: Player) => {
    const { lobbies } = get();
    const lobby = lobbies.find(l => l.id === lobbyId);
    
    if (!lobby) return { success: false, message: 'Lobby not found' };
    if (lobby.players.length >= lobby.maxPlayers) return { success: false, message: 'Lobby is full' };
    if (lobby.status !== 'waiting') return { success: false, message: 'Game already started' };
    
    const updatedLobby = { ...lobby, players: [...lobby.players, player] };
    set(state => ({
      lobbies: state.lobbies.map(l => l.id === lobbyId ? updatedLobby : l),
      currentLobby: updatedLobby,
      lobbyChat: [...state.lobbyChat, { id: Date.now().toString(), from: 'System', content: `${player.displayName} joined`, timestamp: Date.now(), type: 'system' }],
    }));
    
    return { success: true, message: 'Joined lobby!' };
  },

  leaveLobby: (playerId: string) => {
    set(state => {
      if (!state.currentLobby) return state;
      const player = state.currentLobby.players.find(p => p.id === playerId);
      const updatedPlayers = state.currentLobby.players.filter(p => p.id !== playerId);
      
      if (updatedPlayers.length === 0) {
        return {
          currentLobby: null,
          lobbies: state.lobbies.filter(l => l.id !== state.currentLobby!.id),
          lobbyChat: [],
        };
      }
      
      return {
        currentLobby: { ...state.currentLobby, players: updatedPlayers },
        lobbyChat: [...state.lobbyChat, { id: Date.now().toString(), from: 'System', content: `${player?.displayName || 'Player'} left`, timestamp: Date.now(), type: 'system' }],
      };
    });
  },

  startGame: (lobbyId: string) => {
    set(state => {
      const lobby = state.lobbies.find(l => l.id === lobbyId);
      if (!lobby) return state;
      return {
        lobbies: state.lobbies.map(l => l.id === lobbyId ? { ...l, status: 'in-progress' as const } : l),
        currentLobby: state.currentLobby?.id === lobbyId ? { ...state.currentLobby, status: 'in-progress' as const } : state.currentLobby,
      };
    });
  },

  sendGlobalMessage: (from: string, content: string) => {
    const msg: ChatMessage = {
      id: Date.now().toString(),
      from,
      content,
      timestamp: Date.now(),
      type: 'user',
    };
    set(state => ({
      globalChat: [...state.globalChat.slice(-50), msg],
    }));
    
    // Simulate AI response
    if (Math.random() < 0.3) {
      setTimeout(() => {
        const aiPlayer = AI_PLAYERS[Math.floor(Math.random() * AI_PLAYERS.length)];
        const response = AI_CHAT_RESPONSES[Math.floor(Math.random() * AI_CHAT_RESPONSES.length)];
        const aiMsg: ChatMessage = {
          id: Date.now().toString(),
          from: aiPlayer.displayName,
          content: response,
          timestamp: Date.now(),
          type: 'user',
        };
        set(state => ({
          globalChat: [...state.globalChat.slice(-50), aiMsg],
        }));
      }, 1500 + Math.random() * 3000);
    }
  },

  sendLobbyMessage: (from: string, content: string) => {
    const msg: ChatMessage = {
      id: Date.now().toString(),
      from,
      content,
      timestamp: Date.now(),
      type: 'user',
    };
    set(state => ({
      lobbyChat: [...state.lobbyChat.slice(-50), msg],
    }));
  },

  getRandomPlayers: (count: number, excludeIds: string[] = []) => {
    const available = AI_PLAYERS.filter(p => !excludeIds.includes(p.id) && p.status !== 'offline');
    const shuffled = available.sort(() => Math.random() - 0.5);
    return shuffled.slice(0, count);
  },

  simulateAIActivity: () => {
    // Randomly change AI player statuses
    set(() => ({
      onlinePlayers: AI_PLAYERS.map(p => ({
        ...p,
        status: Math.random() < 0.1 ? (Math.random() < 0.5 ? 'in-game' : 'online') as Player['status'] : p.status,
      })).filter(p => p.status !== 'offline'),
    }));
  },
}));
