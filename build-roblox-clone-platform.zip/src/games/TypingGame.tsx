import { useState, useEffect, useRef, useCallback } from 'react';
import { useAuthStore } from '../store/authStore';

const WORD_LISTS = {
  easy: ['cat', 'dog', 'run', 'fun', 'sun', 'red', 'big', 'hot', 'top', 'map', 'cup', 'hat', 'box', 'fly', 'key', 'sky', 'day', 'boy', 'toy', 'car'],
  medium: ['block', 'pixel', 'world', 'chest', 'sword', 'magic', 'stone', 'light', 'crown', 'tower', 'flame', 'mount', 'cloud', 'storm', 'river', 'power', 'royal', 'brave', 'dream', 'quest'],
  hard: ['adventure', 'dimension', 'explosion', 'legendary', 'mysterious', 'transport', 'challenge', 'beautiful', 'dangerous', 'wonderful', 'fantastic', 'elemental', 'simulator', 'construct', 'butterfly'],
};

interface FallingWord {
  id: number;
  word: string;
  x: number;
  y: number;
  speed: number;
  color: string;
}

const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

export default function TypingGame({ onExit }: { onExit: () => void }) {
  const { addCoins, addXP, incrementGamesPlayed, isLoggedIn } = useAuthStore();
  const [, setWords] = useState<FallingWord[]>([]);
  const [input, setInput] = useState('');
  const [score, setScore] = useState(0);
  const [, setLives] = useState(5);
  const [gameOver, setGameOver] = useState(false);
  const [started, setStarted] = useState(false);
  const [combo, setCombo] = useState(0);
  const [maxCombo, setMaxCombo] = useState(0);
  const [wordsTyped, setWordsTyped] = useState(0);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const nextId = useRef(0);
  const gameRef = useRef({ words: [] as FallingWord[], lives: 5, score: 0, animFrame: 0, spawnTimer: 0 });

  const spawnWord = useCallback(() => {
    const difficulty = gameRef.current.score < 50 ? 'easy' : gameRef.current.score < 150 ? 'medium' : 'hard';
    const list = WORD_LISTS[difficulty];
    const word = list[Math.floor(Math.random() * list.length)];
    const id = nextId.current++;
    return {
      id,
      word,
      x: Math.random() * 340 + 30,
      y: -20,
      speed: 0.3 + Math.random() * 0.3 + gameRef.current.score * 0.002,
      color: COLORS[Math.floor(Math.random() * COLORS.length)],
    };
  }, []);

  const startGame = useCallback(() => {
    const initial: FallingWord[] = [];
    for (let i = 0; i < 2; i++) {
      nextId.current = i;
      const w = spawnWord();
      w.y = Math.random() * 100;
      initial.push(w);
    }
    gameRef.current = { words: initial, lives: 5, score: 0, animFrame: 0, spawnTimer: 0 };
    setWords(initial);
    setInput('');
    setScore(0);
    setLives(5);
    setGameOver(false);
    setStarted(true);
    setCombo(0);
    setMaxCombo(0);
    setWordsTyped(0);
    inputRef.current?.focus();
  }, [spawnWord]);

  useEffect(() => {
    if (!started || gameOver) return;

    let running = true;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const loop = () => {
      if (!running) return;
      const g = gameRef.current;
      g.animFrame++;

      // Spawn
      g.spawnTimer++;
      const spawnRate = Math.max(60, 120 - g.score);
      if (g.spawnTimer >= spawnRate) {
        g.spawnTimer = 0;
        g.words.push(spawnWord());
        setWords([...g.words]);
      }

      // Move words
      let lostLife = false;
      g.words = g.words.filter(w => {
        w.y += w.speed;
        if (w.y > canvas.height) {
          g.lives--;
          lostLife = true;
          setLives(g.lives);
          if (g.lives <= 0) {
            running = false;
            setGameOver(true);
            if (isLoggedIn) {
              addCoins(Math.floor(g.score / 2));
              addXP(Math.floor(g.score / 3));
              incrementGamesPlayed();
            }
          }
          return false;
        }
        return true;
      });

      if (lostLife) {
        setCombo(0);
        setWords([...g.words]);
      }

      // Draw
      ctx.fillStyle = '#1a1a2e';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Danger zone
      ctx.fillStyle = 'rgba(239, 68, 68, 0.1)';
      ctx.fillRect(0, canvas.height - 40, canvas.width, 40);
      ctx.strokeStyle = 'rgba(239, 68, 68, 0.3)';
      ctx.setLineDash([5, 5]);
      ctx.beginPath();
      ctx.moveTo(0, canvas.height - 40);
      ctx.lineTo(canvas.width, canvas.height - 40);
      ctx.stroke();
      ctx.setLineDash([]);

      // Words
      for (const w of g.words) {
        ctx.font = 'bold 18px monospace';
        ctx.shadowColor = w.color;
        ctx.shadowBlur = 8;
        ctx.fillStyle = w.color;

        const metrics = ctx.measureText(w.word);
        const padding = 12;
        const boxW = metrics.width + padding * 2;
        const boxH = 32;
        const bx = w.x - boxW / 2;
        const by = w.y - boxH / 2;

        ctx.fillStyle = 'rgba(0,0,0,0.5)';
        ctx.beginPath();
        ctx.roundRect(bx, by, boxW, boxH, 8);
        ctx.fill();

        ctx.strokeStyle = w.color;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.roundRect(bx, by, boxW, boxH, 8);
        ctx.stroke();

        ctx.fillStyle = w.color;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(w.word, w.x, w.y);
        ctx.shadowBlur = 0;
      }

      // Lives
      ctx.font = '14px sans-serif';
      ctx.fillStyle = '#ef4444';
      ctx.textAlign = 'left';
      ctx.textBaseline = 'top';
      ctx.fillText('❤️'.repeat(g.lives), 10, 10);

      requestAnimationFrame(loop);
    };

    loop();
    return () => { running = false; };
  }, [started, gameOver, spawnWord, isLoggedIn, addCoins, addXP, incrementGamesPlayed]);

  const handleInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.toLowerCase();
    setInput(val);

    const g = gameRef.current;
    const matchIdx = g.words.findIndex(w => w.word === val);
    if (matchIdx !== -1) {
      g.words.splice(matchIdx, 1);
      const points = val.length * 5;
      g.score += points;
      setScore(g.score);
      setWords([...g.words]);
      setInput('');
      setWordsTyped(w => w + 1);
      setCombo(c => {
        const newCombo = c + 1;
        setMaxCombo(mc => Math.max(mc, newCombo));
        return newCombo;
      });
    }
  };

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="flex items-center justify-between w-full max-w-lg">
        <div>
          <div className="text-white font-bold text-lg">⌨️ Score: {score}</div>
          {combo > 1 && <span className="text-yellow-400 text-sm font-bold">🔥 x{combo} combo!</span>}
        </div>
        <button onClick={onExit} className="text-gray-400 hover:text-white text-sm px-3 py-1 bg-gray-800 rounded-lg border border-gray-700">
          Exit Game
        </button>
      </div>

      <div className="relative rounded-xl overflow-hidden border-2 border-gray-700 shadow-2xl">
        <canvas ref={canvasRef} width={420} height={450} />

        {!started && (
          <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center">
            <h2 className="text-3xl font-bold text-white mb-2">⌨️ Type Racer</h2>
            <p className="text-gray-300 mb-2">Type the falling words before they reach the bottom!</p>
            <p className="text-yellow-400 text-sm mb-6">Longer words = more points! Build combos for bonus!</p>
            <button onClick={startGame} className="bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold px-8 py-3 rounded-xl hover:from-green-600 hover:to-emerald-700 transition-all shadow-lg">
              Start Game
            </button>
          </div>
        )}

        {gameOver && (
          <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center">
            <h2 className="text-3xl font-bold text-white mb-2">Game Over!</h2>
            <p className="text-2xl text-yellow-400 font-bold mb-1">Score: {score}</p>
            <p className="text-gray-400 text-sm">{wordsTyped} words typed • Max combo: x{maxCombo}</p>
            {isLoggedIn && (
              <p className="text-green-400 text-sm mt-2 mb-4">+{Math.floor(score / 2)} coins, +{Math.floor(score / 3)} XP</p>
            )}
            <div className="flex gap-3">
              <button onClick={startGame} className="bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold px-6 py-3 rounded-xl hover:from-green-600 hover:to-emerald-700 transition-all shadow-lg">
                Play Again
              </button>
              <button onClick={onExit} className="bg-gray-700 text-white font-bold px-6 py-3 rounded-xl hover:bg-gray-600 transition-all">
                Exit
              </button>
            </div>
          </div>
        )}
      </div>

      {started && !gameOver && (
        <input
          ref={inputRef}
          type="text"
          value={input}
          onChange={handleInput}
          autoFocus
          placeholder="Type the words..."
          className="w-full max-w-lg bg-gray-800 border-2 border-gray-600 focus:border-green-500 rounded-xl px-6 py-3 text-white text-lg font-mono text-center placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-green-500/30"
        />
      )}
    </div>
  );
}
