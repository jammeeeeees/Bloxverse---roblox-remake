import { useState, useEffect, useCallback, useRef } from 'react';
import { useAuthStore } from '../store/authStore';
import { useSocialStore } from '../store/socialStore';
import AvatarDisplay from '../components/AvatarDisplay';

interface Position {
  x: number;
  y: number;
}

interface Player {
  id: string;
  name: string;
  pos: Position;
  avatar: any;
  alive: boolean;
}

const MAZE_SIZE = 15;
const CELL_SIZE = 32;

// Generate a simple maze
const generateMaze = (): number[][] => {
  const maze: number[][] = [];
  for (let y = 0; y < MAZE_SIZE; y++) {
    maze[y] = [];
    for (let x = 0; x < MAZE_SIZE; x++) {
      // Border walls
      if (x === 0 || y === 0 || x === MAZE_SIZE - 1 || y === MAZE_SIZE - 1) {
        maze[y][x] = 1;
      } else if (Math.random() < 0.25 && !(x < 3 && y < 3) && !(x > MAZE_SIZE - 4 && y > MAZE_SIZE - 4)) {
        maze[y][x] = 1;
      } else {
        maze[y][x] = 0;
      }
    }
  }
  // Ensure start and exit are clear
  maze[1][1] = 0;
  maze[1][2] = 0;
  maze[2][1] = 0;
  maze[MAZE_SIZE - 2][MAZE_SIZE - 2] = 2; // Exit
  maze[MAZE_SIZE - 2][MAZE_SIZE - 3] = 0;
  maze[MAZE_SIZE - 3][MAZE_SIZE - 2] = 0;
  return maze;
};

export default function HorrorMazeGame({ onExit }: { onExit: () => void }) {
  const { user, addCoins, addXP, incrementGamesPlayed, isLoggedIn } = useAuthStore();
  const { currentLobby, getRandomPlayers } = useSocialStore();
  
  const [maze, setMaze] = useState<number[][]>([]);
  const [players, setPlayers] = useState<Player[]>([]);
  const [monster, setMonster] = useState<Position>({ x: MAZE_SIZE - 2, y: 1 });
  const [gameOver, setGameOver] = useState(false);
  const [won, setWon] = useState(false);
  const [started, setStarted] = useState(false);
  const [darkness, setDarkness] = useState(3); // Vision radius
  const [scary, setScary] = useState(false);
  const [timer, setTimer] = useState(60);
  const gameRef = useRef({ monster: { x: MAZE_SIZE - 2, y: 1 }, tick: 0 });
  const keysRef = useRef<Set<string>>(new Set());

  const startGame = useCallback(() => {
    const newMaze = generateMaze();
    setMaze(newMaze);
    
    // Create players from lobby or AI
    const initialPlayers: Player[] = [];
    if (user) {
      initialPlayers.push({
        id: user.id,
        name: user.displayName,
        pos: { x: 1, y: 1 },
        avatar: user.equippedAvatar,
        alive: true,
      });
    }
    
    // Add AI players
    const aiPlayers = currentLobby?.players.filter(p => p.id !== user?.id) || getRandomPlayers(2, user ? [user.id] : []);
    aiPlayers.forEach((p, i) => {
      initialPlayers.push({
        id: p.id,
        name: p.displayName,
        pos: { x: 2 + i, y: 1 },
        avatar: p.avatar,
        alive: true,
      });
    });
    
    setPlayers(initialPlayers);
    setMonster({ x: MAZE_SIZE - 2, y: 1 });
    gameRef.current = { monster: { x: MAZE_SIZE - 2, y: 1 }, tick: 0 };
    setGameOver(false);
    setWon(false);
    setStarted(true);
    setTimer(60);
    setDarkness(3);
  }, [user, currentLobby, getRandomPlayers]);

  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => keysRef.current.add(e.key.toLowerCase());
    const handleKeyUp = (e: KeyboardEvent) => keysRef.current.delete(e.key.toLowerCase());
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  // Game loop
  useEffect(() => {
    if (!started || gameOver) return;

    const interval = setInterval(() => {
      gameRef.current.tick++;
      
      // Move player
      setPlayers(prev => {
        const playerIdx = prev.findIndex(p => p.id === user?.id);
        if (playerIdx === -1 || !prev[playerIdx].alive) return prev;
        
        const newPlayers = [...prev];
        const player = { ...newPlayers[playerIdx] };
        let newX = player.pos.x;
        let newY = player.pos.y;
        
        if (keysRef.current.has('w') || keysRef.current.has('arrowup')) newY--;
        if (keysRef.current.has('s') || keysRef.current.has('arrowdown')) newY++;
        if (keysRef.current.has('a') || keysRef.current.has('arrowleft')) newX--;
        if (keysRef.current.has('d') || keysRef.current.has('arrowright')) newX++;
        
        if (newX >= 0 && newX < MAZE_SIZE && newY >= 0 && newY < MAZE_SIZE && maze[newY]?.[newX] !== 1) {
          player.pos = { x: newX, y: newY };
          
          // Check exit
          if (maze[newY][newX] === 2) {
            setWon(true);
            setGameOver(true);
            if (isLoggedIn) {
              addCoins(100 + timer * 2);
              addXP(50 + timer);
              incrementGamesPlayed();
            }
          }
        }
        
        newPlayers[playerIdx] = player;
        return newPlayers;
      });
      
      // Move AI players toward exit
      setPlayers(prev => {
        return prev.map(p => {
          if (p.id === user?.id || !p.alive) return p;
          if (Math.random() < 0.3) {
            const dx = (MAZE_SIZE - 2) - p.pos.x;
            const dy = (MAZE_SIZE - 2) - p.pos.y;
            let newX = p.pos.x + (dx > 0 ? 1 : dx < 0 ? -1 : 0);
            let newY = p.pos.y + (dy > 0 ? 1 : dy < 0 ? -1 : 0);
            if (Math.random() < 0.3) {
              newX = p.pos.x + Math.floor(Math.random() * 3) - 1;
              newY = p.pos.y + Math.floor(Math.random() * 3) - 1;
            }
            if (newX >= 0 && newX < MAZE_SIZE && newY >= 0 && newY < MAZE_SIZE && maze[newY]?.[newX] !== 1) {
              return { ...p, pos: { x: newX, y: newY } };
            }
          }
          return p;
        });
      });
      
      // Move monster
      if (gameRef.current.tick % 3 === 0) {
        setMonster(prev => {
          const playerPos = players.find(p => p.id === user?.id && p.alive)?.pos;
          if (!playerPos) return prev;
          
          const dx = playerPos.x - prev.x;
          const dy = playerPos.y - prev.y;
          let newX = prev.x + (dx > 0 ? 1 : dx < 0 ? -1 : 0);
          let newY = prev.y + (dy > 0 ? 1 : dy < 0 ? -1 : 0);
          
          // Add some randomness
          if (Math.random() < 0.3) {
            newX = prev.x + Math.floor(Math.random() * 3) - 1;
            newY = prev.y + Math.floor(Math.random() * 3) - 1;
          }
          
          if (newX >= 0 && newX < MAZE_SIZE && newY >= 0 && newY < MAZE_SIZE && maze[newY]?.[newX] !== 1) {
            gameRef.current.monster = { x: newX, y: newY };
            
            // Check if monster caught any player
            setPlayers(ps => ps.map(p => {
              if (p.alive && p.pos.x === newX && p.pos.y === newY) {
                if (p.id === user?.id) {
                  setGameOver(true);
                  setWon(false);
                  if (isLoggedIn) {
                    addCoins(10);
                    addXP(5);
                    incrementGamesPlayed();
                  }
                }
                return { ...p, alive: false };
              }
              return p;
            }));
            
            return { x: newX, y: newY };
          }
          return prev;
        });
      }
      
      // Random scary effect
      if (Math.random() < 0.02) {
        setScary(true);
        setTimeout(() => setScary(false), 200);
      }
      
    }, 150);

    return () => clearInterval(interval);
  }, [started, gameOver, maze, players, user, isLoggedIn, addCoins, addXP, incrementGamesPlayed, timer]);

  // Timer
  useEffect(() => {
    if (!started || gameOver) return;
    const interval = setInterval(() => {
      setTimer(t => {
        if (t <= 1) {
          setGameOver(true);
          setWon(false);
          return 0;
        }
        // Reduce vision as time runs out
        if (t === 30) setDarkness(2.5);
        if (t === 15) setDarkness(2);
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [started, gameOver]);

  const playerMe = players.find(p => p.id === user?.id);
  const viewCenterX = playerMe?.pos.x ?? MAZE_SIZE / 2;
  const viewCenterY = playerMe?.pos.y ?? MAZE_SIZE / 2;

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="flex items-center justify-between w-full max-w-lg">
        <div>
          <div className="text-white font-bold text-lg">👻 Horror Maze</div>
          {started && !gameOver && <div className="text-red-400 text-sm">⏱️ {timer}s remaining</div>}
        </div>
        <button onClick={onExit} className="text-gray-400 hover:text-white text-sm px-3 py-1 bg-gray-800 rounded-lg border border-gray-700">
          Exit Game
        </button>
      </div>

      <div
        className={`relative rounded-xl overflow-hidden border-2 border-gray-700 shadow-2xl ${scary ? 'animate-pulse' : ''}`}
        style={{ 
          width: MAZE_SIZE * CELL_SIZE, 
          height: MAZE_SIZE * CELL_SIZE,
          background: '#0a0a0a',
        }}
      >
        {/* Maze */}
        {started && maze.length > 0 && (
          <div className="relative w-full h-full">
            {maze.map((row, y) =>
              row.map((cell, x) => {
                const dist = Math.sqrt(Math.pow(x - viewCenterX, 2) + Math.pow(y - viewCenterY, 2));
                const visible = dist <= darkness || gameOver;
                const opacity = visible ? Math.max(0.3, 1 - dist / (darkness + 1)) : 0;
                
                return (
                  <div
                    key={`${x}-${y}`}
                    className="absolute transition-opacity duration-300"
                    style={{
                      left: x * CELL_SIZE,
                      top: y * CELL_SIZE,
                      width: CELL_SIZE,
                      height: CELL_SIZE,
                      opacity,
                      background: cell === 1 ? '#1a1a2e' : cell === 2 ? '#22c55e' : '#0f0f1a',
                      border: cell === 1 ? '1px solid #2a2a4e' : 'none',
                      boxShadow: cell === 2 ? '0 0 20px #22c55e' : 'none',
                    }}
                  >
                    {cell === 2 && <span className="flex items-center justify-center h-full text-lg">🚪</span>}
                  </div>
                );
              })
            )}

            {/* Players */}
            {players.map(player => {
              const dist = Math.sqrt(Math.pow(player.pos.x - viewCenterX, 2) + Math.pow(player.pos.y - viewCenterY, 2));
              const visible = dist <= darkness + 1 || player.id === user?.id;
              if (!visible || !player.alive) return null;
              
              return (
                <div
                  key={player.id}
                  className="absolute transition-all duration-150 flex flex-col items-center"
                  style={{
                    left: player.pos.x * CELL_SIZE,
                    top: player.pos.y * CELL_SIZE,
                    width: CELL_SIZE,
                    height: CELL_SIZE,
                  }}
                >
                  <div className="scale-50 -mt-2">
                    <AvatarDisplay size="sm" equipped={player.avatar} showPet={false} showAura={false} />
                  </div>
                  <span className="text-[8px] text-white font-bold truncate max-w-8">{player.name.slice(0, 5)}</span>
                </div>
              );
            })}

            {/* Monster */}
            {(() => {
              const dist = Math.sqrt(Math.pow(monster.x - viewCenterX, 2) + Math.pow(monster.y - viewCenterY, 2));
              const visible = dist <= darkness + 0.5;
              if (!visible && !gameOver) return null;
              
              return (
                <div
                  className="absolute transition-all duration-300 flex items-center justify-center text-3xl"
                  style={{
                    left: monster.x * CELL_SIZE,
                    top: monster.y * CELL_SIZE,
                    width: CELL_SIZE,
                    height: CELL_SIZE,
                    filter: 'drop-shadow(0 0 10px red)',
                  }}
                >
                  👹
                </div>
              );
            })()}

            {/* Darkness overlay */}
            <div
              className="absolute inset-0 pointer-events-none"
              style={{
                background: `radial-gradient(circle at ${viewCenterX * CELL_SIZE + CELL_SIZE / 2}px ${viewCenterY * CELL_SIZE + CELL_SIZE / 2}px, transparent 0%, transparent ${darkness * CELL_SIZE}px, rgba(0,0,0,0.95) ${(darkness + 2) * CELL_SIZE}px)`,
              }}
            />
          </div>
        )}

        {/* Start screen */}
        {!started && (
          <div className="absolute inset-0 bg-black/90 flex flex-col items-center justify-center">
            <div className="text-6xl mb-4">👻</div>
            <h2 className="text-2xl font-bold text-white mb-2">Horror Maze</h2>
            <p className="text-gray-400 text-center mb-2 max-w-xs">
              Navigate the dark maze and find the exit before the monster catches you!
            </p>
            <p className="text-red-400 text-sm mb-4">Your vision fades as time runs out...</p>
            <div className="flex flex-wrap gap-2 justify-center mb-4">
              {players.length > 0 ? players.map(p => (
                <div key={p.id} className="bg-gray-800 rounded-lg px-3 py-1 flex items-center gap-2">
                  <span className="text-lg">👤</span>
                  <span className="text-white text-sm">{p.name}</span>
                </div>
              )) : (
                <p className="text-gray-500 text-sm">Waiting for players...</p>
              )}
            </div>
            <button
              onClick={startGame}
              className="bg-gradient-to-r from-red-600 to-red-800 text-white font-bold px-8 py-3 rounded-xl hover:from-red-700 hover:to-red-900 transition-all shadow-lg"
            >
              Enter the Maze 💀
            </button>
          </div>
        )}

        {/* Game over */}
        {gameOver && (
          <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center">
            {won ? (
              <>
                <div className="text-6xl mb-4">🎉</div>
                <h2 className="text-2xl font-bold text-green-400 mb-2">You Escaped!</h2>
                <p className="text-gray-400 mb-1">{timer} seconds remaining</p>
              </>
            ) : (
              <>
                <div className="text-6xl mb-4">💀</div>
                <h2 className="text-2xl font-bold text-red-400 mb-2">Game Over</h2>
                <p className="text-gray-400 mb-1">The monster got you...</p>
              </>
            )}
            {isLoggedIn && (
              <p className="text-green-400 text-sm mb-4">
                +{won ? 100 + timer * 2 : 10} coins, +{won ? 50 + timer : 5} XP
              </p>
            )}
            <div className="flex gap-3">
              <button
                onClick={startGame}
                className="bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold px-6 py-3 rounded-xl hover:from-green-600 hover:to-emerald-700 transition-all shadow-lg"
              >
                Play Again
              </button>
              <button
                onClick={onExit}
                className="bg-gray-700 text-white font-bold px-6 py-3 rounded-xl hover:bg-gray-600 transition-all"
              >
                Exit
              </button>
            </div>
          </div>
        )}
      </div>

      <p className="text-gray-400 text-sm">WASD or Arrow keys to move • 🚪 = Exit • 👹 = Monster</p>
    </div>
  );
}
