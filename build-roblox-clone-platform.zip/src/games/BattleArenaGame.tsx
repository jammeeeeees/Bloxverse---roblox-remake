import { useState, useEffect, useCallback, useRef } from 'react';
import { useAuthStore } from '../store/authStore';
import { useSocialStore } from '../store/socialStore';
import AvatarDisplay from '../components/AvatarDisplay';

interface Position {
  x: number;
  y: number;
}

interface Fighter {
  id: string;
  name: string;
  pos: Position;
  avatar: any;
  health: number;
  maxHealth: number;
  score: number;
  lastAttack: number;
  stunned: number;
  facing: 'left' | 'right';
}

interface Projectile {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  owner: string;
}

interface PowerUp {
  id: number;
  x: number;
  y: number;
  type: 'health' | 'speed' | 'damage';
}

const ARENA_WIDTH = 500;
const ARENA_HEIGHT = 400;
const PLAYER_SIZE = 40;

export default function BattleArenaGame({ onExit }: { onExit: () => void }) {
  const { user, addCoins, addXP, incrementGamesPlayed, isLoggedIn } = useAuthStore();
  const { currentLobby, getRandomPlayers } = useSocialStore();
  
  const [fighters, setFighters] = useState<Fighter[]>([]);
  const [projectiles, setProjectiles] = useState<Projectile[]>([]);
  const [powerUps, setPowerUps] = useState<PowerUp[]>([]);
  const [gameOver, setGameOver] = useState(false);
  const [started, setStarted] = useState(false);
  const [winner, setWinner] = useState<Fighter | null>(null);
  const [timer, setTimer] = useState(90);
  const [effects, setEffects] = useState<{ id: number; x: number; y: number; text: string }[]>([]);
  
  const keysRef = useRef<Set<string>>(new Set());
  const projectileIdRef = useRef(0);
  const effectIdRef = useRef(0);
  const powerUpIdRef = useRef(0);
  const gameLoopRef = useRef<number>(0);

  const addEffect = (x: number, y: number, text: string) => {
    const id = effectIdRef.current++;
    setEffects(prev => [...prev, { id, x, y, text }]);
    setTimeout(() => setEffects(prev => prev.filter(e => e.id !== id)), 500);
  };

  const startGame = useCallback(() => {
    const initialFighters: Fighter[] = [];
    
    // Add player
    if (user) {
      initialFighters.push({
        id: user.id,
        name: user.displayName,
        pos: { x: 50, y: ARENA_HEIGHT / 2 },
        avatar: user.equippedAvatar,
        health: 100,
        maxHealth: 100,
        score: 0,
        lastAttack: 0,
        stunned: 0,
        facing: 'right',
      });
    }
    
    // Add AI fighters
    const aiPlayers = currentLobby?.players.filter(p => p.id !== user?.id) || getRandomPlayers(3, user ? [user.id] : []);
    const positions = [
      { x: ARENA_WIDTH - 90, y: ARENA_HEIGHT / 2 },
      { x: ARENA_WIDTH / 2, y: 50 },
      { x: ARENA_WIDTH / 2, y: ARENA_HEIGHT - 90 },
    ];
    
    aiPlayers.slice(0, 3).forEach((p, i) => {
      initialFighters.push({
        id: p.id,
        name: p.displayName,
        pos: positions[i] || { x: Math.random() * (ARENA_WIDTH - 100) + 50, y: Math.random() * (ARENA_HEIGHT - 100) + 50 },
        avatar: p.avatar,
        health: 100,
        maxHealth: 100,
        score: 0,
        lastAttack: 0,
        stunned: 0,
        facing: i % 2 === 0 ? 'left' : 'right',
      });
    });
    
    setFighters(initialFighters);
    setProjectiles([]);
    setPowerUps([]);
    setGameOver(false);
    setStarted(true);
    setWinner(null);
    setTimer(90);
    setEffects([]);
  }, [user, currentLobby, getRandomPlayers]);

  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      keysRef.current.add(e.key.toLowerCase());
      // Shoot
      if (e.key === ' ' && started && !gameOver) {
        setFighters(prev => {
          const player = prev.find(f => f.id === user?.id);
          if (!player || Date.now() - player.lastAttack < 300 || player.stunned > 0) return prev;
          
          const proj: Projectile = {
            id: projectileIdRef.current++,
            x: player.pos.x + PLAYER_SIZE / 2,
            y: player.pos.y + PLAYER_SIZE / 2,
            vx: player.facing === 'right' ? 10 : -10,
            vy: 0,
            owner: player.id,
          };
          setProjectiles(p => [...p, proj]);
          
          return prev.map(f => f.id === user?.id ? { ...f, lastAttack: Date.now() } : f);
        });
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => keysRef.current.delete(e.key.toLowerCase());
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [started, gameOver, user]);

  // Game loop
  useEffect(() => {
    if (!started || gameOver) return;

    const loop = () => {
      // Move player
      setFighters(prev => {
        return prev.map(f => {
          if (f.id !== user?.id || f.health <= 0 || f.stunned > 0) {
            // AI movement
            if (f.id !== user?.id && f.health > 0 && f.stunned <= 0) {
              const target = prev.find(t => t.id !== f.id && t.health > 0);
              if (target && Math.random() < 0.5) {
                const dx = target.pos.x - f.pos.x;
                const dy = target.pos.y - f.pos.y;
                const dist = Math.sqrt(dx * dx + dy * dy);
                
                let newX = f.pos.x;
                let newY = f.pos.y;
                
                if (dist > 100) {
                  newX += (dx / dist) * 3;
                  newY += (dy / dist) * 3;
                } else if (dist < 60) {
                  newX -= (dx / dist) * 2;
                  newY -= (dy / dist) * 2;
                }
                
                newX = Math.max(10, Math.min(ARENA_WIDTH - PLAYER_SIZE - 10, newX));
                newY = Math.max(10, Math.min(ARENA_HEIGHT - PLAYER_SIZE - 10, newY));
                
                // AI shoot
                if (Math.random() < 0.1 && Date.now() - f.lastAttack > 500) {
                  const proj: Projectile = {
                    id: projectileIdRef.current++,
                    x: f.pos.x + PLAYER_SIZE / 2,
                    y: f.pos.y + PLAYER_SIZE / 2,
                    vx: dx > 0 ? 8 : -8,
                    vy: (dy / dist) * 3,
                    owner: f.id,
                  };
                  setProjectiles(p => [...p, proj]);
                  return { ...f, pos: { x: newX, y: newY }, lastAttack: Date.now(), facing: dx > 0 ? 'right' as const : 'left' as const };
                }
                
                return { ...f, pos: { x: newX, y: newY }, facing: dx > 0 ? 'right' as const : 'left' as const };
              }
            }
            return { ...f, stunned: Math.max(0, f.stunned - 1) };
          }
          
          let newX = f.pos.x;
          let newY = f.pos.y;
          let newFacing = f.facing;
          
          if (keysRef.current.has('w') || keysRef.current.has('arrowup')) newY -= 5;
          if (keysRef.current.has('s') || keysRef.current.has('arrowdown')) newY += 5;
          if (keysRef.current.has('a') || keysRef.current.has('arrowleft')) { newX -= 5; newFacing = 'left'; }
          if (keysRef.current.has('d') || keysRef.current.has('arrowright')) { newX += 5; newFacing = 'right'; }
          
          newX = Math.max(10, Math.min(ARENA_WIDTH - PLAYER_SIZE - 10, newX));
          newY = Math.max(10, Math.min(ARENA_HEIGHT - PLAYER_SIZE - 10, newY));
          
          return { ...f, pos: { x: newX, y: newY }, facing: newFacing, stunned: Math.max(0, f.stunned - 1) };
        });
      });
      
      // Move projectiles and check collisions
      setProjectiles(prev => {
        const remaining: Projectile[] = [];
        
        for (const proj of prev) {
          const newX = proj.x + proj.vx;
          const newY = proj.y + proj.vy;
          
          if (newX < 0 || newX > ARENA_WIDTH || newY < 0 || newY > ARENA_HEIGHT) continue;
          
          let hit = false;
          setFighters(fighters => {
            return fighters.map(f => {
              if (f.id === proj.owner || f.health <= 0 || hit) return f;
              
              const dx = (f.pos.x + PLAYER_SIZE / 2) - newX;
              const dy = (f.pos.y + PLAYER_SIZE / 2) - newY;
              if (Math.sqrt(dx * dx + dy * dy) < PLAYER_SIZE / 2) {
                hit = true;
                const damage = 15;
                const newHealth = Math.max(0, f.health - damage);
                addEffect(f.pos.x + PLAYER_SIZE / 2, f.pos.y, `-${damage}`);
                
                // Give score to attacker
                if (newHealth <= 0) {
                  setFighters(fs => fs.map(attacker => 
                    attacker.id === proj.owner ? { ...attacker, score: attacker.score + 100 } : attacker
                  ));
                  addEffect(f.pos.x + PLAYER_SIZE / 2, f.pos.y - 20, '💀');
                }
                
                return { ...f, health: newHealth, stunned: 5 };
              }
              return f;
            });
          });
          
          if (!hit) {
            remaining.push({ ...proj, x: newX, y: newY });
          }
        }
        
        return remaining;
      });
      
      // Check power-up collisions
      setPowerUps(prev => {
        return prev.filter(pu => {
          let collected = false;
          setFighters(fighters => {
            return fighters.map(f => {
              if (f.health <= 0 || collected) return f;
              const dx = (f.pos.x + PLAYER_SIZE / 2) - pu.x;
              const dy = (f.pos.y + PLAYER_SIZE / 2) - pu.y;
              if (Math.sqrt(dx * dx + dy * dy) < PLAYER_SIZE) {
                collected = true;
                if (pu.type === 'health') {
                  addEffect(pu.x, pu.y, '+25 HP');
                  return { ...f, health: Math.min(f.maxHealth, f.health + 25) };
                }
                return f;
              }
              return f;
            });
          });
          return !collected;
        });
      });
      
      // Check win condition
      setFighters(prev => {
        const alive = prev.filter(f => f.health > 0);
        if (alive.length <= 1 && !gameOver) {
          setGameOver(true);
          setWinner(alive[0] || null);
          if (isLoggedIn && alive[0]?.id === user?.id) {
            const score = alive[0].score + 200;
            addCoins(Math.floor(score / 2));
            addXP(Math.floor(score / 3));
            incrementGamesPlayed();
          } else if (isLoggedIn) {
            const myFighter = prev.find(f => f.id === user?.id);
            addCoins(Math.floor((myFighter?.score || 0) / 5) + 10);
            addXP(Math.floor((myFighter?.score || 0) / 10) + 5);
            incrementGamesPlayed();
          }
        }
        return prev;
      });
      
      gameLoopRef.current = requestAnimationFrame(loop);
    };
    
    gameLoopRef.current = requestAnimationFrame(loop);
    return () => { if (gameLoopRef.current) cancelAnimationFrame(gameLoopRef.current); };
  }, [started, gameOver, user, isLoggedIn, addCoins, addXP, incrementGamesPlayed]);

  // Spawn power-ups
  useEffect(() => {
    if (!started || gameOver) return;
    const interval = setInterval(() => {
      if (powerUps.length < 3) {
        setPowerUps(prev => [...prev, {
          id: powerUpIdRef.current++,
          x: Math.random() * (ARENA_WIDTH - 40) + 20,
          y: Math.random() * (ARENA_HEIGHT - 40) + 20,
          type: 'health',
        }]);
      }
    }, 5000);
    return () => clearInterval(interval);
  }, [started, gameOver, powerUps.length]);

  // Timer
  useEffect(() => {
    if (!started || gameOver) return;
    const interval = setInterval(() => {
      setTimer(t => {
        if (t <= 1) {
          // Time's up - highest score wins
          setFighters(prev => {
            const sorted = [...prev].sort((a, b) => b.score - a.score);
            setWinner(sorted[0]);
            setGameOver(true);
            return prev;
          });
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [started, gameOver]);

  const myFighter = fighters.find(f => f.id === user?.id);

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="flex items-center justify-between w-full max-w-xl">
        <div>
          <div className="text-white font-bold text-lg">⚔️ Battle Arena</div>
          {started && !gameOver && <div className="text-yellow-400 text-sm">⏱️ {timer}s • Score: {myFighter?.score || 0}</div>}
        </div>
        <button onClick={onExit} className="text-gray-400 hover:text-white text-sm px-3 py-1 bg-gray-800 rounded-lg border border-gray-700">
          Exit Game
        </button>
      </div>

      {/* Health bars */}
      {started && !gameOver && (
        <div className="flex gap-4 flex-wrap justify-center">
          {fighters.map(f => (
            <div key={f.id} className={`flex items-center gap-2 px-3 py-1 rounded-lg ${f.id === user?.id ? 'bg-green-500/20 border border-green-500/30' : 'bg-gray-800'}`}>
              <span className="text-xs">{f.name.slice(0, 8)}</span>
              <div className="w-20 h-2 bg-gray-700 rounded-full overflow-hidden">
                <div
                  className={`h-full transition-all ${f.health > 50 ? 'bg-green-500' : f.health > 25 ? 'bg-yellow-500' : 'bg-red-500'}`}
                  style={{ width: `${f.health}%` }}
                />
              </div>
              <span className="text-xs text-gray-400">{f.score}</span>
            </div>
          ))}
        </div>
      )}

      <div
        className="relative rounded-xl overflow-hidden border-2 border-gray-700 shadow-2xl"
        style={{ width: ARENA_WIDTH, height: ARENA_HEIGHT, background: 'linear-gradient(135deg, #1a1a2e 0%, #16213e 100%)' }}
      >
        {/* Arena decorations */}
        <div className="absolute inset-4 border border-gray-700/30 rounded-lg" />
        <div className="absolute top-1/2 left-1/2 w-20 h-20 -ml-10 -mt-10 border-2 border-gray-700/30 rounded-full" />

        {/* Power-ups */}
        {powerUps.map(pu => (
          <div
            key={pu.id}
            className="absolute w-8 h-8 flex items-center justify-center text-xl animate-bounce"
            style={{ left: pu.x - 16, top: pu.y - 16 }}
          >
            {pu.type === 'health' ? '❤️' : '⚡'}
          </div>
        ))}

        {/* Projectiles */}
        {projectiles.map(proj => (
          <div
            key={proj.id}
            className="absolute w-3 h-3 bg-yellow-400 rounded-full"
            style={{
              left: proj.x - 6,
              top: proj.y - 6,
              boxShadow: '0 0 10px #fbbf24',
            }}
          />
        ))}

        {/* Fighters */}
        {fighters.map(f => f.health > 0 && (
          <div
            key={f.id}
            className={`absolute transition-all duration-75 ${f.stunned > 0 ? 'opacity-50' : ''}`}
            style={{
              left: f.pos.x,
              top: f.pos.y,
              width: PLAYER_SIZE,
              height: PLAYER_SIZE,
              transform: f.facing === 'left' ? 'scaleX(-1)' : 'scaleX(1)',
            }}
          >
            <div className={`scale-75 ${f.id === user?.id ? 'ring-2 ring-green-400 ring-offset-2 ring-offset-transparent rounded-full' : ''}`}>
              <AvatarDisplay size="sm" equipped={f.avatar} showPet={false} showAura={f.id === user?.id} />
            </div>
          </div>
        ))}

        {/* Effects */}
        {effects.map(e => (
          <div
            key={e.id}
            className="absolute text-red-400 font-bold text-sm pointer-events-none animate-bounce"
            style={{ left: e.x, top: e.y }}
          >
            {e.text}
          </div>
        ))}

        {/* Start screen */}
        {!started && (
          <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center">
            <div className="text-6xl mb-4">⚔️</div>
            <h2 className="text-2xl font-bold text-white mb-2">Battle Arena</h2>
            <p className="text-gray-400 text-center mb-4 max-w-xs">
              Fight against other players! Last one standing wins.
            </p>
            <p className="text-yellow-400 text-sm mb-4">WASD to move • SPACE to shoot</p>
            <button
              onClick={startGame}
              className="bg-gradient-to-r from-red-500 to-orange-600 text-white font-bold px-8 py-3 rounded-xl hover:from-red-600 hover:to-orange-700 transition-all shadow-lg"
            >
              Start Battle! ⚔️
            </button>
          </div>
        )}

        {/* Game over */}
        {gameOver && (
          <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center">
            {winner?.id === user?.id ? (
              <>
                <div className="text-6xl mb-4">🏆</div>
                <h2 className="text-2xl font-bold text-yellow-400 mb-2">Victory!</h2>
                <p className="text-white">Score: {(winner?.score || 0) + 200}</p>
              </>
            ) : winner ? (
              <>
                <div className="text-6xl mb-4">💀</div>
                <h2 className="text-2xl font-bold text-red-400 mb-2">Defeated</h2>
                <p className="text-gray-400">{winner.name} wins!</p>
                <p className="text-white">Your score: {myFighter?.score || 0}</p>
              </>
            ) : (
              <>
                <div className="text-6xl mb-4">⏱️</div>
                <h2 className="text-2xl font-bold text-white mb-2">Time's Up!</h2>
              </>
            )}
            {isLoggedIn && (
              <p className="text-green-400 text-sm mt-2 mb-4">
                Rewards claimed!
              </p>
            )}
            <div className="flex gap-3 mt-2">
              <button
                onClick={startGame}
                className="bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold px-6 py-3 rounded-xl hover:from-green-600 hover:to-emerald-700 transition-all shadow-lg"
              >
                Play Again
              </button>
              <button onClick={onExit} className="bg-gray-700 text-white font-bold px-6 py-3 rounded-xl hover:bg-gray-600 transition-all">
                Exit
              </button>
            </div>
          </div>
        )}
      </div>

      <p className="text-gray-400 text-sm">WASD to move • SPACE to shoot • ❤️ = Health</p>
    </div>
  );
}
