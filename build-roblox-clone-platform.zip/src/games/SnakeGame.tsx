import { useState, useEffect, useCallback, useRef } from 'react';
import { useAuthStore } from '../store/authStore';

type Direction = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT';
type Point = { x: number; y: number };

const GRID_SIZE = 20;
const CELL_SIZE = 20;

export default function SnakeGame({ onExit }: { onExit: () => void }) {
  const { addCoins, addXP, incrementGamesPlayed, isLoggedIn } = useAuthStore();
  const [snake, setSnake] = useState<Point[]>([{ x: 10, y: 10 }]);
  const [food, setFood] = useState<Point>({ x: 15, y: 15 });
  const [goldenFood, setGoldenFood] = useState<Point | null>(null);
  const [, setDirection] = useState<Direction>('RIGHT');
  const [gameOver, setGameOver] = useState(false);
  const [started, setStarted] = useState(false);
  const [score, setScore] = useState(0);
  const [speed, setSpeed] = useState(150);
  const dirRef = useRef<Direction>('RIGHT');
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const randomFood = useCallback((snakeBody: Point[]): Point => {
    let pos: Point;
    do {
      pos = {
        x: Math.floor(Math.random() * GRID_SIZE),
        y: Math.floor(Math.random() * GRID_SIZE),
      };
    } while (snakeBody.some(s => s.x === pos.x && s.y === pos.y));
    return pos;
  }, []);

  const startGame = useCallback(() => {
    const initial = [{ x: 10, y: 10 }];
    setSnake(initial);
    setFood(randomFood(initial));
    setGoldenFood(null);
    setDirection('RIGHT');
    dirRef.current = 'RIGHT';
    setGameOver(false);
    setStarted(true);
    setScore(0);
    setSpeed(150);
  }, [randomFood]);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      const dir = dirRef.current;
      if ((e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') && dir !== 'DOWN') {
        dirRef.current = 'UP';
        setDirection('UP');
      }
      if ((e.key === 'ArrowDown' || e.key === 's' || e.key === 'S') && dir !== 'UP') {
        dirRef.current = 'DOWN';
        setDirection('DOWN');
      }
      if ((e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') && dir !== 'RIGHT') {
        dirRef.current = 'LEFT';
        setDirection('LEFT');
      }
      if ((e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') && dir !== 'LEFT') {
        dirRef.current = 'RIGHT';
        setDirection('RIGHT');
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, []);

  useEffect(() => {
    if (!started || gameOver) return;

    const interval = setInterval(() => {
      setSnake(prev => {
        const head = { ...prev[0] };
        const dir = dirRef.current;

        switch (dir) {
          case 'UP': head.y--; break;
          case 'DOWN': head.y++; break;
          case 'LEFT': head.x--; break;
          case 'RIGHT': head.x++; break;
        }

        // Wall collision
        if (head.x < 0 || head.x >= GRID_SIZE || head.y < 0 || head.y >= GRID_SIZE) {
          setGameOver(true);
          if (isLoggedIn) {
            addCoins(score);
            addXP(Math.floor(score / 2));
            incrementGamesPlayed();
          }
          return prev;
        }

        // Self collision
        if (prev.some(s => s.x === head.x && s.y === head.y)) {
          setGameOver(true);
          if (isLoggedIn) {
            addCoins(score);
            addXP(Math.floor(score / 2));
            incrementGamesPlayed();
          }
          return prev;
        }

        const newSnake = [head, ...prev];

        // Check food
        if (head.x === food.x && head.y === food.y) {
          const newScore = score + 10;
          setScore(newScore);
          setFood(randomFood(newSnake));
          if (newScore % 50 === 0) {
            setGoldenFood(randomFood(newSnake));
          }
          if (newScore % 30 === 0 && speed > 60) {
            setSpeed(s => Math.max(60, s - 10));
          }
        } else if (goldenFood && head.x === goldenFood.x && head.y === goldenFood.y) {
          setScore(s => s + 50);
          setGoldenFood(null);
        } else {
          newSnake.pop();
        }

        return newSnake;
      });
    }, speed);

    return () => clearInterval(interval);
  }, [started, gameOver, food, goldenFood, speed, score, randomFood, isLoggedIn, addCoins, addXP, incrementGamesPlayed]);

  // Draw
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const W = GRID_SIZE * CELL_SIZE;
    const H = GRID_SIZE * CELL_SIZE;

    // Background
    ctx.fillStyle = '#1a1a2e';
    ctx.fillRect(0, 0, W, H);

    // Grid
    ctx.strokeStyle = 'rgba(255,255,255,0.03)';
    for (let i = 0; i < GRID_SIZE; i++) {
      ctx.beginPath();
      ctx.moveTo(i * CELL_SIZE, 0);
      ctx.lineTo(i * CELL_SIZE, H);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, i * CELL_SIZE);
      ctx.lineTo(W, i * CELL_SIZE);
      ctx.stroke();
    }

    // Snake
    snake.forEach((seg, i) => {
      const isHead = i === 0;
      const gradient = ctx.createRadialGradient(
        seg.x * CELL_SIZE + CELL_SIZE / 2,
        seg.y * CELL_SIZE + CELL_SIZE / 2,
        0,
        seg.x * CELL_SIZE + CELL_SIZE / 2,
        seg.y * CELL_SIZE + CELL_SIZE / 2,
        CELL_SIZE / 2
      );
      if (isHead) {
        gradient.addColorStop(0, '#34d399');
        gradient.addColorStop(1, '#059669');
      } else {
        gradient.addColorStop(0, '#10b981');
        gradient.addColorStop(1, '#047857');
      }
      ctx.fillStyle = gradient;
      ctx.shadowColor = '#10b981';
      ctx.shadowBlur = isHead ? 10 : 4;
      ctx.beginPath();
      ctx.roundRect(
        seg.x * CELL_SIZE + 1,
        seg.y * CELL_SIZE + 1,
        CELL_SIZE - 2,
        CELL_SIZE - 2,
        4
      );
      ctx.fill();
      ctx.shadowBlur = 0;

      // Eyes on head
      if (isHead) {
        ctx.fillStyle = 'white';
        ctx.beginPath();
        ctx.arc(seg.x * CELL_SIZE + 7, seg.y * CELL_SIZE + 8, 3, 0, Math.PI * 2);
        ctx.arc(seg.x * CELL_SIZE + 14, seg.y * CELL_SIZE + 8, 3, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#1a1a2e';
        ctx.beginPath();
        ctx.arc(seg.x * CELL_SIZE + 7, seg.y * CELL_SIZE + 8, 1.5, 0, Math.PI * 2);
        ctx.arc(seg.x * CELL_SIZE + 14, seg.y * CELL_SIZE + 8, 1.5, 0, Math.PI * 2);
        ctx.fill();
      }
    });

    // Food
    ctx.fillStyle = '#ef4444';
    ctx.shadowColor = '#ef4444';
    ctx.shadowBlur = 10;
    ctx.beginPath();
    ctx.arc(food.x * CELL_SIZE + CELL_SIZE / 2, food.y * CELL_SIZE + CELL_SIZE / 2, CELL_SIZE / 2 - 2, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    // Golden food
    if (goldenFood) {
      ctx.fillStyle = '#fbbf24';
      ctx.shadowColor = '#fbbf24';
      ctx.shadowBlur = 15;
      ctx.beginPath();
      ctx.arc(goldenFood.x * CELL_SIZE + CELL_SIZE / 2, goldenFood.y * CELL_SIZE + CELL_SIZE / 2, CELL_SIZE / 2 - 1, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.arc(goldenFood.x * CELL_SIZE + CELL_SIZE / 2, goldenFood.y * CELL_SIZE + CELL_SIZE / 2, CELL_SIZE / 2 - 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
    }
  }, [snake, food, goldenFood]);

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="flex items-center justify-between w-full max-w-lg">
        <div className="text-white font-bold text-lg">🐍 Score: {score}</div>
        <button onClick={onExit} className="text-gray-400 hover:text-white text-sm px-3 py-1 bg-gray-800 rounded-lg border border-gray-700">
          Exit Game
        </button>
      </div>

      <div className="relative rounded-xl overflow-hidden border-2 border-gray-700 shadow-2xl">
        <canvas ref={canvasRef} width={GRID_SIZE * CELL_SIZE} height={GRID_SIZE * CELL_SIZE} />

        {!started && (
          <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center">
            <h2 className="text-3xl font-bold text-white mb-2">🐍 Snake Simulator</h2>
            <p className="text-gray-300 mb-4">Eat food, grow longer, don't hit walls!</p>
            <p className="text-yellow-400 text-sm mb-4">Golden food = 50 points! Speed increases over time!</p>
            <button onClick={startGame} className="bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold px-8 py-3 rounded-xl hover:from-green-600 hover:to-emerald-700 transition-all shadow-lg">
              Start Game
            </button>
          </div>
        )}

        {gameOver && (
          <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center">
            <h2 className="text-3xl font-bold text-white mb-2">Game Over!</h2>
            <p className="text-2xl text-yellow-400 font-bold mb-1">Score: {score}</p>
            <p className="text-gray-400 mb-1">Length: {snake.length}</p>
            {isLoggedIn && (
              <p className="text-green-400 text-sm mb-4">+{score} coins, +{Math.floor(score / 2)} XP</p>
            )}
            <div className="flex gap-3">
              <button onClick={startGame} className="bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold px-6 py-3 rounded-xl hover:from-green-600 hover:to-emerald-700 transition-all shadow-lg">
                Play Again
              </button>
              <button onClick={onExit} className="bg-gray-700 text-white font-bold px-6 py-3 rounded-xl hover:bg-gray-600 transition-all">
                Exit
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Mobile controls */}
      <div className="grid grid-cols-3 gap-2 w-36 md:hidden">
        <div />
        <button onClick={() => { if (dirRef.current !== 'DOWN') { dirRef.current = 'UP'; setDirection('UP'); } }} className="bg-gray-700 text-white rounded-lg p-3 text-center">↑</button>
        <div />
        <button onClick={() => { if (dirRef.current !== 'RIGHT') { dirRef.current = 'LEFT'; setDirection('LEFT'); } }} className="bg-gray-700 text-white rounded-lg p-3 text-center">←</button>
        <button onClick={() => { if (dirRef.current !== 'UP') { dirRef.current = 'DOWN'; setDirection('DOWN'); } }} className="bg-gray-700 text-white rounded-lg p-3 text-center">↓</button>
        <button onClick={() => { if (dirRef.current !== 'LEFT') { dirRef.current = 'RIGHT'; setDirection('RIGHT'); } }} className="bg-gray-700 text-white rounded-lg p-3 text-center">→</button>
      </div>

      <p className="text-gray-400 text-sm">Arrow keys / WASD to move</p>
    </div>
  );
}
