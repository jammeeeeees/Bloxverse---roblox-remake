import { useState, useEffect, useRef, useCallback } from 'react';
import { useAuthStore } from '../store/authStore';

interface Mole {
  id: number;
  active: boolean;
  golden: boolean;
  hit: boolean;
  timer: number;
}

export default function WhackAMoleGame({ onExit }: { onExit: () => void }) {
  const { addCoins, addXP, incrementGamesPlayed, isLoggedIn } = useAuthStore();
  const [moles, setMoles] = useState<Mole[]>(
    Array.from({ length: 9 }, (_, i) => ({ id: i, active: false, golden: false, hit: false, timer: 0 }))
  );
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const [gameOver, setGameOver] = useState(false);
  const [started, setStarted] = useState(false);
  const [hits, setHits] = useState(0);
  const [misses, setMisses] = useState(0);
  const [combo, setCombo] = useState(0);
  const [effects, setEffects] = useState<{ id: number; x: number; y: number; text: string; color: string }[]>([]);
  const effectId = useRef(0);
  const intervalRef = useRef<ReturnType<typeof setInterval>>(undefined);
  const timerRef = useRef<ReturnType<typeof setInterval>>(undefined);

  const startGame = useCallback(() => {
    setMoles(Array.from({ length: 9 }, (_, i) => ({ id: i, active: false, golden: false, hit: false, timer: 0 })));
    setScore(0);
    setTimeLeft(30);
    setGameOver(false);
    setStarted(true);
    setHits(0);
    setMisses(0);
    setCombo(0);
    setEffects([]);
  }, []);

  // Mole spawning
  useEffect(() => {
    if (!started || gameOver) return;

    intervalRef.current = setInterval(() => {
      setMoles(prev => {
        const newMoles = prev.map(m => {
          if (m.active) {
            m.timer--;
            if (m.timer <= 0) {
              return { ...m, active: false, golden: false, hit: false, timer: 0 };
            }
          }
          return { ...m };
        });

        // Spawn new moles
        const inactiveIndices = newMoles.filter(m => !m.active).map(m => m.id);
        if (inactiveIndices.length > 0 && Math.random() < 0.3) {
          const idx = inactiveIndices[Math.floor(Math.random() * inactiveIndices.length)];
          const isGolden = Math.random() < 0.1;
          newMoles[idx] = {
            ...newMoles[idx],
            active: true,
            golden: isGolden,
            hit: false,
            timer: isGolden ? 8 : 12 + Math.floor(Math.random() * 8),
          };
        }

        return newMoles;
      });
    }, 100);

    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [started, gameOver]);

  // Timer
  useEffect(() => {
    if (!started || gameOver) return;

    timerRef.current = setInterval(() => {
      setTimeLeft(t => {
        if (t <= 1) {
          setGameOver(true);
          if (intervalRef.current) clearInterval(intervalRef.current);
          return 0;
        }
        return t - 1;
      });
    }, 1000);

    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [started, gameOver]);

  // End game rewards
  useEffect(() => {
    if (gameOver && isLoggedIn && started) {
      addCoins(Math.floor(score / 2));
      addXP(Math.floor(score / 3));
      incrementGamesPlayed();
    }
  }, [gameOver]);

  const whackMole = (index: number, e: React.MouseEvent) => {
    if (!started || gameOver) return;

    const mole = moles[index];
    if (mole.active && !mole.hit) {
      const points = mole.golden ? 50 : 10;
      const comboBonus = combo >= 3 ? Math.floor(combo * 2) : 0;
      const total = points + comboBonus;

      setScore(s => s + total);
      setHits(h => h + 1);
      setCombo(c => c + 1);

      const rect = (e.target as HTMLElement).getBoundingClientRect();
      const eid = effectId.current++;
      setEffects(prev => [...prev, {
        id: eid,
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
        text: `+${total}`,
        color: mole.golden ? '#fbbf24' : '#10b981',
      }]);
      setTimeout(() => setEffects(prev => prev.filter(ef => ef.id !== eid)), 600);

      setMoles(prev => {
        const newMoles = [...prev];
        newMoles[index] = { ...newMoles[index], hit: true };
        setTimeout(() => {
          setMoles(p => {
            const nm = [...p];
            nm[index] = { ...nm[index], active: false, hit: false };
            return nm;
          });
        }, 200);
        return newMoles;
      });
    } else if (!mole.active) {
      setMisses(m => m + 1);
      setCombo(0);
    }
  };

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="flex items-center justify-between w-full max-w-lg">
        <div>
          <div className="text-white font-bold text-lg">🔨 Score: {score}</div>
          {combo >= 3 && <span className="text-yellow-400 text-sm font-bold">🔥 x{combo} combo!</span>}
        </div>
        <div className="flex items-center gap-4">
          {started && !gameOver && (
            <div className={`text-lg font-bold ${timeLeft <= 10 ? 'text-red-400 animate-pulse' : 'text-white'}`}>
              ⏱️ {timeLeft}s
            </div>
          )}
          <button onClick={onExit} className="text-gray-400 hover:text-white text-sm px-3 py-1 bg-gray-800 rounded-lg border border-gray-700">
            Exit Game
          </button>
        </div>
      </div>

      <div className="relative bg-gray-800 rounded-2xl p-6 border-2 border-gray-700 shadow-2xl">
        {!started ? (
          <div className="w-80 h-80 flex flex-col items-center justify-center">
            <div className="text-6xl mb-4">🔨</div>
            <h2 className="text-2xl font-bold text-white mb-2">Whack-a-Blox</h2>
            <p className="text-gray-400 text-center mb-2">Whack moles as they pop up!</p>
            <p className="text-yellow-400 text-sm mb-6">Golden moles = 50 points! Build combos!</p>
            <button onClick={startGame} className="bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold px-8 py-3 rounded-xl hover:from-green-600 hover:to-emerald-700 transition-all shadow-lg">
              Start Game
            </button>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-3 gap-4">
              {moles.map((mole, i) => (
                <div key={mole.id} className="relative">
                  <button
                    onClick={(e) => whackMole(i, e)}
                    className={`w-24 h-24 rounded-2xl flex items-center justify-center text-5xl transition-all duration-150 border-2 select-none ${
                      mole.hit
                        ? 'bg-yellow-500/20 border-yellow-500 scale-90'
                        : mole.active
                        ? mole.golden
                          ? 'bg-yellow-500/10 border-yellow-500 hover:bg-yellow-500/20 scale-110 animate-bounce'
                          : 'bg-green-500/10 border-green-500 hover:bg-green-500/20 scale-110'
                        : 'bg-gray-700 border-gray-600 hover:bg-gray-600'
                    }`}
                  >
                    {mole.hit ? '💥' : mole.active ? (mole.golden ? '🌟' : '🐹') : '🕳️'}
                  </button>
                  {effects.map(ef => (
                    <div key={ef.id} className="absolute pointer-events-none font-bold" style={{ left: ef.x, top: ef.y, color: ef.color, animation: 'floatUp 0.6s ease-out forwards' }}>
                      {ef.text}
                    </div>
                  ))}
                </div>
              ))}
            </div>

            {/* Stats */}
            <div className="flex justify-center gap-4 mt-4">
              <div className="text-center">
                <p className="text-green-400 text-sm font-bold">{hits}</p>
                <p className="text-gray-500 text-xs">Hits</p>
              </div>
              <div className="text-center">
                <p className="text-red-400 text-sm font-bold">{misses}</p>
                <p className="text-gray-500 text-xs">Misses</p>
              </div>
              <div className="text-center">
                <p className="text-yellow-400 text-sm font-bold">{hits > 0 ? Math.floor((hits / (hits + misses)) * 100) : 0}%</p>
                <p className="text-gray-500 text-xs">Accuracy</p>
              </div>
            </div>
          </>
        )}

        {gameOver && (
          <div className="absolute inset-0 bg-black/70 rounded-2xl flex flex-col items-center justify-center">
            <h2 className="text-3xl font-bold text-white mb-2">Time's Up!</h2>
            <p className="text-2xl text-yellow-400 font-bold mb-1">Score: {score}</p>
            <p className="text-gray-400 text-sm">
              {hits} hits • {misses} misses • {hits > 0 ? Math.floor((hits / (hits + misses)) * 100) : 0}% accuracy
            </p>
            {isLoggedIn && (
              <p className="text-green-400 text-sm mt-2 mb-4">+{Math.floor(score / 2)} coins, +{Math.floor(score / 3)} XP</p>
            )}
            <div className="flex gap-3">
              <button onClick={startGame} className="bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold px-6 py-3 rounded-xl hover:from-green-600 hover:to-emerald-700 transition-all shadow-lg">
                Play Again
              </button>
              <button onClick={onExit} className="bg-gray-700 text-white font-bold px-6 py-3 rounded-xl hover:bg-gray-600 transition-all">
                Exit
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
