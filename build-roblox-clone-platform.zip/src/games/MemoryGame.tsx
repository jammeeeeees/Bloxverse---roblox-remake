import { useState, useEffect, useRef } from 'react';
import { useAuthStore } from '../store/authStore';

interface Card {
  id: number;
  emoji: string;
  flipped: boolean;
  matched: boolean;
}

const EMOJIS = ['🐉', '🦄', '🔥', '⚡', '🌟', '💎', '🎮', '🚀', '🌈', '🎯', '👾', '🎪'];

export default function MemoryGame({ onExit }: { onExit: () => void }) {
  const { addCoins, addXP, incrementGamesPlayed, isLoggedIn } = useAuthStore();
  const [cards, setCards] = useState<Card[]>([]);
  const [flippedCards, setFlippedCards] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  const [matches, setMatches] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [started, setStarted] = useState(false);
  const [timer, setTimer] = useState(0);
  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>('medium');
  const timerRef = useRef<ReturnType<typeof setInterval>>(undefined);
  const lockRef = useRef(false);

  const getPairCount = (d?: typeof difficulty) => {
    switch (d ?? difficulty) {
      case 'easy': return 6;
      case 'medium': return 8;
      case 'hard': return 12;
      default: return 8;
    }
  };

  const startGame = () => {
    const pairCount = getPairCount();
    const selectedEmojis = EMOJIS.slice(0, pairCount);
    const cardPairs = [...selectedEmojis, ...selectedEmojis].map((emoji, i) => ({
      id: i,
      emoji,
      flipped: false,
      matched: false,
    }));

    // Shuffle
    for (let i = cardPairs.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [cardPairs[i], cardPairs[j]] = [cardPairs[j], cardPairs[i]];
    }

    setCards(cardPairs);
    setFlippedCards([]);
    setMoves(0);
    setMatches(0);
    setGameOver(false);
    setStarted(true);
    setTimer(0);
    lockRef.current = false;

    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => setTimer(t => t + 1), 1000);
  };

  useEffect(() => {
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, []);

  const handleCardClick = (index: number) => {
    if (lockRef.current) return;
    if (cards[index].flipped || cards[index].matched) return;
    if (flippedCards.length >= 2) return;

    const newCards = [...cards];
    newCards[index].flipped = true;
    setCards(newCards);

    const newFlipped = [...flippedCards, index];
    setFlippedCards(newFlipped);

    if (newFlipped.length === 2) {
      setMoves(m => m + 1);
      lockRef.current = true;

      if (newCards[newFlipped[0]].emoji === newCards[newFlipped[1]].emoji) {
        // Match!
        setTimeout(() => {
          const matchedCards = [...newCards];
          matchedCards[newFlipped[0]].matched = true;
          matchedCards[newFlipped[1]].matched = true;
          setCards(matchedCards);
          setFlippedCards([]);
          const newMatches = matches + 1;
          setMatches(newMatches);
          lockRef.current = false;

          if (newMatches === getPairCount()) {
            // Game won!
            if (timerRef.current) clearInterval(timerRef.current);
            setGameOver(true);
            if (isLoggedIn) {
              const bonus = difficulty === 'hard' ? 3 : difficulty === 'medium' ? 2 : 1;
              const coinReward = Math.max(10, 50 * bonus - moves);
              const xpReward = Math.max(5, 30 * bonus - Math.floor(timer / 5));
              addCoins(coinReward);
              addXP(xpReward);
              incrementGamesPlayed();
            }
          }
        }, 300);
      } else {
        // No match
        setTimeout(() => {
          const resetCards = [...newCards];
          resetCards[newFlipped[0]].flipped = false;
          resetCards[newFlipped[1]].flipped = false;
          setCards(resetCards);
          setFlippedCards([]);
          lockRef.current = false;
        }, 800);
      }
    }
  };

  const getGridCols = () => {
    const total = getPairCount() * 2;
    if (total <= 12) return 'grid-cols-4';
    if (total <= 16) return 'grid-cols-4';
    return 'grid-cols-6';
  };

  const formatTime = (s: number) => `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, '0')}`;

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="flex items-center justify-between w-full max-w-lg">
        <div className="text-white font-bold text-lg">🧠 Memory Quest</div>
        <button onClick={onExit} className="text-gray-400 hover:text-white text-sm px-3 py-1 bg-gray-800 rounded-lg border border-gray-700">
          Exit Game
        </button>
      </div>

      {!started ? (
        <div className="bg-gray-800 rounded-2xl p-8 text-center border border-gray-700 max-w-md w-full">
          <div className="text-6xl mb-4">🃏</div>
          <h2 className="text-2xl font-bold text-white mb-2">Memory Quest</h2>
          <p className="text-gray-400 mb-6">Match all pairs of cards to win!</p>

          <div className="flex gap-3 justify-center mb-6">
            {(['easy', 'medium', 'hard'] as const).map(d => (
              <button
                key={d}
                onClick={() => setDifficulty(d)}
                className={`px-4 py-2 rounded-lg font-medium text-sm capitalize transition-all ${
                  difficulty === d
                    ? 'bg-green-500 text-white'
                    : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                }`}
              >
                {d} ({d === 'easy' ? 12 : d === 'medium' ? 16 : 24} cards)
              </button>
            ))}
          </div>

          <button onClick={startGame} className="bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold px-8 py-3 rounded-xl hover:from-green-600 hover:to-emerald-700 transition-all shadow-lg">
            Start Game
          </button>
        </div>
      ) : (
        <>
          {/* Stats */}
          <div className="flex gap-4">
            <div className="bg-gray-800 rounded-lg px-4 py-2 border border-gray-700">
              <span className="text-gray-400 text-xs">Moves</span>
              <p className="text-white font-bold">{moves}</p>
            </div>
            <div className="bg-gray-800 rounded-lg px-4 py-2 border border-gray-700">
              <span className="text-gray-400 text-xs">Matches</span>
              <p className="text-white font-bold">{matches}/{getPairCount()}</p>
            </div>
            <div className="bg-gray-800 rounded-lg px-4 py-2 border border-gray-700">
              <span className="text-gray-400 text-xs">Time</span>
              <p className="text-white font-bold">{formatTime(timer)}</p>
            </div>
          </div>

          {/* Cards Grid */}
          <div className={`grid ${getGridCols()} gap-3 max-w-lg`}>
            {cards.map((card, i) => (
              <button
                key={card.id}
                onClick={() => handleCardClick(i)}
                className={`w-16 h-20 sm:w-20 sm:h-24 rounded-xl flex items-center justify-center text-3xl sm:text-4xl font-bold transition-all duration-300 transform ${
                  card.matched
                    ? 'bg-green-500/20 border-2 border-green-500/50 scale-95'
                    : card.flipped
                    ? 'bg-gray-700 border-2 border-blue-400 rotate-0'
                    : 'bg-gradient-to-br from-blue-600 to-purple-700 border-2 border-blue-500/30 hover:border-blue-400/60 hover:scale-105 cursor-pointer'
                }`}
              >
                {card.flipped || card.matched ? (
                  <span className={card.matched ? 'opacity-60' : ''}>{card.emoji}</span>
                ) : (
                  <span className="text-white/30 text-2xl">?</span>
                )}
              </button>
            ))}
          </div>

          {/* Game Over */}
          {gameOver && (
            <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
              <div className="bg-gray-800 rounded-2xl p-8 text-center border border-gray-700 max-w-md w-full">
                <div className="text-6xl mb-4">🎉</div>
                <h2 className="text-2xl font-bold text-white mb-2">You Won!</h2>
                <p className="text-gray-400 mb-1">{moves} moves in {formatTime(timer)}</p>
                {isLoggedIn && (
                  <div className="bg-gray-700/50 rounded-xl p-3 mt-3 mb-4">
                    <p className="text-green-400 text-sm">
                      +{Math.max(10, 50 * (difficulty === 'hard' ? 3 : difficulty === 'medium' ? 2 : 1) - moves)} coins
                    </p>
                    <p className="text-blue-400 text-sm">
                      +{Math.max(5, 30 * (difficulty === 'hard' ? 3 : difficulty === 'medium' ? 2 : 1) - Math.floor(timer / 5))} XP
                    </p>
                  </div>
                )}
                <div className="flex gap-3 justify-center">
                  <button onClick={startGame} className="bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold px-6 py-3 rounded-xl hover:from-green-600 hover:to-emerald-700 transition-all shadow-lg">
                    Play Again
                  </button>
                  <button onClick={onExit} className="bg-gray-700 text-white font-bold px-6 py-3 rounded-xl hover:bg-gray-600 transition-all">
                    Exit
                  </button>
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
