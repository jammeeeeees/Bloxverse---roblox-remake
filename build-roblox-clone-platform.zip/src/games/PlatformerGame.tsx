import { useState, useEffect, useCallback, useRef } from 'react';
import { useAuthStore } from '../store/authStore';

interface Platform {
  x: number;
  y: number;
  width: number;
  color: string;
  type: 'normal' | 'moving' | 'crumbling';
  moveDir?: number;
  moveRange?: number;
  origX?: number;
}

export default function PlatformerGame({ onExit }: { onExit: () => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { addCoins, addXP, incrementGamesPlayed, isLoggedIn } = useAuthStore();
  const [score, setScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [started, setStarted] = useState(false);
  const gameRef = useRef({
    player: { x: 200, y: 300, vy: 0, vx: 0, width: 30, height: 30, onGround: false, jumps: 0 },
    platforms: [] as Platform[],
    keys: {} as Record<string, boolean>,
    scrollY: 0,
    score: 0,
    highestY: 300,
    particles: [] as { x: number; y: number; vx: number; vy: number; life: number; color: string }[],
    coins: [] as { x: number; y: number; collected: boolean }[],
    animFrame: 0,
  });

  const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4'];

  const generatePlatforms = useCallback(() => {
    const platforms: Platform[] = [];
    // Ground platform
    platforms.push({ x: 0, y: 380, width: 500, color: '#10b981', type: 'normal' });

    for (let i = 1; i < 200; i++) {
      const y = 380 - i * 80;
      const x = Math.random() * 340;
      const width = 60 + Math.random() * 80;
      const type = Math.random() < 0.15 ? 'moving' : Math.random() < 0.1 ? 'crumbling' : 'normal';
      platforms.push({
        x,
        y,
        width,
        color: COLORS[i % COLORS.length],
        type,
        moveDir: type === 'moving' ? 1 : undefined,
        moveRange: type === 'moving' ? 50 + Math.random() * 50 : undefined,
        origX: type === 'moving' ? x : undefined,
      });
    }

    const coins = platforms.slice(1).filter(() => Math.random() < 0.4).map(p => ({
      x: p.x + p.width / 2,
      y: p.y - 30,
      collected: false,
    }));

    return { platforms, coins };
  }, []);

  const startGame = useCallback(() => {
    const { platforms, coins } = generatePlatforms();
    gameRef.current = {
      player: { x: 200, y: 300, vy: 0, vx: 0, width: 30, height: 30, onGround: false, jumps: 0 },
      platforms,
      keys: {},
      scrollY: 0,
      score: 0,
      highestY: 300,
      particles: [],
      coins,
      animFrame: 0,
    };
    setScore(0);
    setGameOver(false);
    setStarted(true);
  }, [generatePlatforms]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      gameRef.current.keys[e.key] = true;
      if ((e.key === ' ' || e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') && started && !gameOver) {
        const p = gameRef.current.player;
        if (p.jumps < 2) {
          p.vy = -12;
          p.jumps++;
          p.onGround = false;
          // Jump particles
          for (let i = 0; i < 5; i++) {
            gameRef.current.particles.push({
              x: p.x + p.width / 2,
              y: p.y + p.height,
              vx: (Math.random() - 0.5) * 4,
              vy: Math.random() * 2,
              life: 20,
              color: '#10b981',
            });
          }
        }
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      gameRef.current.keys[e.key] = false;
    };
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [started, gameOver]);

  useEffect(() => {
    if (!started || gameOver) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let running = true;
    const loop = () => {
      if (!running) return;
      const g = gameRef.current;
      g.animFrame++;

      // Player movement
      const keys = g.keys;
      if (keys['ArrowLeft'] || keys['a'] || keys['A']) g.player.vx = -6;
      else if (keys['ArrowRight'] || keys['d'] || keys['D']) g.player.vx = 6;
      else g.player.vx *= 0.8;

      // Gravity
      g.player.vy += 0.6;
      g.player.x += g.player.vx;
      g.player.y += g.player.vy;

      // Wrap around
      if (g.player.x < -g.player.width) g.player.x = canvas.width;
      if (g.player.x > canvas.width) g.player.x = -g.player.width;

      // Platform collision
      g.player.onGround = false;
      for (const plat of g.platforms) {
        // Update moving platforms
        if (plat.type === 'moving' && plat.origX !== undefined && plat.moveRange) {
          plat.x = plat.origX + Math.sin(g.animFrame * 0.02) * plat.moveRange;
        }

        if (
          g.player.vy >= 0 &&
          g.player.x + g.player.width > plat.x &&
          g.player.x < plat.x + plat.width &&
          g.player.y + g.player.height >= plat.y &&
          g.player.y + g.player.height <= plat.y + 15
        ) {
          g.player.y = plat.y - g.player.height;
          g.player.vy = 0;
          g.player.onGround = true;
          g.player.jumps = 0;

          if (plat.type === 'crumbling') {
            plat.width = 0;
          }
        }
      }

      // Coins
      for (const coin of g.coins) {
        if (!coin.collected) {
          const dx = g.player.x + g.player.width / 2 - coin.x;
          const dy = g.player.y + g.player.height / 2 - coin.y;
          if (Math.sqrt(dx * dx + dy * dy) < 25) {
            coin.collected = true;
            g.score += 10;
            for (let i = 0; i < 8; i++) {
              g.particles.push({
                x: coin.x,
                y: coin.y,
                vx: (Math.random() - 0.5) * 6,
                vy: (Math.random() - 0.5) * 6,
                life: 25,
                color: '#fbbf24',
              });
            }
          }
        }
      }

      // Scroll camera
      const targetScroll = g.player.y - canvas.height * 0.4;
      if (targetScroll < g.scrollY) {
        g.scrollY += (targetScroll - g.scrollY) * 0.1;
      }

      // Score based on height
      const heightScore = Math.max(0, Math.floor((380 - g.player.y) / 10));
      if (g.player.y < g.highestY) {
        g.highestY = g.player.y;
        g.score = Math.max(g.score, heightScore);
      }
      setScore(g.score);

      // Fall death
      if (g.player.y > g.scrollY + canvas.height + 100) {
        running = false;
        setGameOver(true);
        if (isLoggedIn) {
          addCoins(Math.floor(g.score / 2));
          addXP(Math.floor(g.score / 3));
          incrementGamesPlayed();
        }
        return;
      }

      // Update particles
      g.particles = g.particles.filter(p => {
        p.x += p.vx;
        p.y += p.vy;
        p.life--;
        return p.life > 0;
      });

      // Draw
      ctx.fillStyle = '#1a1a2e';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Stars background
      for (let i = 0; i < 50; i++) {
        const sx = (i * 97) % canvas.width;
        const sy = ((i * 73 + g.scrollY * 0.1) % canvas.height);
        ctx.fillStyle = `rgba(255,255,255,${0.3 + Math.sin(g.animFrame * 0.05 + i) * 0.2})`;
        ctx.fillRect(sx, sy, 2, 2);
      }

      ctx.save();
      ctx.translate(0, -g.scrollY);

      // Platforms
      for (const plat of g.platforms) {
        if (plat.y > g.scrollY - 20 && plat.y < g.scrollY + canvas.height + 20) {
          ctx.fillStyle = plat.color;
          ctx.shadowColor = plat.color;
          ctx.shadowBlur = 8;
          const radius = 6;
          ctx.beginPath();
          ctx.roundRect(plat.x, plat.y, plat.width, 12, radius);
          ctx.fill();
          ctx.shadowBlur = 0;

          if (plat.type === 'moving') {
            ctx.fillStyle = 'rgba(255,255,255,0.3)';
            ctx.beginPath();
            ctx.roundRect(plat.x + 4, plat.y + 2, plat.width - 8, 4, 2);
            ctx.fill();
          }
          if (plat.type === 'crumbling') {
            ctx.strokeStyle = 'rgba(255,0,0,0.5)';
            ctx.lineWidth = 1;
            ctx.setLineDash([3, 3]);
            ctx.strokeRect(plat.x, plat.y, plat.width, 12);
            ctx.setLineDash([]);
          }
        }
      }

      // Coins
      for (const coin of g.coins) {
        if (!coin.collected && coin.y > g.scrollY - 20 && coin.y < g.scrollY + canvas.height + 20) {
          ctx.fillStyle = '#fbbf24';
          ctx.shadowColor = '#fbbf24';
          ctx.shadowBlur = 10;
          ctx.beginPath();
          ctx.arc(coin.x, coin.y, 8 + Math.sin(g.animFrame * 0.1) * 2, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#f59e0b';
          ctx.beginPath();
          ctx.arc(coin.x, coin.y, 5, 0, Math.PI * 2);
          ctx.fill();
          ctx.shadowBlur = 0;
        }
      }

      // Particles
      for (const p of g.particles) {
        ctx.globalAlpha = p.life / 25;
        ctx.fillStyle = p.color;
        ctx.fillRect(p.x - 2, p.y - 2, 4, 4);
      }
      ctx.globalAlpha = 1;

      // Player
      const px = g.player.x;
      const py = g.player.y;
      const pw = g.player.width;
      const ph = g.player.height;

      // Shadow
      ctx.fillStyle = 'rgba(0,0,0,0.3)';
      ctx.beginPath();
      ctx.ellipse(px + pw / 2, py + ph + 2, pw / 2, 4, 0, 0, Math.PI * 2);
      ctx.fill();

      // Body
      ctx.fillStyle = '#10b981';
      ctx.shadowColor = '#10b981';
      ctx.shadowBlur = 15;
      ctx.beginPath();
      ctx.roundRect(px, py, pw, ph, 6);
      ctx.fill();
      ctx.shadowBlur = 0;

      // Face
      ctx.fillStyle = 'white';
      ctx.fillRect(px + 8, py + 10, 5, 5);
      ctx.fillRect(px + 18, py + 10, 5, 5);
      ctx.fillStyle = '#1a1a2e';
      ctx.fillRect(px + 9, py + 11, 3, 3);
      ctx.fillRect(px + 19, py + 11, 3, 3);
      // Mouth
      ctx.fillStyle = 'white';
      ctx.fillRect(px + 10, py + 20, 10, 3);

      ctx.restore();

      requestAnimationFrame(loop);
    };

    loop();
    return () => { running = false; };
  }, [started, gameOver, isLoggedIn, addCoins, addXP, incrementGamesPlayed]);

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="flex items-center justify-between w-full max-w-lg">
        <div className="text-white font-bold text-lg">Score: {score}</div>
        <button onClick={onExit} className="text-gray-400 hover:text-white text-sm px-3 py-1 bg-gray-800 rounded-lg">
          Exit Game
        </button>
      </div>

      <div className="relative rounded-xl overflow-hidden border-2 border-gray-700 shadow-2xl">
        <canvas ref={canvasRef} width={450} height={500} className="bg-gray-900" />

        {!started && (
          <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center">
            <h2 className="text-4xl font-bold text-white mb-2">🏃 Obby Jumper</h2>
            <p className="text-gray-300 mb-2">Jump as high as you can!</p>
            <p className="text-gray-400 text-sm mb-6">Arrow keys / WASD to move, Space / Up to jump</p>
            <p className="text-yellow-400 text-sm mb-4">Double jump available! Collect coins for bonus points!</p>
            <button onClick={startGame} className="bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold px-8 py-3 rounded-xl hover:from-green-600 hover:to-emerald-700 transition-all shadow-lg">
              Start Game
            </button>
          </div>
        )}

        {gameOver && (
          <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center">
            <h2 className="text-3xl font-bold text-white mb-2">Game Over!</h2>
            <p className="text-2xl text-yellow-400 font-bold mb-1">Score: {score}</p>
            {isLoggedIn && (
              <p className="text-green-400 text-sm mb-4">+{Math.floor(score / 2)} coins, +{Math.floor(score / 3)} XP</p>
            )}
            <div className="flex gap-3">
              <button onClick={startGame} className="bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold px-6 py-3 rounded-xl hover:from-green-600 hover:to-emerald-700 transition-all shadow-lg">
                Play Again
              </button>
              <button onClick={onExit} className="bg-gray-700 text-white font-bold px-6 py-3 rounded-xl hover:bg-gray-600 transition-all">
                Exit
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="text-gray-400 text-sm text-center">
        <p>⬅️➡️ Move | ⬆️/Space Jump | Double jump available!</p>
      </div>
    </div>
  );
}
