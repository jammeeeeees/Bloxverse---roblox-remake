import { useState, useEffect, useCallback, useRef } from 'react';
import { useAuthStore } from '../store/authStore';
import { useSocialStore } from '../store/socialStore';
import AvatarDisplay from '../components/AvatarDisplay';

interface Position {
  x: number;
  y: number;
}

interface Survivor {
  id: string;
  name: string;
  pos: Position;
  avatar: any;
  health: number;
  alive: boolean;
}

interface Zombie {
  id: number;
  x: number;
  y: number;
  health: number;
  speed: number;
}

interface Bullet {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
}

const ARENA_WIDTH = 500;
const ARENA_HEIGHT = 400;

export default function ZombieSurvivalGame({ onExit }: { onExit: () => void }) {
  const { user, addCoins, addXP, incrementGamesPlayed, isLoggedIn } = useAuthStore();
  const { currentLobby, getRandomPlayers } = useSocialStore();
  
  const [survivors, setSurvivors] = useState<Survivor[]>([]);
  const [zombies, setZombies] = useState<Zombie[]>([]);
  const [bullets, setBullets] = useState<Bullet[]>([]);
  const [wave, setWave] = useState(1);
  const [score, setScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [started, setStarted] = useState(false);
  const [zombiesRemaining, setZombiesRemaining] = useState(0);
  
  const keysRef = useRef<Set<string>>(new Set());
  const bulletIdRef = useRef(0);
  const zombieIdRef = useRef(0);
  const lastShootRef = useRef(0);

  const spawnZombies = useCallback((count: number) => {
    const newZombies: Zombie[] = [];
    for (let i = 0; i < count; i++) {
      const side = Math.floor(Math.random() * 4);
      let x = 0, y = 0;
      switch (side) {
        case 0: x = Math.random() * ARENA_WIDTH; y = -20; break;
        case 1: x = ARENA_WIDTH + 20; y = Math.random() * ARENA_HEIGHT; break;
        case 2: x = Math.random() * ARENA_WIDTH; y = ARENA_HEIGHT + 20; break;
        case 3: x = -20; y = Math.random() * ARENA_HEIGHT; break;
      }
      newZombies.push({
        id: zombieIdRef.current++,
        x, y,
        health: 20 + wave * 5,
        speed: 1 + wave * 0.2,
      });
    }
    setZombies(prev => [...prev, ...newZombies]);
    setZombiesRemaining(prev => prev + count);
  }, [wave]);

  const startGame = useCallback(() => {
    const initialSurvivors: Survivor[] = [];
    
    if (user) {
      initialSurvivors.push({
        id: user.id,
        name: user.displayName,
        pos: { x: ARENA_WIDTH / 2, y: ARENA_HEIGHT / 2 },
        avatar: user.equippedAvatar,
        health: 100,
        alive: true,
      });
    }
    
    const aiPlayers = currentLobby?.players.filter(p => p.id !== user?.id) || getRandomPlayers(2, user ? [user.id] : []);
    const positions = [
      { x: ARENA_WIDTH / 2 - 50, y: ARENA_HEIGHT / 2 },
      { x: ARENA_WIDTH / 2 + 50, y: ARENA_HEIGHT / 2 },
    ];
    
    aiPlayers.slice(0, 2).forEach((p, i) => {
      initialSurvivors.push({
        id: p.id,
        name: p.displayName,
        pos: positions[i],
        avatar: p.avatar,
        health: 100,
        alive: true,
      });
    });
    
    setSurvivors(initialSurvivors);
    setZombies([]);
    setBullets([]);
    setWave(1);
    setScore(0);
    setGameOver(false);
    setStarted(true);
    setZombiesRemaining(0);
    zombieIdRef.current = 0;
    bulletIdRef.current = 0;
    
    // Spawn first wave
    setTimeout(() => spawnZombies(5), 1000);
  }, [user, currentLobby, getRandomPlayers, spawnZombies]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      keysRef.current.add(e.key.toLowerCase());
    };
    const handleKeyUp = (e: KeyboardEvent) => keysRef.current.delete(e.key.toLowerCase());
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  // Game loop
  useEffect(() => {
    if (!started || gameOver) return;

    const interval = setInterval(() => {
      // Move player
      setSurvivors(prev => {
        return prev.map(s => {
          if (!s.alive) return s;
          
          if (s.id === user?.id) {
            let newX = s.pos.x;
            let newY = s.pos.y;
            
            if (keysRef.current.has('w') || keysRef.current.has('arrowup')) newY -= 4;
            if (keysRef.current.has('s') || keysRef.current.has('arrowdown')) newY += 4;
            if (keysRef.current.has('a') || keysRef.current.has('arrowleft')) newX -= 4;
            if (keysRef.current.has('d') || keysRef.current.has('arrowright')) newX += 4;
            
            newX = Math.max(20, Math.min(ARENA_WIDTH - 20, newX));
            newY = Math.max(20, Math.min(ARENA_HEIGHT - 20, newY));
            
            // Shoot
            if (keysRef.current.has(' ') && Date.now() - lastShootRef.current > 200) {
              lastShootRef.current = Date.now();
              // Find nearest zombie
              const nearestZombie = zombies.reduce<Zombie | null>((nearest, z) => {
                const dist = Math.sqrt(Math.pow(z.x - newX, 2) + Math.pow(z.y - newY, 2));
                if (!nearest) return z;
                const nearestDist = Math.sqrt(Math.pow(nearest.x - newX, 2) + Math.pow(nearest.y - newY, 2));
                return dist < nearestDist ? z : nearest;
              }, null);
              
              if (nearestZombie) {
                const dx = nearestZombie.x - newX;
                const dy = nearestZombie.y - newY;
                const dist = Math.sqrt(dx * dx + dy * dy);
                setBullets(b => [...b, {
                  id: bulletIdRef.current++,
                  x: newX,
                  y: newY,
                  vx: (dx / dist) * 12,
                  vy: (dy / dist) * 12,
                }]);
              }
            }
            
            return { ...s, pos: { x: newX, y: newY } };
          } else {
            // AI survivors
            const nearestZombie = zombies.reduce<Zombie | null>((nearest, z) => {
              const dist = Math.sqrt(Math.pow(z.x - s.pos.x, 2) + Math.pow(z.y - s.pos.y, 2));
              if (!nearest) return z;
              const nearestDist = Math.sqrt(Math.pow(nearest.x - s.pos.x, 2) + Math.pow(nearest.y - s.pos.y, 2));
              return dist < nearestDist ? z : nearest;
            }, null);
            
            if (nearestZombie) {
              const dx = nearestZombie.x - s.pos.x;
              const dy = nearestZombie.y - s.pos.y;
              const dist = Math.sqrt(dx * dx + dy * dy);
              
              // Run away if too close
              let newX = s.pos.x;
              let newY = s.pos.y;
              if (dist < 80) {
                newX -= (dx / dist) * 2;
                newY -= (dy / dist) * 2;
              }
              
              // Shoot occasionally
              if (Math.random() < 0.15) {
                setBullets(b => [...b, {
                  id: bulletIdRef.current++,
                  x: s.pos.x,
                  y: s.pos.y,
                  vx: (dx / dist) * 10,
                  vy: (dy / dist) * 10,
                }]);
              }
              
              newX = Math.max(20, Math.min(ARENA_WIDTH - 20, newX));
              newY = Math.max(20, Math.min(ARENA_HEIGHT - 20, newY));
              return { ...s, pos: { x: newX, y: newY } };
            }
            return s;
          }
        });
      });
      
      // Move bullets and check hits
      setBullets(prev => {
        return prev.filter(b => {
          const newX = b.x + b.vx;
          const newY = b.y + b.vy;
          
          if (newX < 0 || newX > ARENA_WIDTH || newY < 0 || newY > ARENA_HEIGHT) return false;
          
          let hit = false;
          setZombies(zombies => {
            return zombies.filter(z => {
              const dist = Math.sqrt(Math.pow(z.x - newX, 2) + Math.pow(z.y - newY, 2));
              if (dist < 20) {
                hit = true;
                z.health -= 25;
                if (z.health <= 0) {
                  setScore(s => s + 10);
                  setZombiesRemaining(r => r - 1);
                  return false;
                }
              }
              return true;
            });
          });
          
          if (hit) return false;
          b.x = newX;
          b.y = newY;
          return true;
        });
      });
      
      // Move zombies
      setZombies(prev => {
        return prev.map(z => {
          // Find nearest survivor
          const aliveSurvivors = survivors.filter(s => s.alive);
          if (aliveSurvivors.length === 0) return z;
          
          const nearest = aliveSurvivors.reduce((n, s) => {
            const dist = Math.sqrt(Math.pow(s.pos.x - z.x, 2) + Math.pow(s.pos.y - z.y, 2));
            const nDist = Math.sqrt(Math.pow(n.pos.x - z.x, 2) + Math.pow(n.pos.y - z.y, 2));
            return dist < nDist ? s : n;
          });
          
          const dx = nearest.pos.x - z.x;
          const dy = nearest.pos.y - z.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          
          // Attack if close
          if (dist < 25) {
            setSurvivors(ss => ss.map(s => {
              if (s.id === nearest.id) {
                const newHealth = s.health - 1;
                if (newHealth <= 0) {
                  return { ...s, health: 0, alive: false };
                }
                return { ...s, health: newHealth };
              }
              return s;
            }));
          }
          
          return {
            ...z,
            x: z.x + (dx / dist) * z.speed,
            y: z.y + (dy / dist) * z.speed,
          };
        });
      });
      
      // Check game over
      setSurvivors(prev => {
        const allDead = prev.every(s => !s.alive);
        const playerDead = !prev.find(s => s.id === user?.id)?.alive;
        
        if (allDead || playerDead) {
          if (!gameOver) {
            setGameOver(true);
            if (isLoggedIn) {
              addCoins(score + wave * 20);
              addXP(Math.floor((score + wave * 20) / 2));
              incrementGamesPlayed();
            }
          }
        }
        return prev;
      });
      
      // Next wave
      if (zombiesRemaining === 0 && zombies.length === 0 && started && !gameOver) {
        setWave(w => {
          const nextWave = w + 1;
          setTimeout(() => spawnZombies(5 + nextWave * 2), 2000);
          return nextWave;
        });
      }
      
    }, 50);

    return () => clearInterval(interval);
  }, [started, gameOver, user, zombies, survivors, zombiesRemaining, score, wave, isLoggedIn, addCoins, addXP, incrementGamesPlayed, spawnZombies]);

  const myPlayer = survivors.find(s => s.id === user?.id);

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="flex items-center justify-between w-full max-w-xl">
        <div>
          <div className="text-white font-bold text-lg">🧟 Zombie Survival</div>
          {started && !gameOver && (
            <div className="text-green-400 text-sm">
              Wave {wave} • Score: {score} • HP: {myPlayer?.health || 0}
            </div>
          )}
        </div>
        <button onClick={onExit} className="text-gray-400 hover:text-white text-sm px-3 py-1 bg-gray-800 rounded-lg border border-gray-700">
          Exit
        </button>
      </div>

      {/* Survivor health bars */}
      {started && !gameOver && (
        <div className="flex gap-4 flex-wrap justify-center">
          {survivors.map(s => (
            <div key={s.id} className={`flex items-center gap-2 px-3 py-1 rounded-lg ${s.id === user?.id ? 'bg-green-500/20 border border-green-500/30' : 'bg-gray-800'} ${!s.alive ? 'opacity-50' : ''}`}>
              <span className="text-xs">{s.name.slice(0, 8)}</span>
              <div className="w-16 h-2 bg-gray-700 rounded-full overflow-hidden">
                <div
                  className={`h-full transition-all ${s.health > 50 ? 'bg-green-500' : s.health > 25 ? 'bg-yellow-500' : 'bg-red-500'}`}
                  style={{ width: `${s.health}%` }}
                />
              </div>
              {!s.alive && <span className="text-red-400">💀</span>}
            </div>
          ))}
        </div>
      )}

      <div
        className="relative rounded-xl overflow-hidden border-2 border-gray-700 shadow-2xl"
        style={{ width: ARENA_WIDTH, height: ARENA_HEIGHT, background: '#1a1a2e' }}
      >
        {/* Blood splatters (decoration) */}
        <div className="absolute top-10 left-20 w-8 h-8 bg-red-900/30 rounded-full blur-sm" />
        <div className="absolute bottom-20 right-30 w-6 h-6 bg-red-900/20 rounded-full blur-sm" />

        {/* Bullets */}
        {bullets.map(b => (
          <div
            key={b.id}
            className="absolute w-2 h-2 bg-yellow-400 rounded-full"
            style={{ left: b.x - 4, top: b.y - 4, boxShadow: '0 0 8px #fbbf24' }}
          />
        ))}

        {/* Zombies */}
        {zombies.map(z => (
          <div
            key={z.id}
            className="absolute flex items-center justify-center text-2xl transition-all duration-100"
            style={{ left: z.x - 15, top: z.y - 15, width: 30, height: 30 }}
          >
            🧟
          </div>
        ))}

        {/* Survivors */}
        {survivors.map(s => s.alive && (
          <div
            key={s.id}
            className="absolute transition-all duration-75"
            style={{ left: s.pos.x - 20, top: s.pos.y - 20, width: 40, height: 40 }}
          >
            <div className={`scale-75 ${s.id === user?.id ? 'ring-2 ring-green-400 ring-offset-2 ring-offset-transparent rounded-full' : ''}`}>
              <AvatarDisplay size="sm" equipped={s.avatar} showPet={false} showAura={false} />
            </div>
          </div>
        ))}

        {/* Wave announcement */}
        {zombiesRemaining === 0 && zombies.length === 0 && started && !gameOver && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="bg-black/70 px-8 py-4 rounded-xl">
              <p className="text-2xl font-bold text-green-400">Wave {wave} Complete!</p>
              <p className="text-gray-400 text-sm text-center">Next wave incoming...</p>
            </div>
          </div>
        )}

        {/* Start screen */}
        {!started && (
          <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center">
            <div className="text-6xl mb-4">🧟</div>
            <h2 className="text-2xl font-bold text-white mb-2">Zombie Survival</h2>
            <p className="text-gray-400 text-center mb-4 max-w-xs">
              Survive waves of zombies with your team! How long can you last?
            </p>
            <p className="text-green-400 text-sm mb-4">WASD to move • SPACE to shoot</p>
            <button
              onClick={startGame}
              className="bg-gradient-to-r from-green-600 to-emerald-700 text-white font-bold px-8 py-3 rounded-xl hover:from-green-700 hover:to-emerald-800 transition-all shadow-lg"
            >
              Start Survival! 🔫
            </button>
          </div>
        )}

        {/* Game over */}
        {gameOver && (
          <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center">
            <div className="text-6xl mb-4">💀</div>
            <h2 className="text-2xl font-bold text-red-400 mb-2">Game Over</h2>
            <p className="text-white text-lg">Survived {wave} waves</p>
            <p className="text-yellow-400">Score: {score}</p>
            {isLoggedIn && (
              <p className="text-green-400 text-sm mt-2">+{score + wave * 20} coins, +{Math.floor((score + wave * 20) / 2)} XP</p>
            )}
            <div className="flex gap-3 mt-4">
              <button onClick={startGame} className="bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold px-6 py-3 rounded-xl hover:from-green-600 hover:to-emerald-700 transition-all shadow-lg">
                Try Again
              </button>
              <button onClick={onExit} className="bg-gray-700 text-white font-bold px-6 py-3 rounded-xl hover:bg-gray-600 transition-all">
                Exit
              </button>
            </div>
          </div>
        )}
      </div>

      <p className="text-gray-400 text-sm">WASD to move • SPACE to shoot (auto-aim) • 🧟 = Zombies</p>
    </div>
  );
}
