import { useState, useEffect, useRef, useCallback } from 'react';
import { useAuthStore } from '../store/authStore';

interface Upgrade {
  id: string;
  name: string;
  description: string;
  cost: number;
  cps: number; // coins per second
  cpc: number; // coins per click bonus
  owned: number;
  emoji: string;
}

export default function ClickerGame({ onExit }: { onExit: () => void }) {
  const { addCoins, addXP, incrementGamesPlayed, isLoggedIn } = useAuthStore();
  const [coins, setCoins] = useState(0);
  const [totalCoins, setTotalCoins] = useState(0);
  const [cps, setCps] = useState(0);
  const [cpc, setCpc] = useState(1);
  const [clickEffects, setClickEffects] = useState<{ id: number; x: number; y: number; amount: number }[]>([]);
  const [upgrades, setUpgrades] = useState<Upgrade[]>([
    { id: 'cursor', name: 'Auto Clicker', description: '+0.1 coins/sec', cost: 15, cps: 0.1, cpc: 0, owned: 0, emoji: '🖱️' },
    { id: 'worker', name: 'Worker', description: '+1 coins/sec', cost: 100, cps: 1, cpc: 0, owned: 0, emoji: '👷' },
    { id: 'factory', name: 'Factory', description: '+5 coins/sec', cost: 500, cps: 5, cpc: 0, owned: 0, emoji: '🏭' },
    { id: 'gloves', name: 'Click Gloves', description: '+2 coins/click', cost: 50, cps: 0, cpc: 2, owned: 0, emoji: '🧤' },
    { id: 'robot', name: 'Robot Arm', description: '+20 coins/sec', cost: 2000, cps: 20, cpc: 0, owned: 0, emoji: '🤖' },
    { id: 'magic', name: 'Magic Touch', description: '+10 coins/click', cost: 500, cps: 0, cpc: 10, owned: 0, emoji: '✨' },
    { id: 'mine', name: 'Gold Mine', description: '+50 coins/sec', cost: 5000, cps: 50, cpc: 0, owned: 0, emoji: '⛏️' },
    { id: 'rocket', name: 'Rocket Lab', description: '+200 coins/sec', cost: 20000, cps: 200, cpc: 0, owned: 0, emoji: '🚀' },
  ]);
  const [exitRewards, setExitRewards] = useState(false);
  const hasCountedRef = useRef(false);

  const nextEffectId = useRef(0);

  // CPS tick
  useEffect(() => {
    const interval = setInterval(() => {
      if (cps > 0) {
        setCoins(c => c + cps / 10);
        setTotalCoins(c => c + cps / 10);
      }
    }, 100);
    return () => clearInterval(interval);
  }, [cps]);

  const handleClick = useCallback((e: React.MouseEvent<HTMLButtonElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const id = nextEffectId.current++;

    setCoins(c => c + cpc);
    setTotalCoins(c => c + cpc);
    setClickEffects(prev => [...prev, { id, x, y, amount: cpc }]);
    setTimeout(() => {
      setClickEffects(prev => prev.filter(e => e.id !== id));
    }, 800);
  }, [cpc]);

  const buyUpgrade = (index: number) => {
    const up = upgrades[index];
    if (coins >= up.cost) {
      setCoins(c => c - up.cost);
      const newUpgrades = [...upgrades];
      newUpgrades[index] = {
        ...up,
        owned: up.owned + 1,
        cost: Math.floor(up.cost * 1.15),
      };
      setUpgrades(newUpgrades);

      if (up.cps > 0) setCps(c => c + up.cps);
      if (up.cpc > 0) setCpc(c => c + up.cpc);
    }
  };

  const handleExit = () => {
    if (isLoggedIn && !hasCountedRef.current) {
      const earnedCoins = Math.floor(totalCoins / 10);
      const earnedXP = Math.floor(totalCoins / 5);
      addCoins(earnedCoins);
      addXP(earnedXP);
      incrementGamesPlayed();
      hasCountedRef.current = true;
    }
    setExitRewards(true);
  };

  if (exitRewards) {
    return (
      <div className="flex flex-col items-center gap-4 p-8">
        <h2 className="text-3xl font-bold text-white">🏭 Coin Tycoon - Results</h2>
        <div className="bg-gray-800 rounded-2xl p-8 text-center border border-gray-700 max-w-md w-full">
          <p className="text-yellow-400 text-4xl font-bold mb-2">{Math.floor(totalCoins).toLocaleString()}</p>
          <p className="text-gray-400 mb-4">Total Coins Earned</p>
          {isLoggedIn && (
            <div className="space-y-2 bg-gray-700/50 rounded-xl p-4 mb-4">
              <p className="text-green-400">+{Math.floor(totalCoins / 10)} BloxCoins</p>
              <p className="text-blue-400">+{Math.floor(totalCoins / 5)} XP</p>
            </div>
          )}
          <button onClick={onExit} className="bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold px-8 py-3 rounded-xl hover:from-green-600 hover:to-emerald-700 transition-all shadow-lg">
            Back to Games
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="flex items-center justify-between w-full max-w-3xl">
        <div>
          <div className="text-yellow-400 font-bold text-2xl">💰 {Math.floor(coins).toLocaleString()}</div>
          <div className="text-gray-400 text-sm">{cps.toFixed(1)} coins/sec • {cpc} coins/click</div>
        </div>
        <button onClick={handleExit} className="text-gray-400 hover:text-white text-sm px-3 py-1 bg-gray-800 rounded-lg border border-gray-700">
          Save & Exit
        </button>
      </div>

      <div className="flex flex-col md:flex-row gap-6 w-full max-w-3xl">
        {/* Click Area */}
        <div className="flex-1 flex flex-col items-center gap-4">
          <div className="relative">
            <button
              onClick={handleClick}
              className="w-48 h-48 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center text-7xl shadow-2xl shadow-yellow-500/30 hover:shadow-yellow-500/50 active:scale-95 transition-transform border-4 border-yellow-300 hover:from-yellow-300 hover:to-orange-400 select-none"
            >
              🪙
            </button>
            {clickEffects.map((effect) => (
              <div
                key={effect.id}
                className="absolute pointer-events-none text-yellow-300 font-bold text-xl animate-bounce"
                style={{
                  left: effect.x,
                  top: effect.y,
                  animation: 'floatUp 0.8s ease-out forwards',
                }}
              >
                +{effect.amount}
              </div>
            ))}
          </div>
          <p className="text-gray-500 text-sm">Click the coin!</p>

          {/* Stats */}
          <div className="grid grid-cols-2 gap-3 w-full">
            <div className="bg-gray-800 rounded-xl p-3 text-center border border-gray-700">
              <p className="text-gray-400 text-xs">Total Earned</p>
              <p className="text-white font-bold">{Math.floor(totalCoins).toLocaleString()}</p>
            </div>
            <div className="bg-gray-800 rounded-xl p-3 text-center border border-gray-700">
              <p className="text-gray-400 text-xs">Upgrades</p>
              <p className="text-white font-bold">{upgrades.reduce((s, u) => s + u.owned, 0)}</p>
            </div>
          </div>
        </div>

        {/* Upgrades */}
        <div className="flex-1">
          <h3 className="text-white font-bold mb-3 text-lg">Upgrades</h3>
          <div className="space-y-2 max-h-96 overflow-y-auto pr-2">
            {upgrades.map((up, i) => (
              <button
                key={up.id}
                onClick={() => buyUpgrade(i)}
                disabled={coins < up.cost}
                className={`w-full flex items-center gap-3 p-3 rounded-xl border transition-all text-left ${
                  coins >= up.cost
                    ? 'bg-gray-800 border-gray-600 hover:border-yellow-500/50 hover:bg-gray-700'
                    : 'bg-gray-800/50 border-gray-700/50 opacity-50 cursor-not-allowed'
                }`}
              >
                <span className="text-3xl">{up.emoji}</span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="text-white font-medium text-sm">{up.name}</p>
                    <span className="text-gray-500 text-xs">x{up.owned}</span>
                  </div>
                  <p className="text-gray-400 text-xs">{up.description}</p>
                  <p className="text-yellow-400 text-xs font-medium mt-1">💰 {up.cost.toLocaleString()}</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes floatUp {
          0% { opacity: 1; transform: translateY(0); }
          100% { opacity: 0; transform: translateY(-60px); }
        }
      `}</style>
    </div>
  );
}
