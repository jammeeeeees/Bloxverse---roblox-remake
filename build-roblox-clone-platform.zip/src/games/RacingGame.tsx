import { useState, useEffect, useCallback, useRef } from 'react';
import { useAuthStore } from '../store/authStore';
import { useSocialStore } from '../store/socialStore';

interface Racer {
  id: string;
  name: string;
  x: number;
  y: number;
  speed: number;
  lap: number;
  checkpoint: number;
  avatar: any;
  finished: boolean;
  finishTime: number;
}

const TRACK_WIDTH = 500;
const TRACK_HEIGHT = 400;
const CAR_SIZE = 30;

export default function RacingGame({ onExit }: { onExit: () => void }) {
  const { user, addCoins, addXP, incrementGamesPlayed, isLoggedIn } = useAuthStore();
  const { currentLobby, getRandomPlayers } = useSocialStore();
  
  const [racers, setRacers] = useState<Racer[]>([]);
  const [gameOver, setGameOver] = useState(false);
  const [started, setStarted] = useState(false);
  const [countdown, setCountdown] = useState(3);
  const [raceTime, setRaceTime] = useState(0);
  const [winner, setWinner] = useState<Racer | null>(null);
  
  const keysRef = useRef<Set<string>>(new Set());
  const startTimeRef = useRef(0);

  // Checkpoints for the track (simplified oval)
  const checkpoints = [
    { x: 400, y: 100 },
    { x: 400, y: 300 },
    { x: 100, y: 300 },
    { x: 100, y: 100 },
  ];

  const startGame = useCallback(() => {
    const initialRacers: Racer[] = [];
    const startPositions = [
      { x: 100, y: 80 },
      { x: 100, y: 120 },
      { x: 140, y: 80 },
      { x: 140, y: 120 },
    ];
    
    if (user) {
      initialRacers.push({
        id: user.id,
        name: user.displayName,
        x: startPositions[0].x,
        y: startPositions[0].y,
        speed: 0,
        lap: 0,
        checkpoint: 0,
        avatar: user.equippedAvatar,
        finished: false,
        finishTime: 0,
      });
    }
    
    const aiPlayers = currentLobby?.players.filter(p => p.id !== user?.id) || getRandomPlayers(3, user ? [user.id] : []);
    aiPlayers.slice(0, 3).forEach((p, i) => {
      initialRacers.push({
        id: p.id,
        name: p.displayName,
        x: startPositions[i + 1].x,
        y: startPositions[i + 1].y,
        speed: 0,
        lap: 0,
        checkpoint: 0,
        avatar: p.avatar,
        finished: false,
        finishTime: 0,
      });
    });
    
    setRacers(initialRacers);
    setGameOver(false);
    setStarted(false);
    setCountdown(3);
    setWinner(null);
    setRaceTime(0);
    
    // Countdown
    let count = 3;
    const countdownInterval = setInterval(() => {
      count--;
      setCountdown(count);
      if (count <= 0) {
        clearInterval(countdownInterval);
        setStarted(true);
        startTimeRef.current = Date.now();
      }
    }, 1000);
  }, [user, currentLobby, getRandomPlayers]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => keysRef.current.add(e.key.toLowerCase());
    const handleKeyUp = (e: KeyboardEvent) => keysRef.current.delete(e.key.toLowerCase());
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  useEffect(() => {
    if (!started || gameOver) return;

    const interval = setInterval(() => {
      setRaceTime(Date.now() - startTimeRef.current);
      
      setRacers(prev => {
        return prev.map(racer => {
          if (racer.finished) return racer;
          
          let newX = racer.x;
          let newY = racer.y;
          let newSpeed = racer.speed;
          
          const isPlayer = racer.id === user?.id;
          
          if (isPlayer) {
            // Player controls
            if (keysRef.current.has('w') || keysRef.current.has('arrowup')) {
              newSpeed = Math.min(8, newSpeed + 0.5);
            } else {
              newSpeed = Math.max(0, newSpeed - 0.2);
            }
            
            // Steering based on current target checkpoint
            const target = checkpoints[racer.checkpoint];
            const dx = target.x - racer.x;
            const dy = target.y - racer.y;
            const angle = Math.atan2(dy, dx);
            
            let steerAngle = angle;
            if (keysRef.current.has('a') || keysRef.current.has('arrowleft')) steerAngle -= 0.3;
            if (keysRef.current.has('d') || keysRef.current.has('arrowright')) steerAngle += 0.3;
            
            newX += Math.cos(steerAngle) * newSpeed;
            newY += Math.sin(steerAngle) * newSpeed;
          } else {
            // AI - follow track
            const target = checkpoints[racer.checkpoint];
            const dx = target.x - racer.x;
            const dy = target.y - racer.y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            
            newSpeed = 4 + Math.random() * 2;
            newX += (dx / dist) * newSpeed;
            newY += (dy / dist) * newSpeed;
          }
          
          // Keep on track
          newX = Math.max(20, Math.min(TRACK_WIDTH - 20, newX));
          newY = Math.max(20, Math.min(TRACK_HEIGHT - 20, newY));
          
          // Check checkpoint
          let newCheckpoint = racer.checkpoint;
          let newLap = racer.lap;
          const target = checkpoints[racer.checkpoint];
          const distToCheckpoint = Math.sqrt(Math.pow(newX - target.x, 2) + Math.pow(newY - target.y, 2));
          
          if (distToCheckpoint < 40) {
            newCheckpoint = (racer.checkpoint + 1) % checkpoints.length;
            if (newCheckpoint === 0) {
              newLap++;
              if (newLap >= 3 && !racer.finished) {
                // Finished!
                if (!winner) {
                  setWinner({ ...racer, lap: newLap, finishTime: Date.now() - startTimeRef.current });
                }
                return { ...racer, x: newX, y: newY, speed: newSpeed, checkpoint: newCheckpoint, lap: newLap, finished: true, finishTime: Date.now() - startTimeRef.current };
              }
            }
          }
          
          return { ...racer, x: newX, y: newY, speed: newSpeed, checkpoint: newCheckpoint, lap: newLap };
        });
      });
      
      // Check if all finished or player finished
      setRacers(prev => {
        const allFinished = prev.every(r => r.finished);
        const playerFinished = prev.find(r => r.id === user?.id)?.finished;
        
        if (allFinished || playerFinished) {
          if (!gameOver) {
            setGameOver(true);
            if (isLoggedIn) {
              const myRacer = prev.find(r => r.id === user?.id);
              const position = prev.filter(r => r.finished && r.finishTime < (myRacer?.finishTime || Infinity)).length + 1;
              const coins = position === 1 ? 150 : position === 2 ? 100 : position === 3 ? 50 : 20;
              addCoins(coins);
              addXP(Math.floor(coins / 2));
              incrementGamesPlayed();
            }
          }
        }
        return prev;
      });
      
    }, 50);

    return () => clearInterval(interval);
  }, [started, gameOver, user, winner, isLoggedIn, addCoins, addXP, incrementGamesPlayed, checkpoints]);

  const myRacer = racers.find(r => r.id === user?.id);
  const sortedRacers = [...racers].sort((a, b) => {
    if (a.finished !== b.finished) return a.finished ? -1 : 1;
    if (a.lap !== b.lap) return b.lap - a.lap;
    return b.checkpoint - a.checkpoint;
  });

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="flex items-center justify-between w-full max-w-xl">
        <div>
          <div className="text-white font-bold text-lg">🏎️ Speed Racers</div>
          {started && !gameOver && (
            <div className="text-cyan-400 text-sm">
              Lap {Math.min(3, (myRacer?.lap || 0) + 1)}/3 • {(raceTime / 1000).toFixed(1)}s
            </div>
          )}
        </div>
        <button onClick={onExit} className="text-gray-400 hover:text-white text-sm px-3 py-1 bg-gray-800 rounded-lg border border-gray-700">
          Exit
        </button>
      </div>

      {/* Leaderboard */}
      {started && (
        <div className="flex gap-2 flex-wrap justify-center">
          {sortedRacers.map((r, i) => (
            <div key={r.id} className={`px-3 py-1 rounded-lg text-sm flex items-center gap-2 ${r.id === user?.id ? 'bg-cyan-500/20 border border-cyan-500/30' : 'bg-gray-800'}`}>
              <span className="font-bold text-white">{i + 1}.</span>
              <span className={r.id === user?.id ? 'text-cyan-400' : 'text-gray-300'}>{r.name.slice(0, 8)}</span>
              {r.finished && <span className="text-green-400">✓</span>}
            </div>
          ))}
        </div>
      )}

      <div
        className="relative rounded-xl overflow-hidden border-2 border-gray-700 shadow-2xl"
        style={{ width: TRACK_WIDTH, height: TRACK_HEIGHT, background: '#1a472a' }}
      >
        {/* Track */}
        <div className="absolute inset-8 border-8 border-gray-400 rounded-full bg-gray-700" />
        <div className="absolute inset-20 bg-green-800 rounded-full" />
        
        {/* Start/Finish line */}
        <div className="absolute left-20 top-16 w-2 h-16 bg-white" />
        <div className="absolute left-20 top-16 w-10 text-xs text-white font-bold">START</div>
        
        {/* Checkpoints */}
        {checkpoints.map((cp, i) => (
          <div
            key={i}
            className="absolute w-3 h-3 rounded-full bg-yellow-400 opacity-50"
            style={{ left: cp.x - 6, top: cp.y - 6 }}
          />
        ))}

        {/* Racers */}
        {racers.map(racer => (
          <div
            key={racer.id}
            className="absolute transition-all duration-50"
            style={{
              left: racer.x - CAR_SIZE / 2,
              top: racer.y - CAR_SIZE / 2,
              width: CAR_SIZE,
              height: CAR_SIZE,
            }}
          >
            <div className={`w-full h-full rounded-lg flex items-center justify-center text-lg ${
              racer.id === user?.id
                ? 'bg-cyan-500 shadow-lg shadow-cyan-500/50'
                : 'bg-red-500'
            }`}>
              🏎️
            </div>
            <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 text-[8px] text-white font-bold whitespace-nowrap">
              {racer.name.slice(0, 5)}
            </div>
          </div>
        ))}

        {/* Countdown */}
        {countdown > 0 && !started && racers.length > 0 && (
          <div className="absolute inset-0 bg-black/70 flex items-center justify-center">
            <div className="text-8xl font-black text-white animate-ping">{countdown}</div>
          </div>
        )}

        {/* Start screen */}
        {racers.length === 0 && (
          <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center">
            <div className="text-6xl mb-4">🏎️</div>
            <h2 className="text-2xl font-bold text-white mb-2">Speed Racers</h2>
            <p className="text-gray-400 text-center mb-4 max-w-xs">
              Race 3 laps around the track! First to finish wins!
            </p>
            <p className="text-cyan-400 text-sm mb-4">W = Accelerate • A/D = Steer</p>
            <button
              onClick={startGame}
              className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold px-8 py-3 rounded-xl hover:from-cyan-600 hover:to-blue-700 transition-all shadow-lg"
            >
              Start Race! 🏁
            </button>
          </div>
        )}

        {/* Game over */}
        {gameOver && (
          <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center">
            {winner?.id === user?.id ? (
              <>
                <div className="text-6xl mb-4">🏆</div>
                <h2 className="text-2xl font-bold text-yellow-400 mb-2">You Won!</h2>
                <p className="text-white">Time: {((winner?.finishTime || 0) / 1000).toFixed(2)}s</p>
              </>
            ) : (
              <>
                <div className="text-6xl mb-4">🏁</div>
                <h2 className="text-2xl font-bold text-white mb-2">Race Complete!</h2>
                {winner && <p className="text-gray-400">{winner.name} won!</p>}
                <p className="text-white">Your position: {sortedRacers.findIndex(r => r.id === user?.id) + 1}</p>
              </>
            )}
            {isLoggedIn && <p className="text-green-400 text-sm mt-2">Rewards claimed!</p>}
            <div className="flex gap-3 mt-4">
              <button onClick={startGame} className="bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold px-6 py-3 rounded-xl hover:from-green-600 hover:to-emerald-700 transition-all shadow-lg">
                Race Again
              </button>
              <button onClick={onExit} className="bg-gray-700 text-white font-bold px-6 py-3 rounded-xl hover:bg-gray-600 transition-all">
                Exit
              </button>
            </div>
          </div>
        )}
      </div>

      <p className="text-gray-400 text-sm">W = Accelerate • A/D or ←/→ = Steer • Complete 3 laps!</p>
    </div>
  );
}
