import { useState } from 'react';
import { useAuthStore } from '../store/authStore';
import AvatarDisplay from '../components/AvatarDisplay';
import {
  AVATAR_ITEMS,
  RARITY_COLORS,
  SLOT_INFO,
  ALL_SLOTS,
  AvatarSlot,
  getItemById,
  getItemsBySlot,
  AvatarItem,
  EquippedAvatar,
} from '../data/avatarShop';
import { Coins, ShoppingBag, Check, Lock, Sparkles, ChevronRight } from 'lucide-react';

interface AvatarShopPageProps {
  onOpenAuth: () => void;
}

export default function AvatarShopPage({ onOpenAuth }: AvatarShopPageProps) {
  const { user, isLoggedIn, buyItem, equipItem } = useAuthStore();
  const [activeSlot, setActiveSlot] = useState<AvatarSlot>('hat');
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const [previewItem, setPreviewItem] = useState<string | null>(null);
  const [filterRarity, setFilterRarity] = useState<string>('all');

  if (!isLoggedIn || !user) {
    return (
      <div className="text-center py-20">
        <div className="text-7xl mb-6">🛍️</div>
        <h2 className="text-3xl font-bold text-white mb-3">Avatar Shop</h2>
        <p className="text-gray-400 mb-8 max-w-md mx-auto">
          Sign in to customize your avatar with hats, shirts, pets, auras, and more!
        </p>
        <button
          onClick={onOpenAuth}
          className="bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold px-8 py-3 rounded-xl hover:from-green-600 hover:to-emerald-700 transition-all shadow-lg shadow-green-500/25"
        >
          Sign In to Shop
        </button>
      </div>
    );
  }

  const showNotif = (message: string, type: 'success' | 'error') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 3000);
  };

  const handleBuy = (item: AvatarItem) => {
    const result = buyItem(item.id);
    showNotif(result.message, result.success ? 'success' : 'error');
  };

  const handleEquip = (item: AvatarItem) => {
    equipItem(item.slot, item.id);
    showNotif(`Equipped ${item.name}!`, 'success');
  };

  const items = getItemsBySlot(activeSlot)
    .filter(i => filterRarity === 'all' || i.rarity === filterRarity);

  // Build preview equipped state
  const previewEquipped: EquippedAvatar = { ...user.equippedAvatar };
  if (previewItem) {
    const item = getItemById(previewItem);
    if (item) {
      previewEquipped[item.slot] = item.id;
    }
  }

  const totalOwned = user.ownedItems.length;
  const totalItems = AVATAR_ITEMS.length;

  return (
    <div className="space-y-6">
      {/* Notification Toast */}
      {notification && (
        <div className="fixed top-20 left-1/2 z-50 toast-enter">
          <div
            className={`px-6 py-3 rounded-xl font-medium text-sm shadow-2xl border ${
              notification.type === 'success'
                ? 'bg-green-500/20 border-green-500/40 text-green-300'
                : 'bg-red-500/20 border-red-500/40 text-red-300'
            }`}
          >
            {notification.type === 'success' ? '✅' : '❌'} {notification.message}
          </div>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-600 rounded-2xl flex items-center justify-center shadow-lg shadow-purple-500/20">
            <ShoppingBag size={24} className="text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-white">Avatar Shop</h1>
            <p className="text-gray-400 text-sm">
              Customize your look • {totalOwned}/{totalItems} items owned
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 bg-gradient-to-r from-yellow-500/10 to-orange-500/10 border border-yellow-500/20 rounded-xl px-5 py-3">
          <Coins size={20} className="text-yellow-400" />
          <span className="text-yellow-400 font-bold text-lg">{user.bloxCoins.toLocaleString()}</span>
          <span className="text-yellow-400/50 text-sm">BloxCoins</span>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-6">
        {/* Left Panel - Avatar Preview */}
        <div className="lg:w-72 flex-shrink-0">
          <div className="bg-gray-800 rounded-2xl border border-gray-700 overflow-hidden sticky top-24">
            {/* Avatar Preview Box */}
            <div className="p-6 flex flex-col items-center bg-gradient-to-b from-gray-700/50 to-gray-800">
              <h3 className="text-white font-bold mb-4 text-sm uppercase tracking-wider">Your Avatar</h3>
              <div className="relative mb-4">
                <AvatarDisplay
                  size="xl"
                  equipped={previewEquipped}
                  showPet={true}
                  showAura={true}
                  animated={true}
                />
              </div>
              {previewItem && (
                <p className="text-purple-400 text-xs mb-2 flex items-center gap-1">
                  <Sparkles size={12} /> Previewing...
                </p>
              )}
              <p className="text-gray-400 text-xs text-center">
                {user.displayName}
              </p>
            </div>

            {/* Equipped Items Summary */}
            <div className="p-4 border-t border-gray-700">
              <h4 className="text-gray-400 text-xs font-semibold uppercase tracking-wider mb-3">Equipped</h4>
              <div className="space-y-2">
                {ALL_SLOTS.map(slot => {
                  const item = getItemById(previewEquipped[slot]);
                  const isNone = !item || item.name === 'None' || item.name.includes('Default') || item.name.includes('Classic') || item.name.includes('Basic');
                  return (
                    <button
                      key={slot}
                      onClick={() => setActiveSlot(slot)}
                      className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-left text-xs transition-all ${
                        activeSlot === slot
                          ? 'bg-green-500/15 border border-green-500/30'
                          : 'hover:bg-gray-700 border border-transparent'
                      }`}
                    >
                      <span className="text-base">{SLOT_INFO[slot].emoji}</span>
                      <div className="flex-1 min-w-0">
                        <p className="text-gray-500 leading-none">{SLOT_INFO[slot].label}</p>
                        <p className={`font-medium truncate leading-tight mt-0.5 ${isNone ? 'text-gray-600' : 'text-white'}`}>
                          {item?.name || 'None'}
                        </p>
                      </div>
                      <ChevronRight size={12} className="text-gray-600" />
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Right Panel - Items Grid */}
        <div className="flex-1 min-w-0">
          {/* Slot Tabs */}
          <div className="flex gap-2 overflow-x-auto pb-2 mb-4 scrollbar-none">
            {ALL_SLOTS.map(slot => (
              <button
                key={slot}
                onClick={() => { setActiveSlot(slot); setPreviewItem(null); }}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium whitespace-nowrap transition-all ${
                  activeSlot === slot
                    ? 'bg-green-500 text-white shadow-lg shadow-green-500/25'
                    : 'bg-gray-800 text-gray-400 hover:text-white hover:bg-gray-700 border border-gray-700'
                }`}
              >
                <span>{SLOT_INFO[slot].emoji}</span>
                {SLOT_INFO[slot].label}
              </button>
            ))}
          </div>

          {/* Rarity Filter */}
          <div className="flex gap-2 mb-5 flex-wrap">
            {['all', 'common', 'uncommon', 'rare', 'epic', 'legendary'].map(r => (
              <button
                key={r}
                onClick={() => setFilterRarity(r)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium capitalize transition-all ${
                  filterRarity === r
                    ? r === 'all'
                      ? 'bg-white/10 text-white border border-white/20'
                      : `${RARITY_COLORS[r]?.bg} ${RARITY_COLORS[r]?.text} border ${RARITY_COLORS[r]?.border}`
                    : 'bg-gray-800/50 text-gray-500 hover:text-gray-300 border border-gray-700/50'
                }`}
              >
                {r === 'all' ? '✦ All' : r}
              </button>
            ))}
          </div>

          {/* Items Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
            {items.map(item => {
              const owned = user.ownedItems.includes(item.id);
              const equipped = user.equippedAvatar[item.slot] === item.id;
              const canAfford = user.bloxCoins >= item.price;
              const rarity = RARITY_COLORS[item.rarity];
              const isPreviewing = previewItem === item.id;

              return (
                <div
                  key={item.id}
                  onMouseEnter={() => setPreviewItem(item.id)}
                  onMouseLeave={() => setPreviewItem(null)}
                  className={`relative bg-gray-800 rounded-2xl border-2 transition-all hover:-translate-y-1 hover:shadow-xl ${
                    equipped
                      ? 'border-green-500 shadow-lg shadow-green-500/10'
                      : isPreviewing
                      ? `${rarity.border} ${rarity.glow} shadow-lg`
                      : 'border-gray-700 hover:border-gray-600'
                  }`}
                >
                  {/* Rarity bar */}
                  <div
                    className={`h-1 rounded-t-2xl ${
                      item.rarity === 'common' ? 'bg-gray-500' :
                      item.rarity === 'uncommon' ? 'bg-green-500' :
                      item.rarity === 'rare' ? 'bg-blue-500' :
                      item.rarity === 'epic' ? 'bg-purple-500' :
                      'bg-gradient-to-r from-yellow-400 via-amber-500 to-yellow-600'
                    }`}
                  />

                  <div className="p-4">
                    {/* Item Header */}
                    <div className="flex items-start gap-3 mb-3">
                      {/* Icon */}
                      <div
                        className={`w-14 h-14 rounded-xl flex items-center justify-center text-3xl border ${rarity.border} ${rarity.bg} flex-shrink-0`}
                        style={item.preview && !item.preview.startsWith('linear') && !item.preview.startsWith('#') ? {} : {}}
                      >
                        {item.emoji}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="text-white font-bold text-sm truncate">{item.name}</h3>
                        <span className={`text-xs font-semibold capitalize ${rarity.text}`}>
                          {item.rarity}
                        </span>
                        <p className="text-gray-500 text-xs mt-0.5 line-clamp-2">{item.description}</p>
                      </div>
                    </div>

                    {/* Preview Swatch */}
                    {item.preview && item.id !== 'hat-none' && item.id !== 'acc-none' && item.id !== 'pet-none' && item.id !== 'aura-none' && item.id !== 'face-default' && (
                      <div
                        className="w-full h-3 rounded-full mb-3 border border-white/10"
                        style={{
                          background: item.preview.startsWith('linear') ? item.preview : undefined,
                          backgroundColor: item.preview.startsWith('linear') ? undefined : item.preview,
                        }}
                      />
                    )}

                    {/* Actions */}
                    <div className="flex items-center gap-2">
                      {equipped ? (
                        <div className="flex-1 flex items-center justify-center gap-2 bg-green-500/15 text-green-400 font-semibold text-sm py-2.5 rounded-xl border border-green-500/30">
                          <Check size={16} /> Equipped
                        </div>
                      ) : owned ? (
                        <button
                          onClick={() => handleEquip(item)}
                          className="flex-1 bg-gradient-to-r from-blue-500 to-indigo-600 text-white font-semibold text-sm py-2.5 rounded-xl hover:from-blue-600 hover:to-indigo-700 transition-all shadow-lg shadow-blue-500/20"
                        >
                          Equip
                        </button>
                      ) : item.price === 0 ? (
                        <button
                          onClick={() => handleEquip(item)}
                          className="flex-1 bg-gray-700 text-white font-semibold text-sm py-2.5 rounded-xl hover:bg-gray-600 transition-all"
                        >
                          Free — Equip
                        </button>
                      ) : (
                        <button
                          onClick={() => handleBuy(item)}
                          disabled={!canAfford}
                          className={`flex-1 flex items-center justify-center gap-2 font-semibold text-sm py-2.5 rounded-xl transition-all ${
                            canAfford
                              ? 'bg-gradient-to-r from-yellow-500 to-orange-500 text-white hover:from-yellow-600 hover:to-orange-600 shadow-lg shadow-yellow-500/20'
                              : 'bg-gray-700/50 text-gray-500 cursor-not-allowed'
                          }`}
                        >
                          {canAfford ? (
                            <>
                              <Coins size={14} />
                              {item.price.toLocaleString()}
                            </>
                          ) : (
                            <>
                              <Lock size={14} />
                              {item.price.toLocaleString()}
                            </>
                          )}
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {items.length === 0 && (
            <div className="text-center py-16">
              <div className="text-5xl mb-4">🔍</div>
              <h3 className="text-lg font-bold text-white mb-1">No items found</h3>
              <p className="text-gray-500 text-sm">Try a different rarity filter</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
