import { useAuthStore } from '../store/authStore';
import { useSocialStore } from '../store/socialStore';
import GameCard from '../components/GameCard';
import AvatarDisplay from '../components/AvatarDisplay';
import { GAMES } from '../data/games';
import { Sparkles, TrendingUp, Flame, Clock, ShoppingBag, Users } from 'lucide-react';

interface HomePageProps {
  onPlayGame: (gameId: string, multiplayer?: boolean) => void;
  onOpenAuth: () => void;
  onNavigate?: (page: string) => void;
}

export default function HomePage({ onPlayGame, onOpenAuth, onNavigate }: HomePageProps) {
  const { isLoggedIn, user } = useAuthStore();
  const { friends, onlinePlayers } = useSocialStore();

  const featuredGame = GAMES[0];
  const multiplayerGames = GAMES.filter(g => ['horror', 'battle', 'racing', 'zombie'].includes(g.id));
  const trendingGames = GAMES.slice(0, 4);
  const newGames = [...GAMES].reverse().slice(0, 4);
  const onlineFriendsCount = friends.filter(f => f.status !== 'offline').length;

  return (
    <div className="space-y-10">
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-green-600 via-emerald-600 to-teal-700 p-8 md:p-12">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-40 h-40 bg-white rounded-full blur-3xl" />
          <div className="absolute bottom-10 right-10 w-60 h-60 bg-yellow-300 rounded-full blur-3xl" />
          <div className="absolute top-1/2 left-1/2 w-32 h-32 bg-blue-300 rounded-full blur-3xl" />
        </div>
        {/* Domain watermark */}
        <div className="absolute top-4 right-6 text-white/20 text-xs font-mono tracking-widest">
          bloxverse.arena
        </div>
        <div className="relative flex flex-col md:flex-row items-center gap-8">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-4">
              <Sparkles size={20} className="text-yellow-300" />
              <span className="text-yellow-300 font-semibold text-sm uppercase tracking-wider">
                {isLoggedIn ? `Welcome back, ${user?.displayName}!` : 'Play, Create, Imagine'}
              </span>
            </div>
            <h1 className="text-4xl md:text-5xl font-black text-white mb-4 leading-tight">
              Play Together,<br />Win Together
            </h1>
            <p className="text-green-100 text-lg mb-6 max-w-md">
              Join multiplayer games, customize your avatar, make friends, and compete with players worldwide.
            </p>
            <div className="flex flex-wrap gap-3">
              <button
                onClick={() => onPlayGame(featuredGame.id)}
                className="bg-white text-green-700 font-bold px-8 py-3 rounded-xl hover:bg-green-50 transition-all shadow-lg hover:shadow-xl transform hover:scale-105"
              >
                ▶ Play {featuredGame.title}
              </button>
              {!isLoggedIn && (
                <button
                  onClick={onOpenAuth}
                  className="bg-white/20 text-white font-bold px-8 py-3 rounded-xl hover:bg-white/30 transition-all backdrop-blur-sm border border-white/30"
                >
                  Join Free
                </button>
              )}
            </div>
          </div>
          <div className="relative w-64 h-48 md:w-80 md:h-56 rounded-2xl overflow-hidden shadow-2xl border-2 border-white/20">
            <img src={featuredGame.thumbnail} alt={featuredGame.title} className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
            <div className="absolute bottom-4 left-4">
              <p className="text-white font-bold text-lg">{featuredGame.title}</p>
              <p className="text-green-300 text-sm">{featuredGame.players} playing now</p>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Stats for logged-in users */}
      {isLoggedIn && user && (
        <section className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {/* Avatar Card */}
          <div
            className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-2xl p-4 flex flex-col items-center cursor-pointer hover:border-purple-500/40 transition-all"
            onClick={() => onNavigate?.('avatar')}
          >
            <AvatarDisplay size="md" showPet={true} showAura={true} animated={true} />
            <p className="text-gray-400 text-xs mt-1">Your Avatar</p>
          </div>
          {[
            { label: 'BloxCoins', value: user.bloxCoins.toLocaleString(), icon: '💰', color: 'from-yellow-500/10 to-orange-500/10 border-yellow-500/20' },
            { label: 'Level', value: user.level.toString(), icon: '⭐', color: 'from-purple-500/10 to-pink-500/10 border-purple-500/20' },
            { label: 'Friends Online', value: `${onlineFriendsCount}/${friends.length}`, icon: '👥', color: 'from-blue-500/10 to-cyan-500/10 border-blue-500/20', onClick: () => onNavigate?.('friends') },
            { label: 'Players Online', value: onlinePlayers.length.toString(), icon: '🌐', color: 'from-green-500/10 to-emerald-500/10 border-green-500/20' },
          ].map((stat) => (
            <div
              key={stat.label}
              onClick={stat.onClick}
              className={`bg-gradient-to-br ${stat.color} border rounded-2xl p-4 text-center ${stat.onClick ? 'cursor-pointer hover:scale-105 transition-transform' : ''}`}
            >
              <div className="text-2xl mb-1">{stat.icon}</div>
              <p className="text-white font-bold text-xl">{stat.value}</p>
              <p className="text-gray-400 text-sm">{stat.label}</p>
            </div>
          ))}
        </section>
      )}

      {/* Multiplayer Games Banner */}
      {isLoggedIn && multiplayerGames.length > 0 && (
        <section className="bg-gradient-to-r from-purple-900/40 via-blue-900/40 to-purple-900/40 border border-purple-500/20 rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-blue-600 rounded-xl flex items-center justify-center">
              <Users size={20} className="text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">Multiplayer Games</h2>
              <p className="text-gray-400 text-sm">Play with friends and other players!</p>
            </div>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {multiplayerGames.slice(0, 4).map(game => (
              <button
                key={game.id}
                onClick={() => onPlayGame(game.id, true)}
                className="bg-gray-800/50 rounded-xl border border-gray-700 hover:border-purple-500/50 transition-all overflow-hidden group"
              >
                <div className="aspect-video relative">
                  <img src={game.thumbnail} alt={game.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end p-3">
                    <div>
                      <p className="text-white font-bold text-sm">{game.title}</p>
                      <p className="text-purple-300 text-xs flex items-center gap-1">
                        <Users size={10} /> Multiplayer
                      </p>
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </section>
      )}

      {/* Avatar Shop Banner (for logged-in users) */}
      {isLoggedIn && (
        <section>
          <button
            onClick={() => onNavigate?.('avatar')}
            className="w-full bg-gradient-to-r from-pink-900/40 via-purple-900/40 to-pink-900/40 border border-purple-500/20 rounded-2xl p-6 flex items-center gap-5 hover:border-purple-500/40 transition-all group"
          >
            <div className="w-14 h-14 bg-gradient-to-br from-purple-500 to-pink-600 rounded-2xl flex items-center justify-center shadow-lg shadow-purple-500/20 group-hover:scale-110 transition-transform flex-shrink-0">
              <ShoppingBag size={26} className="text-white" />
            </div>
            <div className="flex-1 text-left">
              <h3 className="text-white font-bold text-lg">Avatar Shop — Customize Your Look!</h3>
              <p className="text-gray-400 text-sm">
                Spend your BloxCoins on hats, pets, auras, and 60+ customization items.
              </p>
            </div>
            <span className="text-purple-400 font-medium hidden sm:block group-hover:translate-x-1 transition-transform">
              Browse Shop →
            </span>
          </button>
        </section>
      )}

      {/* Trending Games */}
      <section>
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-red-500/10 rounded-xl flex items-center justify-center">
            <Flame size={20} className="text-red-400" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white">Trending Now</h2>
            <p className="text-gray-400 text-sm">Most popular games right now</p>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {trendingGames.map(game => (
            <GameCard key={game.id} game={game} onPlay={(id) => onPlayGame(id)} />
          ))}
        </div>
      </section>

      {/* New Games */}
      <section>
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-blue-500/10 rounded-xl flex items-center justify-center">
            <Clock size={20} className="text-blue-400" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white">New Arrivals</h2>
            <p className="text-gray-400 text-sm">Fresh games just added</p>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {newGames.map(game => (
            <GameCard key={game.id} game={game} onPlay={(id) => onPlayGame(id)} />
          ))}
        </div>
      </section>

      {/* Popular Categories */}
      <section>
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-green-500/10 rounded-xl flex items-center justify-center">
            <TrendingUp size={20} className="text-green-400" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white">Browse by Category</h2>
            <p className="text-gray-400 text-sm">Find your favorite type of game</p>
          </div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
          {[
            { name: 'Horror', emoji: '👻', color: 'from-gray-700 to-gray-900', count: '420' },
            { name: 'Battle', emoji: '⚔️', color: 'from-red-600 to-orange-600', count: '890' },
            { name: 'Racing', emoji: '🏎️', color: 'from-blue-500 to-cyan-600', count: '650' },
            { name: 'Survival', emoji: '🧟', color: 'from-green-600 to-emerald-700', count: '780' },
            { name: 'Arcade', emoji: '🕹️', color: 'from-purple-500 to-pink-600', count: '2.1K' },
            { name: 'Puzzle', emoji: '🧩', color: 'from-yellow-500 to-orange-600', count: '340' },
          ].map((cat) => (
            <div
              key={cat.name}
              className={`bg-gradient-to-br ${cat.color} rounded-2xl p-5 text-center cursor-pointer hover:scale-105 transition-transform shadow-lg`}
            >
              <div className="text-3xl mb-2">{cat.emoji}</div>
              <p className="text-white font-bold">{cat.name}</p>
              <p className="text-white/60 text-sm">{cat.count} games</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA for non-logged-in users */}
      {!isLoggedIn && (
        <section className="bg-gradient-to-r from-gray-800 to-gray-900 rounded-3xl p-8 md:p-12 text-center border border-gray-700">
          <h2 className="text-3xl font-bold text-white mb-3">Ready to join the fun?</h2>
          <p className="text-gray-400 mb-6 max-w-md mx-auto">
            Create a free account to play multiplayer games, make friends, customize your avatar, and compete on leaderboards!
          </p>
          <button
            onClick={onOpenAuth}
            className="bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold px-10 py-4 rounded-xl hover:from-green-600 hover:to-emerald-700 transition-all shadow-lg shadow-green-500/25 text-lg"
          >
            Sign Up Free 🎮
          </button>
        </section>
      )}
    </div>
  );
}
