import { useState } from 'react';
import { Trophy, Medal, Crown, Coins, Gamepad2, TrendingUp } from 'lucide-react';

interface LeaderboardEntry {
  rank: number;
  username: string;
  displayName: string;
  avatar: string;
  score: number;
  level: number;
}

const MOCK_LEADERBOARD: LeaderboardEntry[] = [
  { rank: 1, username: 'xBloxKing', displayName: 'BloxKing', avatar: '👑', score: 52340, level: 42 },
  { rank: 2, username: 'ProGamer99', displayName: 'ProGamer', avatar: '🦸‍♂️', score: 48200, level: 38 },
  { rank: 3, username: 'NinjaBlox', displayName: 'NinjaBlox', avatar: '🥷', score: 41800, level: 35 },
  { rank: 4, username: 'StarPlayer', displayName: 'StarPlayer', avatar: '⭐', score: 38500, level: 32 },
  { rank: 5, username: 'GameWizard', displayName: 'GameWizard', avatar: '🧙‍♂️', score: 35200, level: 30 },
  { rank: 6, username: 'PixelMaster', displayName: 'PixelMaster', avatar: '👾', score: 31900, level: 28 },
  { rank: 7, username: 'DragonSlayer', displayName: 'DragonSlayer', avatar: '🐉', score: 28400, level: 25 },
  { rank: 8, username: 'CyberBlox', displayName: 'CyberBlox', avatar: '🤖', score: 25100, level: 22 },
  { rank: 9, username: 'MagicFox', displayName: 'MagicFox', avatar: '🦊', score: 21800, level: 20 },
  { rank: 10, username: 'SpeedRacer', displayName: 'SpeedRacer', avatar: '🏎️', score: 19500, level: 18 },
];

export default function LeaderboardPage() {
  const [tab, setTab] = useState<'coins' | 'level' | 'games'>('coins');

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return <Crown size={20} className="text-yellow-400" />;
      case 2: return <Medal size={20} className="text-gray-300" />;
      case 3: return <Medal size={20} className="text-amber-600" />;
      default: return <span className="text-gray-400 font-bold text-sm">#{rank}</span>;
    }
  };

  const getRankBg = (rank: number) => {
    switch (rank) {
      case 1: return 'bg-yellow-500/10 border-yellow-500/30';
      case 2: return 'bg-gray-400/10 border-gray-400/30';
      case 3: return 'bg-amber-600/10 border-amber-600/30';
      default: return 'bg-gray-800 border-gray-700';
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <Trophy size={28} className="text-yellow-400" />
        <div>
          <h1 className="text-3xl font-bold text-white">Leaderboard</h1>
          <p className="text-gray-400">Top players in Bloxverse</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 bg-gray-800 rounded-xl p-1.5 border border-gray-700">
        {[
          { id: 'coins' as const, label: 'Top Coins', icon: Coins },
          { id: 'level' as const, label: 'Highest Level', icon: TrendingUp },
          { id: 'games' as const, label: 'Most Games', icon: Gamepad2 },
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-medium transition-all ${
              tab === t.id
                ? 'bg-green-500 text-white shadow-lg shadow-green-500/25'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <t.icon size={16} />
            {t.label}
          </button>
        ))}
      </div>

      {/* Top 3 Podium */}
      <div className="flex items-end justify-center gap-4 py-6">
        {[MOCK_LEADERBOARD[1], MOCK_LEADERBOARD[0], MOCK_LEADERBOARD[2]].map((entry, i) => (
          <div key={entry.rank} className={`text-center ${i === 1 ? 'order-2' : i === 0 ? 'order-1' : 'order-3'}`}>
            <div className="relative">
              <div
                className={`w-16 h-16 mx-auto rounded-2xl flex items-center justify-center text-3xl border-2 ${
                  entry.rank === 1
                    ? 'bg-yellow-500/20 border-yellow-500'
                    : entry.rank === 2
                    ? 'bg-gray-400/20 border-gray-400'
                    : 'bg-amber-600/20 border-amber-600'
                }`}
              >
                {entry.avatar}
              </div>
              <div className="absolute -top-2 -right-2">
                {getRankIcon(entry.rank)}
              </div>
            </div>
            <p className="text-white font-bold mt-2 text-sm">{entry.displayName}</p>
            <p className="text-yellow-400 text-sm font-medium">{entry.score.toLocaleString()}</p>
            <div
              className={`mt-2 rounded-t-lg mx-auto ${
                entry.rank === 1
                  ? 'bg-yellow-500/20 w-20 h-24'
                  : entry.rank === 2
                  ? 'bg-gray-400/20 w-20 h-16'
                  : 'bg-amber-600/20 w-20 h-12'
              }`}
            />
          </div>
        ))}
      </div>

      {/* Full List */}
      <div className="space-y-2">
        {MOCK_LEADERBOARD.map((entry) => (
          <div
            key={entry.rank}
            className={`flex items-center gap-4 p-4 rounded-xl border transition-all hover:scale-[1.01] ${getRankBg(entry.rank)}`}
          >
            <div className="w-8 flex justify-center">
              {getRankIcon(entry.rank)}
            </div>
            <div className="w-10 h-10 bg-gray-700 rounded-xl flex items-center justify-center text-xl">
              {entry.avatar}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-white font-bold truncate">{entry.displayName}</p>
              <p className="text-gray-500 text-sm">@{entry.username} • Level {entry.level}</p>
            </div>
            <div className="text-right">
              <p className="text-yellow-400 font-bold">{entry.score.toLocaleString()}</p>
              <p className="text-gray-500 text-xs">coins</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
