import { useState } from 'react';
import GameCard from '../components/GameCard';
import { GAMES, CATEGORIES } from '../data/games';
import { Search, SlidersHorizontal, Users } from 'lucide-react';

interface DiscoverPageProps {
  onPlayGame: (gameId: string, multiplayer?: boolean) => void;
}

export default function DiscoverPage({ onPlayGame }: DiscoverPageProps) {
  const [activeCategory, setActiveCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'popular' | 'rating' | 'name'>('popular');
  const [multiplayerOnly, setMultiplayerOnly] = useState(false);

  let filtered = activeCategory === 'All'
    ? [...GAMES]
    : GAMES.filter(g => g.category === activeCategory);

  if (multiplayerOnly) {
    filtered = filtered.filter(g => g.multiplayer);
  }

  if (searchQuery) {
    const q = searchQuery.toLowerCase();
    filtered = filtered.filter(g =>
      g.title.toLowerCase().includes(q) ||
      g.description.toLowerCase().includes(q) ||
      g.tags.some(t => t.toLowerCase().includes(q))
    );
  }

  if (sortBy === 'rating') {
    filtered.sort((a, b) => b.rating - a.rating);
  } else if (sortBy === 'name') {
    filtered.sort((a, b) => a.title.localeCompare(b.title));
  }

  const multiplayerGames = GAMES.filter(g => g.multiplayer);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">Discover Games</h1>
        <p className="text-gray-400">Browse and find your next favorite game</p>
      </div>

      {/* Multiplayer Banner */}
      <div className="bg-gradient-to-r from-purple-900/40 via-blue-900/40 to-purple-900/40 border border-purple-500/20 rounded-2xl p-5">
        <div className="flex items-center gap-3 mb-3">
          <Users size={20} className="text-purple-400" />
          <h2 className="text-white font-bold">Multiplayer Games</h2>
          <span className="text-purple-400 text-sm">({multiplayerGames.length} games)</span>
        </div>
        <div className="flex gap-3 overflow-x-auto pb-2">
          {multiplayerGames.map(game => (
            <button
              key={game.id}
              onClick={() => onPlayGame(game.id, true)}
              className="flex-shrink-0 bg-gray-800/50 rounded-xl border border-gray-700 hover:border-purple-500/50 transition-all overflow-hidden group w-40"
            >
              <div className="aspect-video relative">
                <img src={game.thumbnail} alt={game.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                <div className="absolute bottom-2 left-2 right-2">
                  <p className="text-white font-bold text-xs truncate">{game.title}</p>
                  <p className="text-purple-300 text-[10px]">Up to {game.maxPlayers} players</p>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Search & Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
          <input
            type="text"
            placeholder="Search games, tags..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-gray-800 border border-gray-700 rounded-xl pl-10 pr-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-green-500 focus:ring-1 focus:ring-green-500"
          />
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setMultiplayerOnly(!multiplayerOnly)}
            className={`flex items-center gap-2 px-4 py-3 rounded-xl text-sm font-medium transition-all border ${
              multiplayerOnly
                ? 'bg-purple-500/20 border-purple-500/50 text-purple-400'
                : 'bg-gray-800 border-gray-700 text-gray-400 hover:text-white'
            }`}
          >
            <Users size={16} />
            Multiplayer
          </button>
          <SlidersHorizontal size={16} className="text-gray-400" />
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
            className="bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-green-500"
          >
            <option value="popular">Most Popular</option>
            <option value="rating">Highest Rated</option>
            <option value="name">Alphabetical</option>
          </select>
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex flex-wrap gap-2">
        {CATEGORIES.map(cat => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-5 py-2 rounded-full text-sm font-medium transition-all ${
              activeCategory === cat
                ? 'bg-green-500 text-white shadow-lg shadow-green-500/25'
                : 'bg-gray-800 text-gray-400 hover:text-white hover:bg-gray-700 border border-gray-700'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Results */}
      {filtered.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map(game => (
            <GameCard key={game.id} game={game} onPlay={(id) => onPlayGame(id, game.multiplayer)} />
          ))}
        </div>
      ) : (
        <div className="text-center py-20">
          <div className="text-6xl mb-4">🔍</div>
          <h3 className="text-xl font-bold text-white mb-2">No games found</h3>
          <p className="text-gray-400">Try a different search or category</p>
        </div>
      )}
    </div>
  );
}
