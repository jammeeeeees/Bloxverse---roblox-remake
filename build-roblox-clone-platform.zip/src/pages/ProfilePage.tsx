import { useAuthStore } from '../store/authStore';
import AvatarDisplay from '../components/AvatarDisplay';
import { Calendar, GamepadIcon, Coins, Award, TrendingUp, Users, ShoppingBag } from 'lucide-react';
import { AVATAR_ITEMS } from '../data/avatarShop';

interface ProfilePageProps {
  onNavigate: (page: string) => void;
}

export default function ProfilePage({ onNavigate }: ProfilePageProps) {
  const { user, isLoggedIn } = useAuthStore();

  if (!isLoggedIn || !user) {
    return (
      <div className="text-center py-20">
        <div className="text-6xl mb-4">👤</div>
        <h2 className="text-2xl font-bold text-white">You are not logged in</h2>
      </div>
    );
  }

  const xpPercent = (user.xp / (user.level * 100)) * 100;
  const totalOwned = user.ownedItems.length;
  const totalItems = AVATAR_ITEMS.length;

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Profile Header */}
      <div className="bg-gray-800 rounded-3xl overflow-hidden border border-gray-700">
        <div className="h-36 bg-gradient-to-r from-green-500 via-emerald-500 to-teal-600 relative">
          <div className="absolute inset-0 opacity-20">
            <div className="absolute top-0 left-1/4 w-32 h-32 bg-white rounded-full blur-3xl" />
            <div className="absolute bottom-0 right-1/4 w-24 h-24 bg-yellow-300 rounded-full blur-3xl" />
          </div>
          {/* Domain watermark */}
          <div className="absolute top-4 right-4 text-white/20 text-xs font-mono tracking-widest">
            bloxverse.arena
          </div>
        </div>
        <div className="px-8 pb-8 relative">
          <div className="flex flex-col sm:flex-row items-center sm:items-end gap-4 -mt-16">
            {/* Avatar Display */}
            <div className="bg-gray-900 rounded-2xl border-4 border-gray-800 p-3 shadow-xl">
              <AvatarDisplay size="lg" showPet={true} showAura={true} animated={true} />
            </div>
            <div className="flex-1 text-center sm:text-left pb-2">
              <h1 className="text-2xl font-bold text-white">{user.displayName}</h1>
              <p className="text-gray-400">@{user.username}</p>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 bg-gradient-to-r from-yellow-500/10 to-orange-500/10 border border-yellow-500/20 rounded-xl px-4 py-2">
                <Coins size={18} className="text-yellow-400" />
                <span className="text-yellow-400 font-bold">{user.bloxCoins.toLocaleString()}</span>
                <span className="text-yellow-400/60 text-sm">coins</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Avatar Customization Banner */}
      <button
        onClick={() => onNavigate('avatar')}
        className="w-full bg-gradient-to-r from-purple-600/20 via-pink-600/20 to-purple-600/20 border border-purple-500/30 rounded-2xl p-5 flex items-center gap-4 hover:border-purple-500/50 transition-all group"
      >
        <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl flex items-center justify-center shadow-lg shadow-purple-500/20 group-hover:scale-110 transition-transform">
          <ShoppingBag size={22} className="text-white" />
        </div>
        <div className="flex-1 text-left">
          <h3 className="text-white font-bold">Customize Your Avatar</h3>
          <p className="text-gray-400 text-sm">
            {totalOwned}/{totalItems} items owned — Spend BloxCoins on hats, pets, auras & more!
          </p>
        </div>
        <span className="text-purple-400 text-sm font-medium group-hover:translate-x-1 transition-transform">
          Open Shop →
        </span>
      </button>

      {/* Level / XP */}
      <div className="bg-gray-800 rounded-2xl p-6 border border-gray-700">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <Award size={20} className="text-purple-400" />
            <span className="text-white font-bold">Level {user.level}</span>
          </div>
          <span className="text-gray-400 text-sm">{user.xp} / {user.level * 100} XP</span>
        </div>
        <div className="w-full bg-gray-700 rounded-full h-4 overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full transition-all duration-500"
            style={{ width: `${xpPercent}%` }}
          />
        </div>
        <p className="text-gray-500 text-sm mt-2">{user.level * 100 - user.xp} XP to level {user.level + 1}</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Games Played', value: user.gamesPlayed, icon: GamepadIcon, color: 'text-green-400' },
          { label: 'Favorites', value: user.favoriteGames.length, icon: TrendingUp, color: 'text-red-400' },
          { label: 'Friends', value: user.friends, icon: Users, color: 'text-blue-400' },
          { label: 'Member Since', value: user.joinDate.split(',')[0], icon: Calendar, color: 'text-yellow-400' },
        ].map((stat) => (
          <div key={stat.label} className="bg-gray-800 rounded-2xl p-4 border border-gray-700 text-center">
            <stat.icon size={24} className={`${stat.color} mx-auto mb-2`} />
            <p className="text-white font-bold text-lg">{stat.value}</p>
            <p className="text-gray-500 text-xs">{stat.label}</p>
          </div>
        ))}
      </div>

      {/* Achievements */}
      <div className="bg-gray-800 rounded-2xl p-6 border border-gray-700">
        <h3 className="text-white font-bold text-lg mb-4">🏆 Achievements</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {[
            { name: 'First Steps', desc: 'Play your first game', emoji: '👣', unlocked: user.gamesPlayed > 0 },
            { name: 'Coin Collector', desc: 'Earn 500 coins', emoji: '💰', unlocked: user.bloxCoins >= 500 },
            { name: 'Level Up!', desc: 'Reach level 5', emoji: '⭐', unlocked: user.level >= 5 },
            { name: 'Game Master', desc: 'Play 10 games', emoji: '🎮', unlocked: user.gamesPlayed >= 10 },
            { name: 'Wealthy', desc: 'Earn 1000 coins', emoji: '👑', unlocked: user.bloxCoins >= 1000 },
            { name: 'Dedicated', desc: 'Reach level 10', emoji: '🔥', unlocked: user.level >= 10 },
            { name: 'Fashionista', desc: 'Own 10 avatar items', emoji: '👗', unlocked: user.ownedItems.length >= 10 },
            { name: 'Collector', desc: 'Own 20 avatar items', emoji: '🏅', unlocked: user.ownedItems.length >= 20 },
            { name: 'Legendary', desc: 'Own a legendary item', emoji: '🌟', unlocked: user.ownedItems.some(id => {
              const item = AVATAR_ITEMS.find(i => i.id === id);
              return item?.rarity === 'legendary';
            })},
          ].map((ach) => (
            <div
              key={ach.name}
              className={`p-3 rounded-xl border text-center transition-all ${
                ach.unlocked
                  ? 'bg-green-500/10 border-green-500/30'
                  : 'bg-gray-700/30 border-gray-700 opacity-50'
              }`}
            >
              <div className="text-2xl mb-1">{ach.emoji}</div>
              <p className={`font-medium text-sm ${ach.unlocked ? 'text-white' : 'text-gray-500'}`}>{ach.name}</p>
              <p className="text-gray-500 text-xs">{ach.desc}</p>
              {ach.unlocked && <span className="text-green-400 text-xs font-bold">✓ Unlocked</span>}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
