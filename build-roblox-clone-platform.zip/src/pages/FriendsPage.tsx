import { useState, useEffect, useRef } from 'react';
import { useAuthStore } from '../store/authStore';
import { useSocialStore, Player } from '../store/socialStore';
import AvatarDisplay from '../components/AvatarDisplay';
import { Users, UserPlus, Search, MessageCircle, Gamepad2, X, Send, Circle } from 'lucide-react';

interface FriendsPageProps {
  onOpenAuth: () => void;
}

export default function FriendsPage({ onOpenAuth }: FriendsPageProps) {
  const { user, isLoggedIn } = useAuthStore();
  const { friends, onlinePlayers, globalChat, sendFriendRequest, removeFriend, sendGlobalMessage, simulateAIActivity } = useSocialStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [addFriendUsername, setAddFriendUsername] = useState('');
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const [chatMessage, setChatMessage] = useState('');
  const [activeTab, setActiveTab] = useState<'friends' | 'online' | 'chat'>('friends');
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const interval = setInterval(simulateAIActivity, 30000);
    return () => clearInterval(interval);
  }, [simulateAIActivity]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [globalChat]);

  if (!isLoggedIn || !user) {
    return (
      <div className="text-center py-20">
        <div className="text-7xl mb-6">👥</div>
        <h2 className="text-3xl font-bold text-white mb-3">Friends & Social</h2>
        <p className="text-gray-400 mb-8 max-w-md mx-auto">
          Sign in to add friends, chat with other players, and play multiplayer games together!
        </p>
        <button
          onClick={onOpenAuth}
          className="bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold px-8 py-3 rounded-xl hover:from-green-600 hover:to-emerald-700 transition-all shadow-lg shadow-green-500/25"
        >
          Sign In
        </button>
      </div>
    );
  }

  const showNotif = (message: string, type: 'success' | 'error') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 3000);
  };

  const handleAddFriend = () => {
    if (!addFriendUsername.trim()) return;
    const result = sendFriendRequest(addFriendUsername.trim());
    showNotif(result.message, result.success ? 'success' : 'error');
    if (result.success) setAddFriendUsername('');
  };

  const handleSendMessage = () => {
    if (!chatMessage.trim()) return;
    sendGlobalMessage(user.displayName, chatMessage.trim());
    setChatMessage('');
  };

  const filteredFriends = friends.filter(f =>
    f.displayName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    f.username.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getStatusColor = (status: Player['status']) => {
    switch (status) {
      case 'online': return 'bg-green-500';
      case 'in-game': return 'bg-blue-500';
      case 'offline': return 'bg-gray-500';
    }
  };

  const getStatusText = (status: Player['status'], game?: string) => {
    switch (status) {
      case 'online': return 'Online';
      case 'in-game': return `Playing ${game || 'a game'}`;
      case 'offline': return 'Offline';
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Notification */}
      {notification && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50">
          <div className={`px-6 py-3 rounded-xl font-medium text-sm shadow-2xl border ${
            notification.type === 'success'
              ? 'bg-green-500/20 border-green-500/40 text-green-300'
              : 'bg-red-500/20 border-red-500/40 text-red-300'
          }`}>
            {notification.type === 'success' ? '✅' : '❌'} {notification.message}
          </div>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg shadow-blue-500/20">
            <Users size={24} className="text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-white">Friends & Social</h1>
            <p className="text-gray-400 text-sm">
              {friends.length} friends • {onlinePlayers.length} players online
            </p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 bg-gray-800 rounded-xl p-1.5 border border-gray-700">
        {[
          { id: 'friends' as const, label: 'My Friends', icon: Users, count: friends.length },
          { id: 'online' as const, label: 'Online Now', icon: Circle, count: onlinePlayers.length },
          { id: 'chat' as const, label: 'Global Chat', icon: MessageCircle },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-medium transition-all ${
              activeTab === tab.id
                ? 'bg-green-500 text-white shadow-lg shadow-green-500/25'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <tab.icon size={16} />
            {tab.label}
            {tab.count !== undefined && <span className="text-xs opacity-70">({tab.count})</span>}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-4">
          {activeTab === 'friends' && (
            <>
              {/* Add Friend */}
              <div className="bg-gray-800 rounded-2xl p-4 border border-gray-700">
                <h3 className="text-white font-bold mb-3 flex items-center gap-2">
                  <UserPlus size={18} className="text-green-400" />
                  Add Friend
                </h3>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Enter username..."
                    value={addFriendUsername}
                    onChange={(e) => setAddFriendUsername(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleAddFriend()}
                    className="flex-1 bg-gray-900 border border-gray-700 rounded-xl px-4 py-2.5 text-white placeholder-gray-500 focus:outline-none focus:border-green-500"
                  />
                  <button
                    onClick={handleAddFriend}
                    className="bg-gradient-to-r from-green-500 to-emerald-600 text-white font-semibold px-6 py-2.5 rounded-xl hover:from-green-600 hover:to-emerald-700 transition-all"
                  >
                    Add
                  </button>
                </div>
                <p className="text-gray-500 text-xs mt-2">Try: NightHunter, StarGazer, BloxKing, ShadowNinja, CuteKitty</p>
              </div>

              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
                <input
                  type="text"
                  placeholder="Search friends..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-gray-800 border border-gray-700 rounded-xl pl-10 pr-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-green-500"
                />
              </div>

              {/* Friends List */}
              {filteredFriends.length > 0 ? (
                <div className="space-y-2">
                  {filteredFriends.map((friend) => (
                    <div key={friend.id} className="bg-gray-800 rounded-xl border border-gray-700 p-4 flex items-center gap-4 hover:border-gray-600 transition-colors">
                      <div className="relative">
                        <AvatarDisplay size="md" equipped={friend.avatar} showPet={false} showAura={false} />
                        <div className={`absolute -bottom-1 -right-1 w-4 h-4 ${getStatusColor(friend.status)} rounded-full border-2 border-gray-800`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-white font-bold truncate">{friend.displayName}</p>
                        <p className="text-gray-500 text-sm">@{friend.username} • Level {friend.level}</p>
                        <p className={`text-sm ${friend.status === 'online' ? 'text-green-400' : friend.status === 'in-game' ? 'text-blue-400' : 'text-gray-500'}`}>
                          {getStatusText(friend.status, friend.currentGame)}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        {friend.status !== 'offline' && (
                          <button className="p-2 bg-blue-500/10 text-blue-400 rounded-lg hover:bg-blue-500/20 transition-colors">
                            <Gamepad2 size={18} />
                          </button>
                        )}
                        <button
                          onClick={() => removeFriend(friend.id)}
                          className="p-2 bg-red-500/10 text-red-400 rounded-lg hover:bg-red-500/20 transition-colors"
                        >
                          <X size={18} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 bg-gray-800 rounded-2xl border border-gray-700">
                  <div className="text-5xl mb-4">👋</div>
                  <h3 className="text-lg font-bold text-white mb-2">No friends yet</h3>
                  <p className="text-gray-500 text-sm">Add friends to play multiplayer games together!</p>
                </div>
              )}
            </>
          )}

          {activeTab === 'online' && (
            <div className="space-y-2">
              {onlinePlayers.map((player) => (
                <div key={player.id} className="bg-gray-800 rounded-xl border border-gray-700 p-4 flex items-center gap-4 hover:border-gray-600 transition-colors">
                  <div className="relative">
                    <AvatarDisplay size="md" equipped={player.avatar} showPet={false} showAura={false} />
                    <div className={`absolute -bottom-1 -right-1 w-4 h-4 ${getStatusColor(player.status)} rounded-full border-2 border-gray-800`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white font-bold truncate">{player.displayName}</p>
                    <p className="text-gray-500 text-sm">Level {player.level}</p>
                    <p className={`text-sm ${player.status === 'online' ? 'text-green-400' : 'text-blue-400'}`}>
                      {getStatusText(player.status, player.currentGame)}
                    </p>
                  </div>
                  {!friends.some(f => f.id === player.id) && (
                    <button
                      onClick={() => {
                        const result = sendFriendRequest(player.username);
                        showNotif(result.message, result.success ? 'success' : 'error');
                      }}
                      className="px-4 py-2 bg-green-500/10 text-green-400 rounded-lg hover:bg-green-500/20 transition-colors text-sm font-medium"
                    >
                      Add Friend
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}

          {activeTab === 'chat' && (
            <div className="bg-gray-800 rounded-2xl border border-gray-700 overflow-hidden">
              {/* Chat Messages */}
              <div className="h-96 overflow-y-auto p-4 space-y-3">
                {globalChat.map((msg) => (
                  <div key={msg.id} className={`flex gap-3 ${msg.type === 'system' ? 'justify-center' : ''}`}>
                    {msg.type === 'system' ? (
                      <p className="text-gray-500 text-xs bg-gray-900 px-3 py-1 rounded-full">{msg.content}</p>
                    ) : (
                      <>
                        <div className="w-8 h-8 bg-gray-700 rounded-full flex items-center justify-center text-sm flex-shrink-0">
                          {msg.from[0]}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-baseline gap-2">
                            <span className={`font-semibold text-sm ${msg.from === user.displayName ? 'text-green-400' : 'text-white'}`}>
                              {msg.from}
                            </span>
                            <span className="text-gray-600 text-xs">
                              {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </div>
                          <p className="text-gray-300 text-sm break-words">{msg.content}</p>
                        </div>
                      </>
                    )}
                  </div>
                ))}
                <div ref={chatEndRef} />
              </div>

              {/* Chat Input */}
              <div className="p-4 border-t border-gray-700">
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Type a message..."
                    value={chatMessage}
                    onChange={(e) => setChatMessage(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                    className="flex-1 bg-gray-900 border border-gray-700 rounded-xl px-4 py-2.5 text-white placeholder-gray-500 focus:outline-none focus:border-green-500"
                  />
                  <button
                    onClick={handleSendMessage}
                    className="bg-gradient-to-r from-green-500 to-emerald-600 text-white p-2.5 rounded-xl hover:from-green-600 hover:to-emerald-700 transition-all"
                  >
                    <Send size={20} />
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Sidebar - Your Info */}
        <div className="space-y-4">
          <div className="bg-gray-800 rounded-2xl border border-gray-700 p-6">
            <h3 className="text-white font-bold mb-4">Your Profile</h3>
            <div className="flex flex-col items-center">
              <AvatarDisplay size="lg" showPet={true} showAura={true} animated />
              <p className="text-white font-bold mt-3">{user.displayName}</p>
              <p className="text-gray-500 text-sm">@{user.username}</p>
              <div className="flex items-center gap-2 mt-2 text-green-400 text-sm">
                <Circle size={8} className="fill-green-400" />
                Online
              </div>
            </div>
          </div>

          <div className="bg-gray-800 rounded-2xl border border-gray-700 p-4">
            <h3 className="text-white font-bold mb-3 text-sm">Quick Stats</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-400">Friends</span>
                <span className="text-white font-medium">{friends.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Online Friends</span>
                <span className="text-green-400 font-medium">{friends.filter(f => f.status !== 'offline').length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Games Played</span>
                <span className="text-white font-medium">{user.gamesPlayed}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
