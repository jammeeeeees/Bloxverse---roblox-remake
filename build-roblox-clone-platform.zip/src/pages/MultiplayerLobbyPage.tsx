import { useEffect, useRef, useState } from 'react';
import { useAuthStore } from '../store/authStore';
import { useSocialStore } from '../store/socialStore';
import AvatarDisplay from '../components/AvatarDisplay';
import { GAMES } from '../data/games';
import { ArrowLeft, Users, Send, Play, Crown, Circle } from 'lucide-react';

interface MultiplayerLobbyPageProps {
  gameId: string | null;
  onStartGame: (gameId: string) => void;
  onBack: () => void;
  onOpenAuth: () => void;
}

export default function MultiplayerLobbyPage({ gameId, onStartGame, onBack, onOpenAuth }: MultiplayerLobbyPageProps) {
  const { user, isLoggedIn } = useAuthStore();
  const { currentLobby, lobbyChat, createLobby, leaveLobby, sendLobbyMessage, startGame } = useSocialStore();
  const [chatMessage, setChatMessage] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);

  const game = GAMES.find(g => g.id === gameId);

  useEffect(() => {
    if (isLoggedIn && user && gameId && !currentLobby) {
      const hostPlayer = {
        id: user.id,
        username: user.username,
        displayName: user.displayName,
        avatar: user.equippedAvatar,
        level: user.level,
        status: 'in-game' as const,
        currentGame: game?.title,
      };
      createLobby(gameId, 4, true, hostPlayer);
    }
  }, [isLoggedIn, user, gameId, currentLobby, createLobby, game]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [lobbyChat]);

  useEffect(() => {
    return () => {
      if (user) leaveLobby(user.id);
    };
  }, []);

  if (!isLoggedIn || !user) {
    return (
      <div className="text-center py-20">
        <div className="text-7xl mb-6">🎮</div>
        <h2 className="text-3xl font-bold text-white mb-3">Join Multiplayer Game</h2>
        <p className="text-gray-400 mb-8 max-w-md mx-auto">
          Sign in to play with other players!
        </p>
        <button
          onClick={onOpenAuth}
          className="bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold px-8 py-3 rounded-xl hover:from-green-600 hover:to-emerald-700 transition-all shadow-lg shadow-green-500/25"
        >
          Sign In
        </button>
      </div>
    );
  }

  if (!game || !currentLobby) {
    return (
      <div className="text-center py-20">
        <div className="text-5xl mb-4 animate-spin">⏳</div>
        <h2 className="text-xl font-bold text-white">Creating lobby...</h2>
      </div>
    );
  }

  const handleSendMessage = () => {
    if (!chatMessage.trim()) return;
    sendLobbyMessage(user.displayName, chatMessage.trim());
    setChatMessage('');
  };

  const handleStartGame = () => {
    startGame(currentLobby.id);
    onStartGame(gameId!);
  };

  const isHost = currentLobby.host.id === user.id;

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <button
          onClick={onBack}
          className="p-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded-lg transition-colors"
        >
          <ArrowLeft size={20} />
        </button>
        <div className="flex-1">
          <h1 className="text-2xl font-bold text-white">{game.title} — Multiplayer Lobby</h1>
          <p className="text-gray-400 text-sm">Waiting for players...</p>
        </div>
        <div className="flex items-center gap-2 text-gray-400">
          <Users size={18} />
          <span>{currentLobby.players.length}/{currentLobby.maxPlayers} players</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Players */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-gray-800 rounded-2xl border border-gray-700 p-6">
            <h2 className="text-white font-bold mb-4 flex items-center gap-2">
              <Users size={18} className="text-green-400" />
              Players in Lobby
            </h2>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {currentLobby.players.map((player) => (
                <div
                  key={player.id}
                  className="bg-gray-900 rounded-xl border border-gray-700 p-4 flex flex-col items-center relative"
                >
                  {player.id === currentLobby.host.id && (
                    <div className="absolute -top-2 -right-2 w-6 h-6 bg-yellow-500 rounded-full flex items-center justify-center">
                      <Crown size={12} className="text-white" />
                    </div>
                  )}
                  <AvatarDisplay size="lg" equipped={player.avatar} showPet={true} showAura={true} animated />
                  <p className="text-white font-bold text-sm mt-2 truncate w-full text-center">{player.displayName}</p>
                  <p className="text-gray-500 text-xs">Level {player.level}</p>
                  <div className="flex items-center gap-1 mt-1 text-green-400 text-xs">
                    <Circle size={6} className="fill-green-400" />
                    Ready
                  </div>
                </div>
              ))}
              
              {/* Empty slots */}
              {Array.from({ length: currentLobby.maxPlayers - currentLobby.players.length }).map((_, idx) => (
                <div
                  key={`empty-${idx}`}
                  className="bg-gray-900/50 rounded-xl border border-gray-700/50 border-dashed p-4 flex flex-col items-center justify-center h-48"
                >
                  <div className="w-16 h-16 bg-gray-800 rounded-xl flex items-center justify-center text-gray-600 mb-2">
                    ?
                  </div>
                  <p className="text-gray-600 text-sm">Waiting...</p>
                </div>
              ))}
            </div>

            {/* Start Game Button */}
            {isHost && (
              <div className="mt-6 flex justify-center">
                <button
                  onClick={handleStartGame}
                  disabled={currentLobby.players.length < 1}
                  className="bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold px-12 py-4 rounded-xl hover:from-green-600 hover:to-emerald-700 transition-all shadow-lg shadow-green-500/25 flex items-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Play size={20} />
                  Start Game
                </button>
              </div>
            )}
            {!isHost && (
              <p className="text-center text-gray-500 mt-6">Waiting for host to start the game...</p>
            )}
          </div>

          {/* Game Info */}
          <div className="bg-gray-800 rounded-2xl border border-gray-700 overflow-hidden">
            <div className="aspect-video relative">
              <img src={game.thumbnail} alt={game.title} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-gray-800 to-transparent" />
              <div className="absolute bottom-4 left-4">
                <span className={`bg-gradient-to-r ${game.gradient} text-white text-xs font-bold px-3 py-1 rounded-full`}>
                  {game.category}
                </span>
              </div>
            </div>
            <div className="p-4">
              <h3 className="text-white font-bold">{game.title}</h3>
              <p className="text-gray-400 text-sm mt-1">{game.description}</p>
            </div>
          </div>
        </div>

        {/* Chat */}
        <div className="bg-gray-800 rounded-2xl border border-gray-700 overflow-hidden flex flex-col h-[500px]">
          <div className="p-4 border-b border-gray-700">
            <h3 className="text-white font-bold">Lobby Chat</h3>
          </div>
          
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {lobbyChat.map((msg) => (
              <div key={msg.id} className={`flex gap-3 ${msg.type === 'system' ? 'justify-center' : ''}`}>
                {msg.type === 'system' ? (
                  <p className="text-gray-500 text-xs bg-gray-900 px-3 py-1 rounded-full">{msg.content}</p>
                ) : (
                  <>
                    <div className="w-7 h-7 bg-gray-700 rounded-full flex items-center justify-center text-xs flex-shrink-0">
                      {msg.from[0]}
                    </div>
                    <div className="flex-1 min-w-0">
                      <span className={`font-semibold text-xs ${msg.from === user.displayName ? 'text-green-400' : 'text-white'}`}>
                        {msg.from}
                      </span>
                      <p className="text-gray-300 text-sm break-words">{msg.content}</p>
                    </div>
                  </>
                )}
              </div>
            ))}
            <div ref={chatEndRef} />
          </div>

          <div className="p-4 border-t border-gray-700">
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Type a message..."
                value={chatMessage}
                onChange={(e) => setChatMessage(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                className="flex-1 bg-gray-900 border border-gray-700 rounded-xl px-3 py-2 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-green-500"
              />
              <button
                onClick={handleSendMessage}
                className="bg-green-500 text-white p-2 rounded-xl hover:bg-green-600 transition-all"
              >
                <Send size={16} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
