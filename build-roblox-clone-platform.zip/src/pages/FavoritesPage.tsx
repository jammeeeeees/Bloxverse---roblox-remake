import { useAuthStore } from '../store/authStore';
import GameCard from '../components/GameCard';
import { GAMES } from '../data/games';

interface FavoritesPageProps {
  onPlayGame: (gameId: string) => void;
  onOpenAuth: () => void;
}

export default function FavoritesPage({ onPlayGame, onOpenAuth }: FavoritesPageProps) {
  const { isLoggedIn, user } = useAuthStore();

  if (!isLoggedIn || !user) {
    return (
      <div className="text-center py-20">
        <div className="text-6xl mb-4">⭐</div>
        <h2 className="text-2xl font-bold text-white mb-3">Sign in to see your favorites</h2>
        <p className="text-gray-400 mb-6">Create an account to save your favorite games</p>
        <button
          onClick={onOpenAuth}
          className="bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold px-8 py-3 rounded-xl hover:from-green-600 hover:to-emerald-700 transition-all shadow-lg"
        >
          Sign In
        </button>
      </div>
    );
  }

  const favoriteGames = GAMES.filter(g => user.favoriteGames.includes(g.id));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">Your Favorites</h1>
        <p className="text-gray-400">{favoriteGames.length} games saved</p>
      </div>

      {favoriteGames.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {favoriteGames.map(game => (
            <GameCard key={game.id} game={game} onPlay={onPlayGame} />
          ))}
        </div>
      ) : (
        <div className="text-center py-16">
          <div className="text-6xl mb-4">💔</div>
          <h3 className="text-xl font-bold text-white mb-2">No favorites yet</h3>
          <p className="text-gray-400">Click the heart icon on any game to add it to your favorites!</p>
        </div>
      )}
    </div>
  );
}
